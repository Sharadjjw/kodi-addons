"""Shared helpers: history storage, resume logic, playback."""
import hashlib
import json
import os
import shutil
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import lp_config as cfg

ADDON_ID = cfg.ADDON_ID
BASE_URL = 'plugin://%s/' % ADDON_ID
# Both Last Played add-ons ignore playback that came from either one's own list.
SKIP_PREFIXES = ('plugin://script.lastplayed/', 'plugin://plugin.video.lastplayed10/')
HISTORY_FILE = 'history.json'
LEGACY_FILE = 'last.json'   # written by v1.0.0
MIN_RESUME = 10             # seconds: don't offer resume below this
END_MARGIN = 30             # seconds: treat as finished within this of the end

RESTORE_PROP = ADDON_ID + '.restore'   # per add-on, so the two never trigger each other
SUB_KEYS = ('sub_enabled', 'sub_index', 'sub_lang', 'sub_name', 'sub_count', 'sub_file',
            'sub_external')
SUB_EXT = ('.srt', '.ass', '.ssa', '.sub', '.smi', '.vtt', '.idx', '.sup')
# A subtitle file added with "Browse for subtitle" (or found next to the video) is
# named by Kodi from the filename's leftover words + "(External)" (string 21602),
# never by the file name itself, so the file has to be found again by that name.
EXTERNAL_LABEL = '(External)'
SUB_FLAG_TOKENS = {'default', 'forced', 'cc', 'sdh'}
LANG_TOKENS = set((
    'aa ab af ak am an ar as av ay az ba be bg bh bi bm bn bo br bs ca ce ch co cr cs cu cv cy '
    'da de dv dz ee el en eo es et eu fa ff fi fj fo fr fy ga gd gl gn gu gv ha he hi ho hr ht '
    'hu hy hz ia id ie ig ii ik io is it iu ja jv ka kg ki kj kk kl km kn ko kr ks ku kv kw ky '
    'la lb lg li ln lo lt lu lv mg mh mi mk ml mn mr ms mt my na nb nd ne ng nl nn no nr nv ny '
    'oc oj om or os pa pi pl ps pt qu rm rn ro ru rw sa sc sd se sg si sk sl sm sn so sq sr ss '
    'st su sv sw ta te tg th ti tk tl tn to tr ts tt tw ty ug uk ur uz ve vi vo wa wo xh yi yo '
    'za zh zu '
    'eng hin mal tam tel kan ben mar guj pan urd fre fra ger deu spa ita por rus jpn kor chi zho '
    'ara heb tur pol dut nld swe nor dan fin gre ell hun cze ces rum ron tha vie ind may msa '
    'english hindi malayalam tamil telugu kannada bengali marathi gujarati punjabi urdu french '
    'german spanish italian portuguese russian japanese korean chinese arabic hebrew turkish '
    'polish dutch swedish norwegian danish finnish greek hungarian czech romanian thai '
    'vietnamese indonesian malay').split())
SEARCH_MAX_FILES = 400      # per folder; keeps the search quick on big folders
# Kodi writes "Opening Subtitle file: <path>" (INFO) to its log whenever an external
# subtitle file is opened, so a browsed file's real path can be read back from there.
LOG_MARK = 'Opening Subtitle file: '
LOG_TAIL = 2 * 1024 * 1024  # bytes read from the end of kodi.log
# Set by Premiumize Library when it switches on a subtitle the user picked for the
# video being started ("<file id>|<time>"); our own restore then stands aside.
PMLIB_OWNER_PROP = 'pmlib.subs_owner'
OWNER_FRESH = 120           # seconds


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def addon():
    # Fresh instance each time so changed settings are picked up.
    return xbmcaddon.Addon(ADDON_ID)


# ---------------------------------------------------------------- settings
def _get_bool(key, default):
    try:
        return addon().getSettingBool(key)
    except Exception:
        return default


def _get_int(key, default):
    try:
        return addon().getSettingInt(key)
    except Exception:
        return default


def resume_enabled():
    return _get_bool('resume', True)


def prompt_enabled():
    return _get_bool('prompt', cfg.PROMPT_DEFAULT)


def history_size():
    if cfg.HISTORY_FIXED:
        return cfg.HISTORY_FIXED
    return max(1, min(_get_int('history_size', 10), 50))


# ----------------------------------------------------------------- storage
def _profile_dir():
    path = xbmcvfs.translatePath(addon().getAddonInfo('profile'))
    os.makedirs(path, exist_ok=True)
    return path


def strm_target(*paths):
    """If what is playing is a library item stored as a .strm file (e.g. Premiumize
    Library), return that .strm path. Replaying the .strm itself makes Kodi treat it
    exactly like playing it from the Movies / TV shows section: it loads the item's
    library info and its saved per-file settings (subtitle offset, audio offset,
    chosen streams), and the add-on behind it attaches its external subtitles again."""
    for path in paths:
        if path and path.split('?')[0].lower().endswith('.strm'):
            return path
    return ''


def entry_id(target):
    return hashlib.md5(target.encode('utf-8')).hexdigest()[:12]


def _clean(entries):
    out = []
    for e in entries:
        if isinstance(e, dict) and e.get('target'):
            e.setdefault('id', entry_id(e['target']))
            out.append(e)
    return out


def _migrate_legacy(folder):
    path = os.path.join(folder, LEGACY_FILE)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            old = json.load(f)
        if not old.get('target'):
            return []
        entry = {
            'id': entry_id(old['target']),
            'target': old['target'],
            'playing': old.get('playing', old['target']),
            'title': old.get('title', ''),
            'type': old.get('type', 'video'),
            'thumb': '',
            'pos': float(old.get('pos') or 0),
            'total': float(old.get('total') or 0),
            'finished': False,
            'ts': time.time(),
        }
        save([entry])
        return [entry]
    except Exception:
        return []


def load():
    folder = _profile_dir()
    path = os.path.join(folder, HISTORY_FILE)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, list):
            return _clean(data)
    except FileNotFoundError:
        pass
    except Exception as exc:
        log('could not read history: %s' % exc, xbmc.LOGERROR)
        return []
    return _migrate_legacy(folder)


def save(entries):
    try:
        path = os.path.join(_profile_dir(), HISTORY_FILE)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(entries, f)
        os.replace(tmp, path)
        _prune_subs({e.get('id') for e in entries})
    except Exception as exc:
        log('could not save history: %s' % exc, xbmc.LOGERROR)


def record_start(entry):
    entries = [e for e in load() if e.get('id') != entry['id']]
    entries.insert(0, entry)
    save(entries[:history_size()])


def update_position(eid, pos, total, finished=False):
    entries = load()
    for e in entries:
        if e.get('id') == eid:
            e['pos'] = 0.0 if finished else float(pos or 0)
            if total:
                e['total'] = float(total)
            e['finished'] = bool(finished)
            save(entries)
            return


def find(eid):
    for e in load():
        if e.get('id') == eid:
            return e
    return None


def remove(eid):
    save([e for e in load() if e.get('id') != eid])


def clear():
    save([])


# ------------------------------------------------------------ resume logic
def has_resume_point(entry):
    pos = float(entry.get('pos') or 0)
    total = float(entry.get('total') or 0)
    if entry.get('finished') or pos < MIN_RESUME:
        return False
    if total > 0 and (pos > total - END_MARGIN or pos / total > 0.95):
        return False
    return True


def can_resume(entry):
    return resume_enabled() and has_resume_point(entry)


def fmt_time(seconds):
    seconds = int(seconds or 0)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return '%d:%02d:%02d' % (h, m, s) if h else '%d:%02d' % (m, s)


# --------------------------------------------------------------- subtitles
def _subs_root():
    return os.path.join(_profile_dir(), 'subs')


def _prune_subs(keep_ids):
    root = _subs_root()
    if not os.path.isdir(root):
        return
    for name in os.listdir(root):
        if name not in keep_ids:
            shutil.rmtree(os.path.join(root, name), ignore_errors=True)


def update_subs(eid, prefs):
    entries = load()
    for e in entries:
        if e.get('id') == eid:
            e.update(prefs)
            save(entries)
            return


def _rpc(method, params=None):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params:
        req['params'] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req))).get('result')
    except Exception:
        return None


def read_subtitle_state():
    """Current subtitle state of the active video player, or None."""
    players = _rpc('Player.GetActivePlayers') or []
    pid = next((p.get('playerid') for p in players if p.get('type') == 'video'), None)
    if pid is None:
        return None
    props = _rpc('Player.GetProperties', {
        'playerid': pid,
        'properties': ['subtitleenabled', 'currentsubtitle', 'subtitles']})
    if not isinstance(props, dict):
        return None
    return {
        'enabled': bool(props.get('subtitleenabled')),
        'current': props.get('currentsubtitle') or {},
        'streams': props.get('subtitles') or [],
    }


def _find_subtitle_file(name, playing):
    dirs = []
    base = (playing or '').split('|')[0].split('?')[0]
    if base and not base.startswith(('http://', 'https://')) and '/' in base:
        dirs.append(base.rsplit('/', 1)[0] + '/')
    dirs += ['special://temp/', 'special://temp/subtitles/']
    custom = (_rpc('Settings.GetSettingValue', {'setting': 'subtitles.custompath'}) or {}).get('value')
    if custom:
        dirs.append(custom if custom.endswith('/') else custom + '/')
    for d in dirs:
        if xbmcvfs.exists(d + name):
            return d + name
    return ''


def _external_label():
    try:
        return xbmc.getLocalizedString(21602) or EXTERNAL_LABEL
    except Exception:
        return EXTERNAL_LABEL


def is_external_name(name):
    name = (name or '').strip()
    return name.endswith(EXTERNAL_LABEL) or name.endswith(_external_label())


def _tokens(text):
    """Split like Kodi does (spaces, dots and dashes)."""
    for ch in '.-':
        text = text.replace(ch, ' ')
    return text.split()


def _key(tokens):
    """Comparable form of name words: language and flag words dropped, letters and digits only."""
    words = [t for t in tokens
             if t.lower() not in LANG_TOKENS and t.lower() not in SUB_FLAG_TOKENS
             and t.lower() != 'none']
    return ''.join(ch for ch in ''.join(words).lower() if ch.isalnum())


def _stream_name_key(name):
    name = (name or '').strip()
    for label in (_external_label(), EXTERNAL_LABEL):
        if label and name.endswith(label):
            name = name[:-len(label)]
            break
    return _key(_tokens(name))


def _file_name_key(filename, video_base):
    """Kodi's rule (CUtil::GetExternalStreamDetailsFromFilename): drop the extension and a
    leading video name, then the words between the dots, minus language/flag words."""
    base = filename.rsplit('.', 1)[0]
    if video_base and base.lower().startswith(video_base.lower()):
        base = base[len(video_base):]
    return _key(_tokens(base))


def _list_subs(folder):
    try:
        dirs, files = xbmcvfs.listdir(folder)
    except Exception:
        return [], []
    subs = [f for f in files[:SEARCH_MAX_FILES] if f.lower().endswith(SUB_EXT)]
    return dirs, subs


def _from_kodi_log(want, video_base):
    """Newest subtitle path in kodi.log whose name matches the stream, or ''."""
    try:
        path = xbmcvfs.translatePath('special://logpath/kodi.log')
        with open(path, 'rb') as handle:
            handle.seek(0, os.SEEK_END)
            size = handle.tell()
            handle.seek(max(0, size - LOG_TAIL))
            text = handle.read().decode('utf-8', 'replace')
    except Exception:
        return ''
    for line in reversed(text.splitlines()):
        at = line.find(LOG_MARK)
        if at < 0:
            continue
        found = line[at + len(LOG_MARK):].strip()
        fname = found.replace('\\', '/').rsplit('/', 1)[-1]
        if (fname.lower().endswith(SUB_EXT) and _file_name_key(fname, video_base) == want
                and xbmcvfs.exists(found)):
            return found
    return ''


def _find_external_file(eid, name, playing):
    """Find the file behind a "(External)" subtitle stream: our kept copy first, then the
    video's folder and its subfolders, the folder above, Kodi's subtitle folders and the
    Android Download folder. Returns a path or ''."""
    want = _stream_name_key(name)
    base = (playing or '').split('|')[0].split('?')[0]
    local = bool(base) and not base.startswith(('http://', 'https://', 'plugin://')) and '/' in base
    video_base = base.rsplit('/', 1)[-1].rsplit('.', 1)[0] if local else ''

    kept = os.path.join(_subs_root(), eid) + '/'
    _, subs = _list_subs(kept)
    hits = [f for f in subs if _file_name_key(f, video_base) == want]
    if hits:
        return kept + hits[0]
    found = _from_kodi_log(want, video_base)
    if found:
        return found

    folders = []
    if local:
        vdir = base.rsplit('/', 1)[0] + '/'
        folders.append(vdir)
        sub_dirs, _ = _list_subs(vdir)
        folders += [vdir + d.rstrip('/') + '/' for d in sub_dirs[:20]]
        parent = vdir.rstrip('/').rsplit('/', 1)[0]
        if parent:
            folders.append(parent + '/')
    folders += ['special://temp/subtitles/', 'special://temp/']
    custom = (_rpc('Settings.GetSettingValue', {'setting': 'subtitles.custompath'}) or {}).get('value')
    if custom:
        folders.append(custom if custom.endswith('/') else custom + '/')
    folders.append('/storage/emulated/0/Download/')

    seen = set()
    for folder in folders:
        if folder in seen:
            continue
        seen.add(folder)
        _, subs = _list_subs(folder)
        hits = [f for f in subs if _file_name_key(f, video_base) == want]
        if not hits:
            continue
        if len(hits) > 1:   # same words, e.g. a .srt and a .ass: newest first
            def _mtime(f):
                try:
                    return xbmcvfs.Stat(folder + f).st_mtime()
                except Exception:
                    return 0
            hits.sort(key=_mtime, reverse=True)
        return folder + hits[0]
    return ''


def _keep_external_subtitle(eid, name, playing):
    """Copy an external subtitle into our profile so it survives temp cleanup."""
    dest_dir = os.path.join(_subs_root(), eid)
    if is_external_name(name):
        src = _find_external_file(eid, name, playing)
        if not src:
            log('could not find the file of subtitle "%s"' % name, xbmc.LOGWARNING)
            return ''
        if src.startswith(dest_dir + '/'):
            return src
        dest = os.path.join(dest_dir, src.rsplit('/', 1)[-1])
    else:
        dest = os.path.join(dest_dir, os.path.basename(name))
        if os.path.exists(dest):
            return dest
        src = _find_subtitle_file(name, playing)
        if not src:
            return ''
    try:
        os.makedirs(dest_dir, exist_ok=True)
        if xbmcvfs.copy(src, dest):
            return dest
    except Exception as exc:
        log('could not keep subtitle: %s' % exc, xbmc.LOGERROR)
    return ''


def snapshot_subtitles(eid, state, playing):
    cur = state['current']
    prefs = {
        'sub_enabled': bool(state['enabled']),
        'sub_index': cur.get('index'),
        'sub_lang': cur.get('language') or '',
        'sub_name': cur.get('name') or '',
        'sub_count': len(state['streams']),
        'sub_file': '',
        'sub_external': False,
    }
    if prefs['sub_enabled']:
        prefs['sub_external'] = is_external_name(prefs['sub_name'])
        if prefs['sub_external'] or prefs['sub_name'].lower().endswith(SUB_EXT):
            prefs['sub_file'] = _keep_external_subtitle(eid, prefs['sub_name'], playing)
    return prefs


def _match_stream(streams, prefs):
    name = prefs.get('sub_name') or ''
    lang = prefs.get('sub_lang') or ''
    for s in streams:
        if (s.get('name') or '') == name and (s.get('language') or '') == lang:
            return s.get('index')
    if prefs.get('sub_external'):
        # A file the user picked: never swap in an embedded track of the same language;
        # the kept file is loaded instead.
        return None
    idx = prefs.get('sub_index')
    if idx is not None and len(streams) == prefs.get('sub_count'):
        for s in streams:
            if s.get('index') == idx and (s.get('language') or '') == lang:
                return idx
    if lang:
        for s in streams:
            if (s.get('language') or '') == lang:
                return s.get('index')
    return None


def restore_subtitles(player, prefs, final=False, allow_file=True):
    """One restore attempt. Returns 'ok', 'applied', 'applied_file', 'wait' or 'gaveup'."""
    if 'sub_enabled' not in prefs:
        return 'gaveup'
    state = read_subtitle_state()
    if state is None:
        return 'gaveup' if final else 'wait'

    if not prefs.get('sub_enabled'):
        if state['enabled']:
            player.showSubtitles(False)
            return 'applied'
        return 'ok'

    streams = state['streams']
    idx = _match_stream(streams, prefs)
    if idx is not None:
        if state['enabled'] and state['current'].get('index') == idx:
            return 'ok'
        player.setSubtitleStream(idx)
        player.showSubtitles(True)
        return 'applied'

    path = prefs.get('sub_file')
    if allow_file and path and xbmcvfs.exists(path) and (streams or final or prefs.get('sub_external')):
        player.setSubtitles(path)
        return 'applied_file'
    return 'gaveup' if final else 'wait'


def subtitles_handled_elsewhere():
    """True when Premiumize Library is applying the user's chosen subtitle to this playback."""
    val = xbmcgui.Window(10000).getProperty(PMLIB_OWNER_PROP)
    try:
        return time.time() - float(val.rsplit('|', 1)[1]) < OWNER_FRESH
    except (IndexError, ValueError):
        return False


def mark_restore(entry):
    """Tell the service this playback was started by us, so it restores subtitles."""
    xbmcgui.Window(10000).setProperty(RESTORE_PROP, '%s|%d' % (entry['id'], int(time.time())))


def take_restore_flag(eid):
    win = xbmcgui.Window(10000)
    val = win.getProperty(RESTORE_PROP)
    if not val:
        return False
    try:
        fid, ts = val.split('|')
        fresh = time.time() - int(ts) < 60
    except Exception:
        fid, fresh = '', False
    if fid == eid or not fresh:
        win.clearProperty(RESTORE_PROP)
    return fid == eid and fresh


# ---------------------------------------------------------------- playback
def make_listitem(entry, resume):
    mark_restore(entry)
    li = xbmcgui.ListItem(label=entry.get('title') or '', path=entry['target'])
    thumb = entry.get('thumb')
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    if resume:
        li.setProperty('StartOffset', str(int(entry.get('pos') or 0)))
    return li


def is_strm(target):
    return bool(target) and target.split('?')[0].lower().endswith('.strm')


def _strm_plugin_url(path):
    try:
        f = xbmcvfs.File(path)
        try:
            text = f.read()
        finally:
            f.close()
    except Exception:
        return ''
    for line in (text or '').splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            return line if line.startswith('plugin://') else ''
    return ''


def _play_strm(entry, resume):
    """Start a library .strm the way the Movies section and Kore do (JSON-RPC
    Player.Open): Kodi expands the .strm, keeps the library item, and loads its
    saved settings (subtitle offset etc.). xbmc.Player().play() can't do this:
    Kodi silently refuses to play a .strm handed to it that way."""
    mark_restore(entry)
    if resume:
        secs = int(entry.get('pos') or 0)
        start = {'hours': secs // 3600, 'minutes': (secs % 3600) // 60,
                 'seconds': secs % 60, 'milliseconds': 0}
    else:
        start = False
    req = {'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Open',
           'params': {'item': {'file': entry['target']}, 'options': {'resume': start}}}
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception as exc:
        reply = {'error': str(exc)}
    if reply.get('result') == 'OK':
        return
    log('Player.Open failed for library item: %s' % reply.get('error'), xbmc.LOGWARNING)
    # Fallback: play the add-on link inside the .strm (subtitles come back,
    # but Kodi won't know it is the library item).
    url = _strm_plugin_url(entry['target'])
    if url:
        li = make_listitem(dict(entry, target=url), resume)
        xbmc.Player().play(item=url, listitem=li)
    else:
        notify('Could not start this item')


def play_entry(entry, resume):
    if is_strm(entry['target']):
        _play_strm(entry, resume)
        return
    xbmc.Player().play(item=entry['target'], listitem=make_listitem(entry, resume))


def ask_start(entry):
    """Returns 'resume', 'start' or None (cancelled)."""
    labels = ['Resume from %s' % fmt_time(entry.get('pos')),
              'Play from the beginning']
    idx = xbmcgui.Dialog().select(entry.get('title') or 'Resume playing?', labels)
    if idx == 0:
        return 'resume'
    if idx == 1:
        return 'start'
    return None


def notify(message):
    xbmcgui.Dialog().notification(cfg.NAME, message,
                                  xbmcgui.NOTIFICATION_INFO, 4000)
