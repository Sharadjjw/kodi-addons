"""Launcher (Program add-ons).

Last Played      (script.lastplayed)         -> resume / replay the last item
Last Played 10   (plugin.video.lastplayed10) -> pick from the last 10 items
"""
import xbmcgui

import lp_config as cfg
import lp_core as core


def start_entry(entry):
    if core.can_resume(entry) and core.prompt_enabled():
        choice = core.ask_start(entry)
        if choice is None:
            return
        core.play_entry(entry, resume=(choice == 'resume'))
    else:
        core.play_entry(entry, resume=core.can_resume(entry))


def pick_from_history(entries):
    labels = []
    for e in entries:
        label = e.get('title') or e['target']
        if core.has_resume_point(e):
            label += '   [%s]' % core.fmt_time(e.get('pos'))
        labels.append(label)
    idx = xbmcgui.Dialog().select('Recently played', labels)
    if idx >= 0:
        start_entry(entries[idx])


def main():
    entries = core.load()
    if not entries:
        core.notify('Nothing played yet')
        return
    if cfg.LAUNCH_MODE == 'history':
        pick_from_history(entries)
    else:
        start_entry(entries[0])


if __name__ == '__main__':
    main()
