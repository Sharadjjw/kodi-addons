"""Per-add-on configuration: Last Played (one click)."""
ADDON_ID = 'script.lastplayed'
NAME = 'Last Played'
LAUNCH_MODE = 'last'       # one click: resume/replay the most recent item
HISTORY_FIXED = 1          # only the last item is kept
PROMPT_DEFAULT = False     # truly one click; can be turned on in settings
