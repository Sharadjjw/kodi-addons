"""Shared helpers: history storage, resume logic, playback."""
import hashlib
import json
import os
import shutil
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import lp_config as cfg

ADDON_ID = cfg.ADDON_ID
BASE_URL = 'plugin://%s/' % ADDON_ID
# Both Last Played add-ons ignore playback that came from either one's own list.
SKIP_PREFIXES = ('plugin://script.lastplayed/', 'plugin://plugin.video.lastplayed10/')
HISTORY_FILE = 'history.json'
LEGACY_FILE = 'last.json'   # written by v1.0.0
MIN_RESUME = 10             # seconds: don't offer resume below this
END_MARGIN = 30             # seconds: treat as finished within this of the end

RESTORE_PROP = ADDON_ID + '.restore'   # per add-on, so the two never trigger each other
SUB_KEYS = ('sub_enabled', 'sub_index', 'sub_lang', 'sub_name', 'sub_count', 'sub_file')
SUB_EXT = ('.srt', '.ass', '.ssa', '.sub', '.smi', '.vtt', '.idx', '.sup')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def addon():
    # Fresh instance each time so changed settings are picked up.
    return xbmcaddon.Addon(ADDON_ID)


# ---------------------------------------------------------------- settings
def _get_bool(key, default):
    try:
        return addon().getSettingBool(key)
    except Exception:
        return default


def _get_int(key, default):
    try:
        return addon().getSettingInt(key)
    except Exception:
        return default


def resume_enabled():
    return _get_bool('resume', True)


def prompt_enabled():
    return _get_bool('prompt', cfg.PROMPT_DEFAULT)


def history_size():
    if cfg.HISTORY_FIXED:
        return cfg.HISTORY_FIXED
    return max(1, min(_get_int('history_size', 10), 50))


# ----------------------------------------------------------------- storage
def _profile_dir():
    path = xbmcvfs.translatePath(addon().getAddonInfo('profile'))
    os.makedirs(path, exist_ok=True)
    return path


def entry_id(target):
    return hashlib.md5(target.encode('utf-8')).hexdigest()[:12]


def _clean(entries):
    out = []
    for e in entries:
        if isinstance(e, dict) and e.get('target'):
            e.setdefault('id', entry_id(e['target']))
            out.append(e)
    return out


def _migrate_legacy(folder):
    path = os.path.join(folder, LEGACY_FILE)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            old = json.load(f)
        if not old.get('target'):
            return []
        entry = {
            'id': entry_id(old['target']),
            'target': old['target'],
            'playing': old.get('playing', old['target']),
            'title': old.get('title', ''),
            'type': old.get('type', 'video'),
            'thumb': '',
            'pos': float(old.get('pos') or 0),
            'total': float(old.get('total') or 0),
            'finished': False,
            'ts': time.time(),
        }
        save([entry])
        return [entry]
    except Exception:
        return []


def load():
    folder = _profile_dir()
    path = os.path.join(folder, HISTORY_FILE)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, list):
            return _clean(data)
    except FileNotFoundError:
        pass
    except Exception as exc:
        log('could not read history: %s' % exc, xbmc.LOGERROR)
        return []
    return _migrate_legacy(folder)


def save(entries):
    try:
        path = os.path.join(_profile_dir(), HISTORY_FILE)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(entries, f)
        os.replace(tmp, path)
        _prune_subs({e.get('id') for e in entries})
    except Exception as exc:
        log('could not save history: %s' % exc, xbmc.LOGERROR)


def record_start(entry):
    entries = [e for e in load() if e.get('id') != entry['id']]
    entries.insert(0, entry)
    save(entries[:history_size()])


def update_position(eid, pos, total, finished=False):
    entries = load()
    for e in entries:
        if e.get('id') == eid:
            e['pos'] = 0.0 if finished else float(pos or 0)
            if total:
                e['total'] = float(total)
            e['finished'] = bool(finished)
            save(entries)
            return


def find(eid):
    for e in load():
        if e.get('id') == eid:
            return e
    return None


def remove(eid):
    save([e for e in load() if e.get('id') != eid])


def clear():
    save([])


# ------------------------------------------------------------ resume logic
def has_resume_point(entry):
    pos = float(entry.get('pos') or 0)
    total = float(entry.get('total') or 0)
    if entry.get('finished') or pos < MIN_RESUME:
        return False
    if total > 0 and (pos > total - END_MARGIN or pos / total > 0.95):
        return False
    return True


def can_resume(entry):
    return resume_enabled() and has_resume_point(entry)


def fmt_time(seconds):
    seconds = int(seconds or 0)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return '%d:%02d:%02d' % (h, m, s) if h else '%d:%02d' % (m, s)


# --------------------------------------------------------------- subtitles
def _subs_root():
    return os.path.join(_profile_dir(), 'subs')


def _prune_subs(keep_ids):
    root = _subs_root()
    if not os.path.isdir(root):
        return
    for name in os.listdir(root):
        if name not in keep_ids:
            shutil.rmtree(os.path.join(root, name), ignore_errors=True)


def update_subs(eid, prefs):
    entries = load()
    for e in entries:
        if e.get('id') == eid:
            e.update(prefs)
            save(entries)
            return


def _rpc(method, params=None):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params:
        req['params'] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req))).get('result')
    except Exception:
        return None


def read_subtitle_state():
    """Current subtitle state of the active video player, or None."""
    players = _rpc('Player.GetActivePlayers') or []
    pid = next((p.get('playerid') for p in players if p.get('type') == 'video'), None)
    if pid is None:
        return None
    props = _rpc('Player.GetProperties', {
        'playerid': pid,
        'properties': ['subtitleenabled', 'currentsubtitle', 'subtitles']})
    if not isinstance(props, dict):
        return None
    return {
        'enabled': bool(props.get('subtitleenabled')),
        'current': props.get('currentsubtitle') or {},
        'streams': props.get('subtitles') or [],
    }


def _find_subtitle_file(name, playing):
    dirs = []
    base = (playing or '').split('|')[0].split('?')[0]
    if base and not base.startswith(('http://', 'https://')) and '/' in base:
        dirs.append(base.rsplit('/', 1)[0] + '/')
    dirs += ['special://temp/', 'special://temp/subtitles/']
    custom = (_rpc('Settings.GetSettingValue', {'setting': 'subtitles.custompath'}) or {}).get('value')
    if custom:
        dirs.append(custom if custom.endswith('/') else custom + '/')
    for d in dirs:
        if xbmcvfs.exists(d + name):
            return d + name
    return ''


def _keep_external_subtitle(eid, name, playing):
    """Copy an external subtitle into our profile so it survives temp cleanup."""
    dest_dir = os.path.join(_subs_root(), eid)
    dest = os.path.join(dest_dir, os.path.basename(name))
    if os.path.exists(dest):
        return dest
    src = _find_subtitle_file(name, playing)
    if not src:
        return ''
    try:
        os.makedirs(dest_dir, exist_ok=True)
        if xbmcvfs.copy(src, dest):
            return dest
    except Exception as exc:
        log('could not keep subtitle: %s' % exc, xbmc.LOGERROR)
    return ''


def snapshot_subtitles(eid, state, playing):
    cur = state['current']
    prefs = {
        'sub_enabled': bool(state['enabled']),
        'sub_index': cur.get('index'),
        'sub_lang': cur.get('language') or '',
        'sub_name': cur.get('name') or '',
        'sub_count': len(state['streams']),
        'sub_file': '',
    }
    if prefs['sub_enabled'] and prefs['sub_name'].lower().endswith(SUB_EXT):
        prefs['sub_file'] = _keep_external_subtitle(eid, prefs['sub_name'], playing)
    return prefs


def _match_stream(streams, prefs):
    name = prefs.get('sub_name') or ''
    lang = prefs.get('sub_lang') or ''
    for s in streams:
        if (s.get('name') or '') == name and (s.get('language') or '') == lang:
            return s.get('index')
    idx = prefs.get('sub_index')
    if idx is not None and len(streams) == prefs.get('sub_count'):
        for s in streams:
            if s.get('index') == idx and (s.get('language') or '') == lang:
                return idx
    if lang:
        for s in streams:
            if (s.get('language') or '') == lang:
                return s.get('index')
    return None


def restore_subtitles(player, prefs, final=False, allow_file=True):
    """One restore attempt. Returns 'ok', 'applied', 'applied_file', 'wait' or 'gaveup'."""
    if 'sub_enabled' not in prefs:
        return 'gaveup'
    state = read_subtitle_state()
    if state is None:
        return 'gaveup' if final else 'wait'

    if not prefs.get('sub_enabled'):
        if state['enabled']:
            player.showSubtitles(False)
            return 'applied'
        return 'ok'

    streams = state['streams']
    idx = _match_stream(streams, prefs)
    if idx is not None:
        if state['enabled'] and state['current'].get('index') == idx:
            return 'ok'
        player.setSubtitleStream(idx)
        player.showSubtitles(True)
        return 'applied'

    path = prefs.get('sub_file')
    if allow_file and path and xbmcvfs.exists(path) and (streams or final):
        player.setSubtitles(path)
        return 'applied_file'
    return 'gaveup' if final else 'wait'


def mark_restore(entry):
    """Tell the service this playback was started by us, so it restores subtitles."""
    xbmcgui.Window(10000).setProperty(RESTORE_PROP, '%s|%d' % (entry['id'], int(time.time())))


def take_restore_flag(eid):
    win = xbmcgui.Window(10000)
    val = win.getProperty(RESTORE_PROP)
    if not val:
        return False
    try:
        fid, ts = val.split('|')
        fresh = time.time() - int(ts) < 60
    except Exception:
        fid, fresh = '', False
    if fid == eid or not fresh:
        win.clearProperty(RESTORE_PROP)
    return fid == eid and fresh


# ---------------------------------------------------------------- playback
def make_listitem(entry, resume):
    mark_restore(entry)
    li = xbmcgui.ListItem(label=entry.get('title') or '', path=entry['target'])
    thumb = entry.get('thumb')
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    if resume:
        li.setProperty('StartOffset', str(int(entry.get('pos') or 0)))
    return li


def play_entry(entry, resume):
    xbmc.Player().play(item=entry['target'], listitem=make_listitem(entry, resume))


def ask_start(entry):
    """Returns 'resume', 'start' or None (cancelled)."""
    labels = ['Resume from %s' % fmt_time(entry.get('pos')),
              'Play from the beginning']
    idx = xbmcgui.Dialog().select(entry.get('title') or 'Resume playing?', labels)
    if idx == 0:
        return 'resume'
    if idx == 1:
        return 'start'
    return None


def notify(message):
    xbmcgui.Dialog().notification(cfg.NAME, message,
                                  xbmcgui.NOTIFICATION_INFO, 4000)
