# -*- coding: utf-8 -*-
"""TorrentClaw for Kodi: browse/search TorrentClaw and add releases to Premiumize."""
import hashlib
import re
import sys
import time
from urllib.parse import urlencode, parse_qsl

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.common import (ADDON, ICON, FANART, ApiError, log, notify, setting,
                                  setting_bool, setting_int, load_json, save_json)
from resources.lib.torrentclaw import (TorrentClaw, magnet_of, info_hash, quality_rank,
                                       torrent_langs)
from resources.lib.premiumize import Premiumize, video_files
from resources.lib import sources, release
from resources.lib.tmdb import TMDb, INDIAN_LANGS, REGIONS, EAST_ASIA, person_label, person_photo
from resources.lib.omdb import OMDb, OMDbLimit
from resources.lib.subtitles import (OpenSubtitles, preferred_langs, release_sub_langs, oshash_remote,
                                     imdb_num, rank, result_label, save_sub, lang_name)

BASE_URL = sys.argv[0] if sys.argv else 'plugin://plugin.video.torrentclaw/'
try:
    HANDLE = int(sys.argv[1])
except (IndexError, ValueError):
    HANDLE = -1
PARAMS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 and sys.argv[2] else {}
# 'Search All Torrent Sites' section: every link inside it carries mode=sites, so titles found by
# actor / director / author / keyword / filter open their releases from all the sites.
SITES = PARAMS.get('mode') == 'sites'

LANG_CODES = ['', 'hi', 'ml', 'ta', 'te', 'kn', 'en']
LANG_NAMES = {'hi': 'Hindi', 'ml': 'Malayalam', 'ta': 'Tamil', 'te': 'Telugu', 'kn': 'Kannada',
              'en': 'English'}
MIN_QUALITY = [0, 720, 1080, 2160]
ITEMS_FILE = 'items.json'
HISTORY_FILE = 'search_history.json'
MAX_CACHED_ITEMS = 600
NO_MATCH_RETRY = 12 * 3600  # look a title up on TorrentClaw again after this long
HEAVY_FIELDS = ('audioTracks', 'subtitleTracks', 'torrentFiles')


def url_for(**kw):
    if SITES and 'mode' not in kw:
        kw['mode'] = 'sites'
    return BASE_URL + '?' + urlencode(dict((k, v) for k, v in kw.items() if v not in (None, '')))


def run_plugin(**kw):
    return 'RunPlugin(%s)' % url_for(**kw)


# ====================================================================== item cache
def _hdr(t):
    """Short HDR string from a torrent."""
    h = t.get('hdrType') or ((t.get('videoInfo') or {}).get('hdr') or '')
    return h


def slim_item(item):
    item = dict(item)
    slim = []
    for t in item.get('torrents') or []:
        t = dict(t)
        if t.get('audioTracks') and not t.get('languages'):
            t['languages'] = torrent_langs(t)
        vi = t.get('videoInfo') or {}
        if vi:
            t['videoInfo'] = {'hdr': vi.get('hdr'), 'width': vi.get('width'), 'height': vi.get('height')}
        for f in HEAVY_FIELDS:
            t.pop(f, None)
        slim.append(t)
    if 'torrents' in item:
        item['torrents'] = slim
    item['_cached_at'] = int(time.time())
    return item


def cache_items(items):
    store = load_json(ITEMS_FILE, {})
    for it in items:
        if it.get('id') is None:
            continue
        old = store.get(str(it['id']))
        if old and old.get('torrents') and not it.get('torrents'):
            it = dict(it, torrents=old['torrents'])  # keep releases we already know
        if old and it.get('_placeholder'):
            for k in ('_tc_id', '_no_tc'):  # keep what we learnt when resolving it
                if k in old and k not in it:
                    it = dict(it, **{k: old[k]})
        store[str(it['id'])] = slim_item(it)
    if len(store) > MAX_CACHED_ITEMS:
        keep = sorted(store.items(), key=lambda kv: kv[1].get('_cached_at', 0))[-MAX_CACHED_ITEMS:]
        store = dict(keep)
    save_json(ITEMS_FILE, store)


def get_item(cid):
    store = load_json(ITEMS_FILE, {})
    item = store.get(str(cid))
    if item and item.get('_tc_id') is not None:
        # a TMDb placeholder already matched to a TorrentClaw title
        return store.get(str(item['_tc_id'])) or item
    return item


def _norm(s):
    return re.sub(r'[^a-z0-9]+', '', (s or '').lower())


def _year_ok(a, b, slack=1):
    try:
        return abs(int(a) - int(b)) <= slack
    except (TypeError, ValueError):
        return True  # unknown year on one side: do not reject on that alone


def _match_score(item, cand):
    """2 = same TMDb id, 1 = same title and year (+/-1), 0 = no match."""
    if cand.get('contentType') and cand.get('contentType') != item.get('contentType', 'movie'):
        return 0  # checked first: TMDb movie and TV ids can be the same number
    if item.get('tmdbId') and str(cand.get('tmdbId') or '') == str(item['tmdbId']):
        return 2
    names = set(n for n in (_norm(item.get('title')), _norm(item.get('titleOriginal'))) if n)
    cnames = set(n for n in (_norm(cand.get('title')), _norm(cand.get('titleOriginal'))) if n)
    if names & cnames and _year_ok(item.get('year'), cand.get('year')):
        return 1
    return 0


def resolve_item(item, force=False):
    """Turn a TMDb placeholder (Indian lists) into the matching TorrentClaw title.

    Returns the TorrentClaw item, or the placeholder (with '_no_tc' set) if
    TorrentClaw has nothing for it."""
    if not item or not item.get('_placeholder'):
        return item
    if not force and item.get('_no_tc') and time.time() - item['_no_tc'] < NO_MATCH_RETRY:
        return item
    tc = TorrentClaw()
    queries = []
    for q in (item.get('title'), item.get('titleOriginal')):
        if q and q.strip() and q.strip().lower() not in [x.lower() for x in queries]:
            queries.append(q.strip())
    best, best_score = None, 0
    for q in queries:
        for year in ((item.get('year'), None) if item.get('year') else (None,)):
            try:
                page = tc.search(q, ctype=item.get('contentType') or 'movie', limit=20, year=year)
            except ApiError as e:
                log('TorrentClaw lookup of %s failed: %s' % (q, e))
                continue
            for cand in page.items:
                sc = _match_score(item, cand)
                if sc > best_score:
                    best, best_score = cand, sc
            if best_score == 2 or (best_score and year):
                break
        if best_score:
            break
    store = load_json(ITEMS_FILE, {})
    ph = dict(store.get(str(item['id'])) or item)
    if best:
        merged = dict(best)
        for k in ('posterUrl', 'backdropUrl', 'overview', 'tmdbId', 'year'):
            if not merged.get(k) and item.get(k):
                merged[k] = item[k]
        for k in ('ratingImdb', 'imdbId'):  # IMDb score/id fetched for author lists
            if not merged.get(k) and item.get(k):
                merged[k] = item[k]
        if not imdb_rating(merged) and item.get('ratingTmdb'):
            merged['ratingTmdb'] = item['ratingTmdb']
        cache_items([merged])
        ph['_tc_id'] = best['id']
        ph.pop('_no_tc', None)
        log('Matched "%s" (%s) to TorrentClaw id %s' % (item.get('title'), item.get('year'), best['id']))
    else:
        ph['_no_tc'] = int(time.time())
        log('"%s" (%s) is not on TorrentClaw' % (item.get('title'), item.get('year')))
    store = load_json(ITEMS_FILE, {})
    store[str(item['id'])] = ph
    save_json(ITEMS_FILE, store)
    if best:
        return get_item(best['id']) or best
    return ph


def load_item(cid, force=False):
    """get_item() plus resolving Indian-list placeholders. None if the list expired."""
    item = get_item(cid)
    if item and item.get('_placeholder'):
        progress = xbmcgui.DialogProgressBG()
        progress.create('TorrentClaw', 'Looking up %s...' % (item.get('title') or ''))
        try:
            item = resolve_item(item, force=force)
        finally:
            progress.close()
    return item


def not_on_tc(item):
    notify('"%s" is not on TorrentClaw yet' % (item.get('title') or 'This film'))


def ensure_torrents(item, force=False):
    """Make sure the item has its torrent list (listing endpoints may omit it)."""
    if item.get('torrents') and not force:
        return item
    tc = TorrentClaw()
    page = tc.search(item.get('title') or item.get('titleOriginal') or '', ctype=item.get('contentType'),
                     limit=10, year=item.get('year'))
    match = None
    for r in page.items:
        if r.get('id') == item.get('id') or (item.get('imdbId') and r.get('imdbId') == item.get('imdbId')):
            match = r
            break
    if match:
        merged = dict(item)
        merged.update(match)
        cache_items([merged])
        return get_item(merged['id']) or merged
    return item


# ====================================================================== formatting
def imdb_rating(item):
    for k in ('ratingImdb', 'rating', 'ratingTmdb'):
        try:
            v = float(item.get(k))
            if v > 0:
                return v
        except (TypeError, ValueError):
            pass
    return None


def rating_tag(item):
    r = imdb_rating(item)
    if r is None:
        return ''
    src = 'IMDb' if item.get('ratingImdb') else 'TMDB'
    return '[COLOR gold]%s %.1f[/COLOR]' % (src, r)


def fmt_size(b):
    try:
        b = float(b)
    except (TypeError, ValueError):
        return '?'
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if b < 1024 or unit == 'TB':
            return ('%.1f %s' % (b, unit)) if unit in ('GB', 'TB') else ('%d %s' % (b, unit))
        b /= 1024.0


def quality_label(t):
    r = quality_rank(t)
    if r >= 2160:
        return '4K'
    if r:
        return '%dp' % r
    return (t.get('quality') or 'SD').upper()


def ep_label(t):
    s, e = t.get('season'), t.get('episode')
    if s is not None and e is not None:
        return 'S%02dE%02d' % (int(s), int(e))
    if s is not None:
        return 'S%02d pack' % int(s)
    return ''


def torrent_summary(t, with_seeds=True):
    parts = [quality_label(t)]
    for v in (t.get('sourceType'), t.get('codec'), _hdr(t)):
        if v:
            parts.append(str(v).upper())
    s = ' '.join(parts) + '  ·  ' + fmt_size(t.get('sizeBytes'))
    if with_seeds:
        s += '  ·  %s seeds' % (t.get('seeders') if t.get('seeders') is not None else '?')
    langs = torrent_langs(t)
    if langs:
        s += '  ·  ' + ' '.join(l.upper() for l in langs[:7])
    return s


def torrent_label(t, item, cached=None):
    pre = ''
    if cached:
        pre = '[COLOR springgreen][CACHED][/COLOR] '
    el = ep_label(t)
    if el:
        pre += '[B]%s[/B] ' % el
    lab = pre + '[B]%s[/B]' % torrent_summary(t)
    have = release_sub_langs(t)
    if 'en' in have:
        lab += '  ·  [COLOR grey]EN subs[/COLOR]'
    elif setting_bool('subs_enabled'):
        lab += '  ·  [COLOR orange]no EN subs[/COLOR]'
    rt = rating_tag(item)
    if rt:
        lab += '  ·  ' + rt
    return lab


# ====================================================================== filtering
def threat_bad(t):
    lvl = (t.get('threatLevel') or '').lower()
    return any(w in lvl for w in ('malic', 'danger', 'suspic', 'infect'))


def filter_torrents(torrents, lang=None):
    lang = lang if lang is not None else LANG_CODES[setting_int('lang_filter', 0)] if 0 <= setting_int('lang_filter', 0) < len(LANG_CODES) else ''
    minq = MIN_QUALITY[setting_int('min_quality', 0)] if 0 <= setting_int('min_quality', 0) < len(MIN_QUALITY) else 0
    hide_dead = setting_bool('hide_dead')
    out = []
    for t in torrents or []:
        if threat_bad(t):
            continue
        if hide_dead and (t.get('seeders') or 0) <= 0:
            continue
        if minq and quality_rank(t) < minq:
            continue
        if lang and lang not in torrent_langs(t):
            continue
        out.append(t)
    mode = setting_int('torrent_sort', 0)
    if mode == 1:
        out.sort(key=lambda t: (t.get('seeders') or 0), reverse=True)
    elif mode == 2:
        out.sort(key=lambda t: (t.get('sizeBytes') or 0), reverse=True)
    else:
        out.sort(key=lambda t: (t.get('qualityScore') or 0, t.get('seeders') or 0), reverse=True)
    return out


def cache_status(torrents):
    if not setting_bool('check_cache') or not setting('pm_apikey'):
        return {}
    hashes = [info_hash(t) for t in torrents if info_hash(t)]
    if not hashes:
        return {}
    try:
        return Premiumize().check_cache(hashes)
    except ApiError as e:
        log('cache check failed: %s' % e)
        return {}


def tkey(t, idx):
    return info_hash(t) or 'i%d' % idx


def find_torrent(item, key):
    for i, t in enumerate(item.get('torrents') or []):
        if tkey(t, i) == key:
            return t
    return None


# ====================================================================== list items
def set_info(li, item, mediatype=None, plot=None):
    title = item.get('title') or item.get('titleOriginal') or ''
    mediatype = mediatype or ('tvshow' if item.get('contentType') == 'show' else 'movie')
    rating = imdb_rating(item)
    try:
        tag = li.getVideoInfoTag()
        tag.setMediaType(mediatype)
        tag.setTitle(title)
        if item.get('titleOriginal'):
            tag.setOriginalTitle(item['titleOriginal'])
        if item.get('year'):
            tag.setYear(int(item['year']))
        tag.setPlot(plot if plot is not None else (item.get('overview') or ''))
        if item.get('genres'):
            tag.setGenres(list(item['genres']))
        if item.get('originCountry'):
            tag.setCountries(list(item['originCountry']))
        if rating is not None:
            tag.setRatings({'imdb': (rating, 0)}, 'imdb')
        ids = {}
        if item.get('imdbId'):
            ids['imdb'] = item['imdbId']
            tag.setIMDBNumber(item['imdbId'])
        if item.get('tmdbId'):
            ids['tmdb'] = str(item['tmdbId'])
        if ids:
            tag.setUniqueIDs(ids, 'imdb' if 'imdb' in ids else 'tmdb')
    except AttributeError:  # Kodi 19 fallback
        info = {'mediatype': mediatype, 'title': title, 'plot': plot if plot is not None else (item.get('overview') or ''),
                'genre': item.get('genres') or [], 'imdbnumber': item.get('imdbId') or ''}
        if item.get('year'):
            info['year'] = int(item['year'])
        if rating is not None:
            info['rating'] = rating
        li.setInfo('video', info)
        if rating is not None:
            li.setRating('imdb', rating, 0, True)


def set_art(li, item):
    poster = item.get('posterUrl') or ICON
    li.setArt({'poster': poster, 'thumb': poster, 'icon': poster,
               'fanart': item.get('backdropUrl') or FANART})


def add_dir(label, params, icon=None, plot='', context=None, folder=True):
    li = xbmcgui.ListItem(label=label, offscreen=True)
    li.setArt({'icon': icon or ICON, 'thumb': icon or ICON, 'fanart': FANART})
    try:
        li.getVideoInfoTag().setPlot(plot)
    except AttributeError:
        li.setInfo('video', {'plot': plot})
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, url_for(**params), li, folder)


def end_dir(content='videos', cache=False):
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)


# ====================================================================== menus
def main_menu():
    add_dir('Popular Movies', {'action': 'list', 'src': 'popular', 'type': 'movie'})
    add_dir('Popular TV Shows', {'action': 'list', 'src': 'popular', 'type': 'show'})
    add_dir('Latest Movies', {'action': 'list', 'src': 'recent', 'type': 'movie'})
    add_dir('Latest TV Shows', {'action': 'list', 'src': 'recent', 'type': 'show'})
    add_dir('Trending Today', {'action': 'list', 'src': 'trending', 'period': 'daily'})
    add_dir('Trending This Week', {'action': 'list', 'src': 'trending', 'period': 'weekly'})
    add_dir('Indian Movies', {'action': 'indian_menu'},
            plot='Latest and popular Hindi, Malayalam, Tamil, Telugu and Kannada films, plus any film with an Indian-language audio track.')
    add_dir('East Asian Movies', {'action': 'east_asia_menu'},
            plot='Best, popular and latest Chinese, Japanese, Hong Kong and Korean films.')
    add_dir('Search Movies', {'action': 'search', 'type': 'movie'},
            plot='Search by title, actor, director, author or keyword, or use the advanced filter.')
    add_dir('Search TV Shows', {'action': 'search', 'type': 'show'},
            plot='Search by title, actor, director, author or keyword, or use the advanced filter.\n'
                 'Tip: type "Show name S01E05" to search a specific episode.')
    add_dir('Search All Torrent Sites', {'action': 'sites_menu', 'mode': 'sites'},
            plot='Search many torrent sites at once (The Pirate Bay, YTS, Nyaa, 1337x, LimeTorrents, Knaben) '
                 'by title, actor, director, author or keyword, or with the advanced filter, and add a release to Premiumize.')
    add_dir('My TMDb Watchlist', {'action': 'tmdb_watchlist_menu'},
            plot='Films and shows you added to your TMDb watchlist (long-press any title > Add to TMDb watchlist).')
    add_dir('Premiumize Transfers', {'action': 'transfers'},
            plot='See what is downloading in your Premiumize cloud.')
    add_dir('Settings / Test connection', {'action': 'settings'}, folder=False)
    end_dir('files')


def indian_menu():
    tm = TMDb()
    if not tm.configured:
        add_dir('[COLOR orange]Add a TMDb API key in settings to list Indian films[/COLOR]',
                {'action': 'settings'}, folder=False,
                plot='Settings > Accounts > TMDb API key. It is free from themoviedb.org. '
                     'If the Premiumize Library add-on is installed with a key, it is used automatically.')
    add_dir('Latest Indian Movies', {'action': 'indian', 'src': 'latest'},
            plot='Newest Hindi, Malayalam, Tamil, Telugu and Kannada films (from TMDb). '
                 'Releases are looked up on TorrentClaw when you open one.')
    add_dir('Popular Indian Movies', {'action': 'indian', 'src': 'popular'},
            plot='Most popular Indian films right now (from TMDb).')
    add_dir('Best Indian Movies', {'action': 'indian', 'src': 'best'},
            plot='Highest-rated Indian films on TMDb.')
    for code in INDIAN_LANGS:
        add_dir('%s Movies' % LANG_NAMES[code], {'action': 'indian_lang', 'lang': code},
                plot='Latest and popular films made in %s.' % LANG_NAMES[code])
    for code in INDIAN_LANGS:
        add_dir('Any film with %s audio' % LANG_NAMES[code], {'action': 'dubbed', 'lang': code},
                plot='Every film on TorrentClaw that has a %s audio track, including dubbed '
                     'Hollywood and other-language films.' % LANG_NAMES[code])
    end_dir('files')


def indian_lang_menu(lang):
    name = LANG_NAMES.get(lang, lang)
    add_dir('Latest %s Movies' % name, {'action': 'indian', 'src': 'latest', 'lang': lang})
    add_dir('Popular %s Movies' % name, {'action': 'indian', 'src': 'popular', 'lang': lang})
    add_dir('Best %s Movies' % name, {'action': 'indian', 'src': 'best', 'lang': lang})
    add_dir('Any film with %s audio' % name, {'action': 'dubbed', 'lang': lang})
    end_dir('files')


# ====================================================================== title listings
def title_context(item):
    cid = item['id']
    ctx = [('Add to Premiumize cloud...', run_plugin(action='add_pick', id=cid)),
           ('Add best release to cloud', run_plugin(action='add_best', id=cid)),
           ('Show all releases', 'Container.Update(%s)' % url_for(action='torrents', id=cid))]
    if item.get('contentType') == 'show':
        ctx.append(('Find a specific episode...', run_plugin(action='episode_search', id=cid)))
    title = item.get('title') or item.get('titleOriginal') or ''
    ctype = 'show' if item.get('contentType') == 'show' else 'movie'
    if title:
        ctx.append(('Search TorrentClaw for this title',
                    'Container.Update(%s)' % url_for(action='search', type=ctype, q=title)))
    if item.get('tmdbId'):
        ctx.append(('Add to TMDb watchlist', run_plugin(action='tmdb_watch', mt='tv' if ctype == 'show' else 'movie',
                                                      tid=item['tmdbId'], title=title)))
        if ctype == 'movie':
            ctx.append(('Add to a TMDb list...', run_plugin(action='tmdb_list_add', tid=item['tmdbId'], title=title)))
    return ctx


def add_title(item, lang=None, tag_tv=False, keep_all=False):
    """keep_all: TMDb-based lists (author, keyword, watchlist) always show every title,
    marked when TorrentClaw has nothing for it, instead of hiding it."""
    if SITES:
        return add_site_title(item, tag_tv)
    torrents = item.get('torrents')
    filtered = filter_torrents(torrents, lang) if torrents else []
    hidden_by_filters = bool(torrents is not None and len(torrents) and not filtered)
    if hidden_by_filters and not keep_all:
        return False  # all releases hidden by filters
    if item.get('hasTorrents') is False and setting_bool('hide_no_torrents') and not keep_all:
        return False
    title = item.get('title') or item.get('titleOriginal') or 'Unknown'
    label = '%s (%s)' % (title, item['year']) if item.get('year') else title
    if tag_tv and item.get('contentType') == 'show':
        label = '[COLOR grey][TV][/COLOR] ' + label
    rt = rating_tag(item)
    if rt:
        label += '  ' + rt
    if item.get('_no_tc'):
        if setting_bool('hide_no_torrents') and not keep_all:
            return False
        label += '  [COLOR grey](not on TorrentClaw yet)[/COLOR]'
    elif hidden_by_filters:
        label += '  [COLOR grey](no releases match your filters)[/COLOR]'
    elif keep_all and item.get('hasTorrents') is False:
        label += '  [COLOR grey](no releases yet)[/COLOR]'
    if filtered:
        label += '  [COLOR grey]%s[/COLOR]' % quality_label(filtered[0])
    plot = item.get('overview') or ''
    if filtered:
        plot += '\n\n[B]Best release:[/B] %s' % torrent_summary(filtered[0])
        plot += '\n%d release(s) available' % len(filtered)
    li = xbmcgui.ListItem(label=label, offscreen=True)
    set_art(li, item)
    set_info(li, item, plot=plot)
    li.addContextMenuItems(title_context(item))
    xbmcplugin.addDirectoryItem(HANDLE, url_for(action='torrents', id=item['id'], lang=lang), li, True)
    return True


def list_titles(items, next_params=None, content='movies', lang=None, empty_msg=None, tag_tv=False,
                keep_all=False):
    seen, unique = set(), []
    for i in items:
        if i.get('id') is not None and i['id'] not in seen:
            seen.add(i['id'])
            unique.append(i)
    items = unique
    cache_items(items)
    store = None
    for n, it in enumerate(items):
        if it.get('_placeholder') and not SITES:
            store = store if store is not None else load_json(ITEMS_FILE, {})
            ph = store.get(str(it['id'])) or it
            if ph.get('_tc_id') is not None and store.get(str(ph['_tc_id'])):
                items[n] = store[str(ph['_tc_id'])]  # already matched: show its releases
            elif ph.get('_no_tc'):
                items[n] = ph
    shown = 0
    for it in items:
        if add_title(it, lang, tag_tv, keep_all):
            shown += 1
    if next_params:
        add_dir('[B]Next page >>[/B]', next_params)
    if not shown and not next_params:
        notify(empty_msg or 'Nothing found')
    end_dir(content)


def do_list(src, ctype=None, period=None, page=1):
    tc = TorrentClaw()
    if src == 'popular':
        res = tc.popular(ctype, page)
    elif src == 'recent':
        res = tc.recent(ctype, page)
    else:
        res = tc.trending(period or 'daily', ctype, page)
    if res.notice and not tc.key:
        notify('Add your TorrentClaw API key in settings to get magnet links')
    nxt = {'action': 'list', 'src': src, 'type': ctype, 'period': period, 'page': page + 1} if res.has_more else None
    list_titles(res.items, nxt, 'tvshows' if ctype == 'show' else 'movies')


def _key_warning():
    add_dir('[COLOR orange]Add a TMDb API key in settings to list these films[/COLOR]',
            {'action': 'settings'}, folder=False,
            plot='Settings > Accounts > TMDb API key. It is free from themoviedb.org. '
                 'If the Premiumize Library add-on is installed with a key, it is used automatically.')


def east_asia_menu():
    if not TMDb().configured:
        _key_warning()
    for region in EAST_ASIA:
        name = REGIONS[region]['name']
        add_dir('%s Movies' % name, {'action': 'region_menu', 'region': region},
                plot='Best, popular and latest %s films.' % name)
    end_dir('files')


def region_menu(region):
    name = REGIONS.get(region, REGIONS['in'])['name']
    add_dir('Best %s Movies' % name, {'action': 'world', 'region': region, 'src': 'best'},
            plot='Highest-rated %s films on TMDb.' % name)
    add_dir('Popular %s Movies' % name, {'action': 'world', 'region': region, 'src': 'popular'},
            plot='Most popular %s films right now.' % name)
    add_dir('Latest %s Movies' % name, {'action': 'world', 'region': region, 'src': 'latest'},
            plot='Newest released %s films. Very new ones may not be on TorrentClaw yet.' % name)
    end_dir('files')


def do_world(region='in', src='latest', lang=None, page=1, action='world'):
    """Films from TMDb discover; TorrentClaw releases are looked up on open."""
    tm = TMDb()
    if not tm.configured:
        notify('Add a TMDb API key in settings to list these films')
        return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    sort = src if src in ('popular', 'best') else 'latest'
    items, has_more = tm.discover(region, sort, lang, page)
    nxt = None
    if has_more:
        nxt = {'action': action, 'src': src, 'lang': lang, 'page': page + 1}
        if action == 'world':
            nxt['region'] = region
    list_titles(items, nxt, 'movies', empty_msg='TMDb returned no films')


def do_indian(src='latest', lang=None, page=1):
    do_world('in', src, lang, page, action='indian')


def do_dubbed(lang, page=1):
    """TorrentClaw search filtered by audio language, with no search words."""
    tc = TorrentClaw()
    res = tc.search('', ctype='movie', page=page, lang=lang)
    nxt = {'action': 'dubbed', 'lang': lang, 'page': page + 1} if res.has_more else None
    list_titles(res.items, nxt, 'movies', lang=lang,
                empty_msg='No films with %s audio found' % LANG_NAMES.get(lang, lang))


# ====================================================================== search
def search_root(ctype):
    what = 'shows' if ctype == 'show' else 'films'
    add_dir('[B]New search...[/B]', {'action': 'search_new', 'type': ctype},
            plot='Search by title.')
    add_dir('[B]Search by actor...[/B]', {'action': 'person_new', 'type': ctype, 'role': 'actor'},
            plot='Type an actor\'s name to list their main %s, highest rated first (from TMDb). '
                 'Releases are looked up on TorrentClaw when you open one.' % what)
    add_dir('[B]Search by director...[/B]', {'action': 'person_new', 'type': ctype, 'role': 'director'},
            plot='Type a director\'s name to list the %s they directed, highest rated first (from TMDb). '
                 'Releases are looked up on TorrentClaw when you open one.' % what)
    add_dir('[B]Search by author...[/B]', {'action': 'person_new', 'type': ctype, 'role': 'author'},
            plot='Type a writer\'s name (for example Raymond Chandler or Keigo Higashino) to list films and '
                 'shows based on their novels, stories, screenplays or characters, highest IMDb score first. '
                 'Open a title to see its TorrentClaw releases.')
    add_dir('[B]Search by keyword...[/B]', {'action': 'keyword_new', 'type': ctype},
            plot='Type a tag word, for example "time travel", "film noir" or "heist", pick the matching TMDb '
                 'keyword, and see the best-known titles with it, highest IMDb score first.')
    add_dir('[B]Advanced filter...[/B]', {'action': 'filter_new', 'type': ctype},
            plot='Pick a language, a genre and a decade, for example English thrillers from the 1980s. '
                 'Results are sorted by IMDb score, highest first.')
    store = load_json(HISTORY_FILE, {})
    for f in store.get(FILTER_FAV_KEY % ctype, []):
        add_dir('[COLOR gold]★[/COLOR] %s' % filter_label(f.get('lang'), f.get('genre'), f.get('decade')),
                dict(action='filter', type=ctype, lang=f.get('lang'), genre=f.get('genre'), decade=f.get('decade')),
                context=[('Remove from favourites', run_plugin(action='filter_fav_del', type=ctype, lang=f.get('lang'),
                                                               genre=f.get('genre'), decade=f.get('decade')))])
    for p in store.get(PEOPLE_KEY % ctype, []):
        role = p.get('role') or 'actor'
        label = '[COLOR grey]%s:[/COLOR] %s' % (role.title(), p.get('name') or '')
        if role == 'author':
            label += '  [COLOR grey]%s[/COLOR]' % AUTHOR_SCOPE_NAMES.get(p.get('scope') or ctype, '')
        add_dir(label,
                {'action': 'person', 'type': ctype, 'role': role, 'pid': p.get('pid'), 'name': p.get('name'),
                 'scope': p.get('scope')},
                icon=p.get('photo') or None,
                context=[('Remove from history', run_plugin(action='person_history_del', type=ctype,
                                                            role=role, pid=p.get('pid')))])
    for k in store.get(KEYWORD_KEY % ctype, []):
        add_dir('[COLOR grey]Keyword:[/COLOR] %s  [COLOR grey]%s[/COLOR]' % (k.get('name') or '',
                                                                       AUTHOR_SCOPE_NAMES.get(k.get('scope') or ctype, '')),
                {'action': 'keyword', 'type': ctype, 'kid': k.get('kid'), 'name': k.get('name'), 'scope': k.get('scope')},
                context=[('Remove from history', run_plugin(action='keyword_history_del', type=ctype, kid=k.get('kid')))])
    hist = store.get(_hkey(ctype), [])
    for q in hist:
        add_dir(q, {'action': 'search', 'type': ctype, 'q': q},
                context=[('Remove from history', run_plugin(action='history_del', type=ctype, q=q))])
    end_dir('files')


def search_new(ctype):
    heading = 'Search TV shows' if ctype == 'show' else 'Search movies'
    # close this action first (as the actor/director search does); doing it after the
    # keyboard made Kodi drop the Container.Update below, so the search never ran
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    q = xbmcgui.Dialog().input(heading).strip()
    if not q:
        return
    store = load_json(HISTORY_FILE, {})
    hist = [h for h in store.get(_hkey(ctype), []) if h.lower() != q.lower()]
    store[_hkey(ctype)] = ([q] + hist)[:20]
    save_json(HISTORY_FILE, store)
    xbmc.executebuiltin('Container.Update(%s)' % url_for(action='search', type=ctype, q=q))


def history_del(ctype, q):
    store = load_json(HISTORY_FILE, {})
    store[_hkey(ctype)] = [h for h in store.get(_hkey(ctype), []) if h != q]
    save_json(HISTORY_FILE, store)
    xbmc.executebuiltin('Container.Refresh')


def do_search(ctype, q, page=1):
    if SITES:
        return sites_results(q, ctype)
    tc = TorrentClaw()
    idx = setting_int('lang_filter', 0)
    lang = LANG_CODES[idx] if 0 <= idx < len(LANG_CODES) else ''
    res = tc.search(q, ctype=ctype, page=page, lang=lang or None)
    nxt = {'action': 'search', 'type': ctype, 'q': q, 'page': page + 1} if res.has_more else None
    list_titles(res.items, nxt, 'tvshows' if ctype == 'show' else 'movies',
                empty_msg='No results for "%s"' % q)


# ---------------------------------------------------------------------- actor / director search
PEOPLE_KEY = 'people_%s'  # search-history key per content type
PEOPLE_PAGE = 50


def person_new(ctype, role):
    """Ask for a name, pick the right person, then open their film/show list."""
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    tm = TMDb()
    if not tm.configured:
        return notify('Add a TMDb API key in settings to search by actor, director or author')
    q = xbmcgui.Dialog().input('Search %s name' % role).strip()
    if not q:
        return
    progress = xbmcgui.DialogProgressBG()
    progress.create('TorrentClaw', 'Looking up %s...' % q)
    try:
        people = tm.search_people(q)
    finally:
        progress.close()
    if not people:
        return notify('No one called "%s" found on TMDb' % q)
    # put people known for the role being searched first, keeping TMDb's order otherwise
    dept = {'director': 'Directing', 'author': 'Writing'}.get(role, 'Acting')
    people.sort(key=lambda p: p.get('known_for_department') != dept)
    if len(people) == 1:
        person = people[0]
    else:
        choices = []
        for p in people[:25]:
            li = xbmcgui.ListItem(label=p.get('name') or '', label2=person_label(p), offscreen=True)
            photo = person_photo(p)
            if photo:
                li.setArt({'icon': photo, 'thumb': photo})
            choices.append(li)
        idx = xbmcgui.Dialog().select('Which %s?' % role, choices, useDetails=True)
        if idx < 0:
            return
        person = people[idx]
    entry = {'pid': person['id'], 'name': person.get('name') or q, 'role': role, 'photo': person_photo(person)}
    if role == 'author':
        keys = ['movie', 'show', 'both']
        i = xbmcgui.Dialog().select('%s: what should I list?' % entry['name'],
                                    [AUTHOR_SCOPE_NAMES[k] for k in keys], preselect=0 if ctype == 'movie' else 1)
        if i < 0:
            return
        entry['scope'] = keys[i]
    store = load_json(HISTORY_FILE, {})
    key = PEOPLE_KEY % ctype
    hist = [h for h in store.get(key, []) if not (h.get('pid') == entry['pid'] and h.get('role') == role)]
    store[key] = ([entry] + hist)[:20]
    save_json(HISTORY_FILE, store)
    xbmc.executebuiltin('Container.Update(%s)' % url_for(action='person', type=ctype, role=role,
                                                         pid=entry['pid'], name=entry['name'],
                                                         scope=entry.get('scope')))


def do_person(ctype, role, pid, name, page=1, scope=None):
    tm = TMDb()
    if not tm.configured:
        notify('Add a TMDb API key in settings to search by actor, director or author')
        return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    if role == 'author':
        return do_author(tm, ctype, pid, name, scope or ctype)
    items = tm.person_titles(pid, role, ctype)
    start = (page - 1) * PEOPLE_PAGE
    chunk = items[start:start + PEOPLE_PAGE]
    nxt = None
    if start + PEOPLE_PAGE < len(items):
        nxt = {'action': 'person', 'type': ctype, 'role': role, 'pid': pid, 'name': name, 'page': page + 1}
    what = 'shows' if ctype == 'show' else 'films'
    xbmcplugin.setPluginCategory(HANDLE, '%s - %s' % (name or '', what))
    list_titles(chunk, nxt, 'tvshows' if ctype == 'show' else 'movies',
                empty_msg='No main %s found for %s' % (what, name or 'this person'))


def person_history_del(ctype, role, pid):
    store = load_json(HISTORY_FILE, {})
    key = PEOPLE_KEY % ctype
    store[key] = [h for h in store.get(key, []) if not (str(h.get('pid')) == str(pid) and h.get('role') == role)]
    save_json(HISTORY_FILE, store)
    xbmc.executebuiltin('Container.Refresh')


# ---------------------------------------------------------------------- author search
AUTHOR_SCOPE_NAMES = {'movie': 'Movies', 'show': 'TV shows', 'both': 'Movies and TV shows'}
AUTHOR_SCOPES = {'movie': ['movie'], 'show': ['show'], 'both': ['movie', 'show']}
IMDB_CACHE = 'imdb_scores.json'
IMDB_TTL = 14 * 24 * 3600           # IMDb score kept this long
IMDB_MISS_TTL = 3 * 24 * 3600       # "no IMDb id / no score" retried after this long
IMDB_WORKERS = 4


def add_imdb_scores(items):
    """Fill imdbId / ratingImdb on TMDb items (TMDb external id + OMDb score), cached.

    Returns a short note for the user when scores could not be fetched, else ''."""
    from concurrent.futures import ThreadPoolExecutor
    om, tm = OMDb(), TMDb()
    cache = load_json(IMDB_CACHE, {})
    now = time.time()
    state = {'limit': False, 'error': None}

    def key(it):
        return '%s:%s' % (it.get('contentType'), it.get('tmdbId'))

    def fresh(entry):
        ttl = IMDB_TTL if entry.get('r') else IMDB_MISS_TTL
        return now - entry.get('t', 0) < ttl

    def one(it):
        k = key(it)
        hit = cache.get(k)
        if hit and fresh(hit):
            return k, hit
        try:
            imdb = (hit or {}).get('imdb') or tm.imdb_id(it.get('contentType'), it['tmdbId'])
            entry = {'imdb': imdb, 'r': None, 'v': 0, 't': int(now)}
            if imdb and om.configured and not state['limit']:
                entry.update(om.rating(imdb))
            return k, entry
        except OMDbLimit:
            state['limit'] = True
        except ApiError as e:
            state['error'] = e
        return k, None

    todo = [it for it in items if it.get('tmdbId')]
    with ThreadPoolExecutor(max_workers=IMDB_WORKERS) as pool:
        results = dict(pool.map(one, todo))
    changed = False
    for it in todo:
        entry = results.get(key(it))
        if entry is None:
            continue
        if entry is not cache.get(key(it)):
            cache[key(it)] = entry
            changed = True
        if entry.get('imdb'):
            it['imdbId'] = entry['imdb']
        if entry.get('r'):
            it['ratingImdb'] = entry['r']
            it['_imdb_votes'] = entry.get('v') or 0
    if changed:
        save_json(IMDB_CACHE, cache)
    if not om.configured:
        return 'Add an OMDb key in settings for IMDb scores (sorted by TMDb score for now)'
    if state['limit']:
        return 'OMDb daily limit reached: some titles are sorted by TMDb score'
    if state['error']:
        log('IMDb scores: %s' % state['error'])
    return ''


def _author_sort_key(it):
    imdb = float(it.get('ratingImdb') or 0)
    tmdb = float(it.get('ratingTmdb') or 0)
    return (imdb > 0, imdb if imdb > 0 else tmdb, it.get('_imdb_votes') or 0)


def do_author(tm, ctype, pid, name, scope):
    scope = scope if scope in AUTHOR_SCOPES else ctype
    progress = xbmcgui.DialogProgressBG()
    progress.create('TorrentClaw', 'Finding films and shows based on %s...' % (name or 'this author'))
    try:
        items = tm.author_titles(pid, AUTHOR_SCOPES[scope])
        progress.update(50, 'TorrentClaw', 'Getting IMDb scores...')
        note = add_imdb_scores(items)
    finally:
        progress.close()
    items.sort(key=_author_sort_key, reverse=True)
    if note:
        notify(note)
    content = {'movie': 'movies', 'show': 'tvshows'}.get(scope, 'videos')
    xbmcplugin.setPluginCategory(HANDLE, '%s - %s' % (name or '', AUTHOR_SCOPE_NAMES[scope]))
    list_titles(items, None, content, tag_tv=(scope == 'both'), keep_all=True,
                empty_msg='No films or shows based on %s\'s work found on TMDb' % (name or 'this author'))


# ---------------------------------------------------------------------- keyword (tag) search
KEYWORD_KEY = 'keywords_%s'   # search history per content type


def _ask_scope(heading, ctype):
    keys = ['movie', 'show', 'both']
    i = xbmcgui.Dialog().select(heading, [AUTHOR_SCOPE_NAMES[k] for k in keys], preselect=0 if ctype == 'movie' else 1)
    return keys[i] if i >= 0 else None


def keyword_new(ctype):
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    tm = TMDb()
    if not tm.configured:
        return notify('Add a TMDb API key in settings to search by keyword')
    q = xbmcgui.Dialog().input('Keyword (for example time travel)').strip()
    if not q:
        return
    try:
        found = tm.search_keywords(q)
    except ApiError as e:
        return notify(str(e))
    if not found:
        return notify('TMDb has no keyword like "%s"' % q)
    if len(found) == 1:
        kw = found[0]
    else:
        # exact match first, then the shortest (most general) names
        found.sort(key=lambda k: (k['name'].strip().lower() != q.lower(), len(k['name'])))
        i = xbmcgui.Dialog().select('Which keyword?', [k['name'] for k in found[:40]])
        if i < 0:
            return
        kw = found[i]
    scope = _ask_scope('"%s": what should I list?' % kw['name'], ctype)
    if not scope:
        return
    entry = {'kid': kw['id'], 'name': kw['name'], 'scope': scope}
    store = load_json(HISTORY_FILE, {})
    key = KEYWORD_KEY % ctype
    store[key] = ([entry] + [h for h in store.get(key, []) if str(h.get('kid')) != str(kw['id'])])[:20]
    save_json(HISTORY_FILE, store)
    xbmc.executebuiltin('Container.Update(%s)' % url_for(action='keyword', type=ctype, kid=kw['id'],
                                                         name=kw['name'], scope=scope))


def do_keyword(ctype, kid, name, scope):
    tm = TMDb()
    if not tm.configured:
        notify('Add a TMDb API key in settings to search by keyword')
        return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    scope = scope if scope in AUTHOR_SCOPES else ctype
    progress = xbmcgui.DialogProgressBG()
    progress.create('TorrentClaw', 'Finding titles with "%s"...' % (name or kid))
    try:
        items = []
        for c in AUTHOR_SCOPES[scope]:
            items += tm.keyword_titles(kid, c)
        progress.update(50, 'TorrentClaw', 'Getting IMDb scores...')
        note = add_imdb_scores(items)
    finally:
        progress.close()
    items.sort(key=_author_sort_key, reverse=True)
    if note:
        notify(note)
    content = {'movie': 'movies', 'show': 'tvshows'}.get(scope, 'videos')
    xbmcplugin.setPluginCategory(HANDLE, '%s - %s' % (name or '', AUTHOR_SCOPE_NAMES[scope]))
    list_titles(items, None, content, tag_tv=(scope == 'both'), keep_all=True,
                empty_msg='No titles with the keyword "%s"' % (name or kid))


def keyword_history_del(ctype, kid):
    store = load_json(HISTORY_FILE, {})
    key = KEYWORD_KEY % ctype
    store[key] = [h for h in store.get(key, []) if str(h.get('kid')) != str(kid)]
    save_json(HISTORY_FILE, store)
    xbmc.executebuiltin('Container.Refresh')


# ---------------------------------------------------------------------- TMDb account (watchlist, lists)
ACCOUNT_FILE = 'tmdb_account.json'


def tmdb_account(offer_connect=True):
    acct = load_json(ACCOUNT_FILE, {})
    if acct.get('session_id') and acct.get('account_id'):
        return acct
    if offer_connect and xbmcgui.Dialog().yesno('TorrentClaw', 'Your TMDb account is not connected yet.\n\n'
                                               'Connect it now? You approve it once on your phone or PC.'):
        return tmdb_connect()
    return None


def tmdb_connect():
    tm = TMDb()
    if not tm.configured:
        notify('Add a TMDb API key in settings first')
        return None
    d = xbmcgui.Dialog()
    try:
        token = tm.request_token()
    except ApiError as e:
        notify(str(e))
        return None
    url = 'https://www.themoviedb.org/authenticate/' + token
    d.ok('Connect TMDb account', 'On your phone or PC, open the address shown next, sign in to TMDb and press '
                                 '"Approve". Then come back and press OK.\n\n'
                                 'With the Kore app you can copy the address from the text box.')
    d.input('Open this address, approve, then press OK', defaultt=url)
    for _attempt in range(2):
        try:
            session = tm.create_session(token)
            info = tm.account(session)
            acct = {'session_id': session, 'account_id': info.get('id'),
                    'username': info.get('username') or ''}
            if not acct['account_id']:
                raise ApiError('TMDb did not return the account')
            save_json(ACCOUNT_FILE, acct)
            notify('TMDb account connected%s' % (': ' + acct['username'] if acct['username'] else ''))
            return acct
        except ApiError as e:
            log('TMDb connect: %s' % e)
            if not d.yesno('Connect TMDb account', 'TMDb has not seen the approval yet.\n\n'
                                                   'Approve it on themoviedb.org, then choose Try again.\n\n%s' % url,
                           nolabel='Cancel', yeslabel='Try again'):
                return None
    notify('TMDb account not connected. Try again from settings.')
    return None


def tmdb_disconnect():
    acct = load_json(ACCOUNT_FILE, {})
    if acct.get('session_id'):
        try:
            TMDb().delete_session(acct['session_id'])
        except ApiError as e:
            log('TMDb disconnect: %s' % e)
    save_json(ACCOUNT_FILE, {})
    notify('TMDb account disconnected')


def _tmdb_error(e):
    if getattr(e, 'code', None) == 401:
        save_json(ACCOUNT_FILE, {})
        notify('TMDb no longer accepts this connection. Connect your account again.')
    else:
        notify(str(e))


def tmdb_watch(media_type, tmdb_id, title=''):
    acct = tmdb_account()
    if not acct:
        return
    try:
        TMDb().watchlist_add(acct['session_id'], acct['account_id'], media_type, tmdb_id)
        notify('Added to your TMDb watchlist: %s' % (title or tmdb_id))
    except ApiError as e:
        _tmdb_error(e)


def tmdb_list_add(tmdb_id, title=''):
    acct = tmdb_account()
    if not acct:
        return
    tm, d = TMDb(), xbmcgui.Dialog()
    try:
        lists = tm.my_lists(acct['session_id'], acct['account_id'])
    except ApiError as e:
        return _tmdb_error(e)
    labels = ['[B]New list...[/B]'] + ['%s  [COLOR grey](%s)[/COLOR]' % (l.get('name') or '?', l.get('item_count', 0))
                                       for l in lists]
    i = d.select('Add "%s" to which TMDb list?' % (title or tmdb_id), labels)
    if i < 0:
        return
    try:
        if i == 0:
            name = d.input('Name of the new list').strip()
            if not name:
                return
            list_id = tm.create_list(acct['session_id'], name)
            if not list_id:
                return notify('TMDb did not create the list')
        else:
            list_id, name = lists[i - 1]['id'], lists[i - 1].get('name') or ''
        tm.list_add(acct['session_id'], list_id, tmdb_id)
        notify('Added to "%s": %s' % (name, title or tmdb_id))
    except ApiError as e:
        if 'duplicate' in str(e).lower() or 'already' in str(e).lower():
            notify('Already in "%s"' % name)
        else:
            _tmdb_error(e)


def tmdb_watchlist_menu():
    add_dir('Watchlist - Movies', {'action': 'tmdb_watchlist', 'type': 'movie'})
    add_dir('Watchlist - TV Shows', {'action': 'tmdb_watchlist', 'type': 'show'})
    add_dir('Connect / reconnect TMDb account', {'action': 'tmdb_connect'}, folder=False)
    end_dir('files')


def do_tmdb_watchlist(ctype, page=1):
    acct = tmdb_account()
    if not acct:
        return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    try:
        items, has_more = TMDb().watchlist(acct['session_id'], acct['account_id'], ctype, page)
    except ApiError as e:
        _tmdb_error(e)
        return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    nxt = {'action': 'tmdb_watchlist', 'type': ctype, 'page': page + 1} if has_more else None
    list_titles(items, nxt, 'tvshows' if ctype == 'show' else 'movies', empty_msg='Your TMDb watchlist is empty',
                keep_all=True)


# ---------------------------------------------------------------------- advanced filter
FILTER_FILE = 'filter_results.json'
FILTER_FAV_KEY = 'filters_%s'          # saved favourites per content type, in HISTORY_FILE
FILTER_TTL = 6 * 3600                  # re-ask TorrentClaw after this long
FILTER_PAGE = 50                       # titles per Kodi page
FILTER_TOP = 200                       # titles kept per filter, re-sorted by IMDb
FILTER_FETCH_PAGES = 2                 # TorrentClaw pages (of 50) fetched per country
FILTER_WORKERS = 4                     # parallel TorrentClaw requests
FILTER_MAX_CACHED = 8                  # filter result lists kept on disk

# Language = films made in these countries that also have this audio track.
# TorrentClaw has no original-language filter; country of origin + audio is the closest.
FILTER_LANGS = [
    ('en', 'English', ['US', 'GB', 'CA', 'AU', 'IE', 'NZ']),
    ('hi', 'Hindi', ['IN']),
    ('ml', 'Malayalam', ['IN']),
    ('ta', 'Tamil', ['IN']),
    ('te', 'Telugu', ['IN']),
    ('kn', 'Kannada', ['IN']),
    ('ko', 'Korean', ['KR']),
    ('ja', 'Japanese', ['JP']),
    ('zh', 'Chinese', ['CN', 'HK', 'TW']),
]
# Hide titles with few votes only where plenty of well-known titles exist; older
# regional films often have few votes and would vanish.
FILTER_VOTES_MIN = {'en': '1000'}
# "Art house" is not a TorrentClaw genre: it comes from TMDb's art house keyword instead
# (titles are looked up on TorrentClaw when opened, like the Indian lists).
ARTHOUSE = 'Art house'
ARTHOUSE_QUERIES = ('art house', 'arthouse')
ARTHOUSE_NAMES = ('art house', 'arthouse', 'art house film', 'arthouse film', 'art house cinema', 'art film')
ARTHOUSE_TMDB_LANGS = {'zh': ['zh', 'cn']}   # TMDb: zh Mandarin, cn Cantonese
ARTHOUSE_MIN_VOTES = {'en': 20}              # others: 3
ARTHOUSE_PAGES = 10                          # TMDb pages of 20 = up to 200 titles
MOVIE_GENRES = ['Action', 'Adventure', 'Animation', 'Anime', ARTHOUSE, 'Comedy', 'Crime', 'Documentary',
                'Drama', 'Family', 'Fantasy', 'History', 'Horror', 'Music', 'Mystery', 'Romance',
                'Science Fiction', 'Thriller', 'War', 'Western']
SHOW_GENRES = ['Action & Adventure', 'Animation', 'Anime', ARTHOUSE, 'Comedy', 'Crime', 'Documentary',
               'Drama', 'Family', 'Kids', 'Mystery', 'Reality', 'Sci-Fi & Fantasy', 'Soap',
               'War & Politics', 'Western']
# (key, label, year_min, year_max)
DECADES = [('2020', '2020s', 2020, 2029), ('2010', '2010s', 2010, 2019), ('2000', '2000s', 2000, 2009),
           ('1990', '1990s', 1990, 1999), ('1980', '1980s', 1980, 1989), ('1970', '1970s', 1970, 1979),
           ('1960', '1960s', 1960, 1969), ('1950', '1950s', 1950, 1959), ('old', 'Before 1950', 1900, 1949)]


def _filter_lang(code):
    for c, name, countries in FILTER_LANGS:
        if c == code:
            return c, name, countries
    return None


def _decade(key):
    for d in DECADES:
        if d[0] == key:
            return d
    return None


def filter_label(lang, genre, decade):
    lg, dc = _filter_lang(lang), _decade(decade)
    return '%s · %s · %s' % (lg[1] if lg else lang, genre or '?', dc[1] if dc else decade)


def filter_new(ctype):
    """Ask language, genre and decade, then open the result list."""
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    d = xbmcgui.Dialog()
    i = d.select('Language', [name for _c, name, _cs in FILTER_LANGS])
    if i < 0:
        return
    lang = FILTER_LANGS[i][0]
    genres = SHOW_GENRES if ctype == 'show' else MOVIE_GENRES
    j = d.select('Genre', genres)
    if j < 0:
        return
    k = d.select('Decade', [x[1] for x in DECADES])
    if k < 0:
        return
    xbmc.executebuiltin('Container.Update(%s)' % url_for(action='filter', type=ctype, lang=lang,
                                                         genre=genres[j], decade=DECADES[k][0]))


def _imdb_sort_key(item):
    """True IMDb order: titles with an IMDb score first, by score; then the rest by TMDb score."""
    try:
        imdb = float(item.get('ratingImdb') or 0)
    except (TypeError, ValueError):
        imdb = 0.0
    try:
        tmdb = float(item.get('ratingTmdb') or 0)
    except (TypeError, ValueError):
        tmdb = 0.0
    return (imdb > 0, imdb if imdb > 0 else tmdb, tmdb)


def fetch_arthouse(ctype, code, dc):
    """Art house titles from TMDb (keyword), best TMDb rating first. Returns placeholders."""
    from concurrent.futures import ThreadPoolExecutor
    tm = TMDb()
    if not tm.configured:
        raise ApiError('Add a TMDb API key in settings to use the Art house filter')
    ids = tm.keyword_ids(ARTHOUSE_QUERIES, ARTHOUSE_NAMES)
    if not ids:
        raise ApiError('TMDb has no "art house" tag right now')
    langs = ARTHOUSE_TMDB_LANGS.get(code, [code])
    votes = ARTHOUSE_MIN_VOTES.get(code, 3)

    def one(page):
        try:
            return tm.discover_keywords(ctype, ids, langs, dc[2], dc[3], page, votes)[0], None
        except ApiError as e:
            return [], e

    with ThreadPoolExecutor(max_workers=FILTER_WORKERS) as pool:
        results = list(pool.map(one, range(1, ARTHOUSE_PAGES + 1)))
    seen, merged = set(), []
    for items, _e in results:
        for it in items:
            if it['id'] not in seen:
                seen.add(it['id'])
                merged.append(it)
    errors = [e for _i, e in results if e]
    if not merged and errors:
        raise errors[0]
    merged.sort(key=lambda it: float(it.get('ratingTmdb') or 0), reverse=True)
    return merged[:FILTER_TOP]


def fetch_filter(ctype, lang, genre, decade):
    """Top titles for a filter from TorrentClaw, re-sorted by IMDb score. Returns a list of items."""
    if SITES:
        return fetch_filter_sites(ctype, lang, genre, decade)
    from concurrent.futures import ThreadPoolExecutor
    lg, dc = _filter_lang(lang), _decade(decade)
    if not lg or not dc:
        return []
    code, _name, countries = lg
    if genre == ARTHOUSE:
        return fetch_arthouse(ctype, code, dc)
    jobs = [(c, p) for c in countries for p in range(1, FILTER_FETCH_PAGES + 1)]

    def one(job):
        country, page = job
        try:
            return TorrentClaw().discover(ctype=ctype, genre=genre, year_min=dc[2], year_max=dc[3],
                                          lang=code, country=country, votes_min=FILTER_VOTES_MIN.get(code),
                                          sort='rating', page=page, limit=50).items, None
        except ApiError as e:
            return [], e

    with ThreadPoolExecutor(max_workers=FILTER_WORKERS) as pool:
        results = list(pool.map(one, jobs))
    errors = [e for _items, e in results if e]
    seen, merged = set(), []
    for items, _e in results:
        for it in items:
            if it.get('id') is not None and it['id'] not in seen:
                seen.add(it['id'])
                merged.append(it)
    if not merged and errors:
        raise errors[0]
    if errors:
        log('Advanced filter: %d of %d TorrentClaw requests failed (%s)' % (len(errors), len(jobs), errors[0]))
    merged.sort(key=_imdb_sort_key, reverse=True)
    return merged[:FILTER_TOP]


def do_filter(ctype, lang, genre, decade, page=1):
    key = '|'.join([('sites' if SITES else ''), ctype or 'movie', lang or '', genre or '', decade or ''])
    store = load_json(FILTER_FILE, {})
    entry = store.get(key)
    if not entry or time.time() - entry.get('t', 0) > FILTER_TTL:
        progress = xbmcgui.DialogProgressBG()
        progress.create('TorrentClaw', 'Finding %s...' % filter_label(lang, genre, decade))
        try:
            items = fetch_filter(ctype, lang, genre, decade)
        finally:
            progress.close()
        entry = {'t': int(time.time()), 'items': [slim_item(i) for i in items]}
        store[key] = entry
        if len(store) > FILTER_MAX_CACHED:
            store = dict(sorted(store.items(), key=lambda kv: kv[1].get('t', 0))[-FILTER_MAX_CACHED:])
        save_json(FILTER_FILE, store)
    items = entry.get('items') or []
    start = (page - 1) * FILTER_PAGE
    chunk = items[start:start + FILTER_PAGE]
    nxt = None
    if start + FILTER_PAGE < len(items):
        nxt = {'action': 'filter', 'type': ctype, 'lang': lang, 'genre': genre, 'decade': decade, 'page': page + 1}
    label = filter_label(lang, genre, decade)
    xbmcplugin.setPluginCategory(HANDLE, label)
    if page == 1 and items:
        favs = load_json(HISTORY_FILE, {}).get(FILTER_FAV_KEY % ctype, [])
        if not any(f.get('lang') == lang and f.get('genre') == genre and f.get('decade') == decade for f in favs):
            add_dir('[COLOR gold]★ Save this filter as a favourite[/COLOR]',
                    {'action': 'filter_fav_add', 'type': ctype, 'lang': lang, 'genre': genre, 'decade': decade},
                    folder=False, plot='Adds "%s" to the search menu for one-click access.' % label)
    list_titles(chunk, nxt, 'tvshows' if ctype == 'show' else 'movies',
                empty_msg='Nothing found for %s' % label)


def filter_fav_add(ctype, lang, genre, decade):
    store = load_json(HISTORY_FILE, {})
    key = FILTER_FAV_KEY % ctype
    favs = [f for f in store.get(key, []) if not (f.get('lang') == lang and f.get('genre') == genre
                                                    and f.get('decade') == decade)]
    store[key] = ([{'lang': lang, 'genre': genre, 'decade': decade}] + favs)[:30]
    save_json(HISTORY_FILE, store)
    notify('Saved: %s' % filter_label(lang, genre, decade))
    xbmc.executebuiltin('Container.Refresh')


def filter_fav_del(ctype, lang, genre, decade):
    store = load_json(HISTORY_FILE, {})
    key = FILTER_FAV_KEY % ctype
    store[key] = [f for f in store.get(key, []) if not (f.get('lang') == lang and f.get('genre') == genre
                                                          and f.get('decade') == decade)]
    save_json(HISTORY_FILE, store)
    xbmc.executebuiltin('Container.Refresh')


def episode_search(cid):
    item = load_item(cid)
    if not item:
        return notify('Please reopen the list and try again')
    if item.get('_placeholder'):
        return not_on_tc(item)
    cid = item['id']
    d = xbmcgui.Dialog()
    season = d.numeric(0, 'Season number')
    if not season:
        return
    episode = d.numeric(0, 'Episode number (leave empty for whole season)')
    res = TorrentClaw().search(item.get('title') or '', ctype='show', season=int(season),
                               episode=int(episode) if episode else None, limit=10)
    new = []
    for r in res.items:
        if r.get('id') == item.get('id') or (item.get('imdbId') and r.get('imdbId') == item.get('imdbId')):
            new = r.get('torrents') or []
            break
    if not new:
        return notify('No releases found for that season/episode')
    known = set(info_hash(t) for t in item.get('torrents') or [])
    item['torrents'] = (item.get('torrents') or []) + [t for t in new if info_hash(t) not in known or not info_hash(t)]
    cache_items([item])
    xbmc.executebuiltin('Container.Update(%s)' % url_for(action='torrents', id=cid, season=season))


# ====================================================================== releases (torrents) view
def show_torrents(cid, season=None, lang=None):
    item = load_item(cid)
    if not item:
        notify('This list expired, please reopen it')
        return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    if item.get('_placeholder'):
        not_on_tc(item)
        add_dir('[B]Look it up on TorrentClaw again[/B]', {'action': 'relookup', 'id': cid}, folder=False,
                plot='New releases appear on TorrentClaw a while after a film comes out.')
        add_dir('Search TorrentClaw for "%s"' % (item.get('title') or ''),
                {'action': 'search', 'type': item.get('contentType') or 'movie', 'q': item.get('title') or ''})
        return end_dir('files')
    cid = item['id']
    item = ensure_torrents(item)
    torrents = item.get('torrents') or []
    is_show = item.get('contentType') == 'show'

    # TV shows with several seasons: show season folders first
    if is_show and season is None:
        seasons = sorted(set(t.get('season') for t in torrents if t.get('season') is not None))
        if len(seasons) > 1:
            for s in seasons:
                n = len(filter_torrents([t for t in torrents if t.get('season') == s], lang))
                li = xbmcgui.ListItem(label='Season %d  [COLOR grey](%d releases)[/COLOR]' % (s, n), offscreen=True)
                set_art(li, item)
                set_info(li, item, mediatype='season')
                xbmcplugin.addDirectoryItem(HANDLE, url_for(action='torrents', id=cid, season=s, lang=lang), li, True)
            other = [t for t in torrents if t.get('season') is None]
            if other:
                add_dir('Complete series / other packs', {'action': 'torrents', 'id': cid, 'season': 'none', 'lang': lang})
            add_dir('[B]Find a specific episode...[/B]', {'action': 'episode_search', 'id': cid}, folder=False)
            return end_dir('seasons')

    if season == 'none':
        torrents = [t for t in torrents if t.get('season') is None]
    elif season is not None:
        torrents = [t for t in torrents if str(t.get('season')) == str(season)]
        torrents.sort(key=lambda t: (t.get('episode') or 0))

    raw = torrents
    torrents = filter_torrents(torrents, lang)
    if season not in (None, 'none'):
        torrents.sort(key=lambda t: (t.get('episode') is not None, t.get('episode') or 0))
    if not torrents:
        msg = 'No releases match your filters' if raw else 'No releases found'
        notify(msg)
    cached = cache_status(torrents)
    original = item.get('torrents') or []
    for t in torrents:
        key = tkey(t, original.index(t)) if t in original else info_hash(t)
        h = info_hash(t)
        li = xbmcgui.ListItem(label=torrent_label(t, item, cached.get(h)), offscreen=True)
        set_art(li, item)
        plot = '%s\n\n%s' % (t.get('rawTitle') or '', torrent_summary(t))
        if t.get('subtitleLanguages'):
            plot += '\nSubtitles: ' + ', '.join(s.upper() for s in t['subtitleLanguages'])
        if t.get('qualityScore') is not None:
            plot += '\nQuality score: %s/100' % t['qualityScore']
        plot += '\nSource: %s' % (t.get('source') or '?')
        if h in cached:
            plot += '\nPremiumize: %s' % ('cached - instant' if cached[h] else 'not cached (will download first)')
        set_info(li, item, mediatype='video', plot=plot)
        ctx = [('Add to Premiumize cloud', run_plugin(action='add', id=cid, t=key)),
               ('Play now via Premiumize', run_plugin(action='play', id=cid, t=key)),
               ('Play now - choose subtitles...', run_plugin(action='play_subs', id=cid, t=key)),
               ('Release details', run_plugin(action='details', id=cid, t=key))]
        li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(HANDLE, url_for(action='torrent_menu', id=cid, t=key), li, False)
    if is_show and season is not None:
        add_dir('[B]Find a specific episode...[/B]', {'action': 'episode_search', 'id': cid}, folder=False)
    end_dir('videos')


# ====================================================================== actions
def _lookup(cid, key):
    item = get_item(cid)
    if not item:
        notify('This list expired, please reopen it')
        return None, None
    t = find_torrent(item, key)
    if not t:
        notify('Release not found, please reopen the list')
    return item, t


def _folder_for(item, pm):
    path = setting('folder_shows') if item.get('contentType') == 'show' else setting('folder_movies')
    if not path:
        return None
    return pm.folder_id_for(path)


def add_to_cloud(item, t):
    title = item.get('title') or ''
    magnet = magnet_of(t, t.get('rawTitle') or title)
    if not magnet:
        return notify('No magnet link. Set your TorrentClaw API key in settings.')
    pm = Premiumize()
    progress = xbmcgui.DialogProgressBG()
    progress.create('TorrentClaw', 'Adding to Premiumize...')
    try:
        folder_id = _folder_for(item, pm)
        res = pm.create_transfer(magnet, folder_id)
        h = info_hash(t)
        cached = False
        if h:
            try:
                cached = pm.check_cache([h]).get(h, False)
            except ApiError:
                pass
    finally:
        progress.close()
    name = res.get('name') or title
    if cached:
        notify('%s - cached, ready in your cloud' % name, 'Added to Premiumize')
    else:
        notify('%s - downloading to your cloud' % name, 'Added to Premiumize')
    log('Added transfer %s (%s)' % (res.get('id'), name))


def pick_release(item, prompt='Add to Premiumize cloud'):
    item = ensure_torrents(item)
    torrents = filter_torrents(item.get('torrents') or [])
    if not torrents:
        notify('No releases match your filters')
        return None
    cached = cache_status(torrents)
    labels = [torrent_label(t, item, cached.get(info_hash(t))) for t in torrents]
    idx = xbmcgui.Dialog().select('%s - %s' % (prompt, item.get('title') or ''), labels)
    return torrents[idx] if idx >= 0 else None


def add_pick(cid):
    item = load_item(cid)
    if not item:
        return notify('This list expired, please reopen it')
    if item.get('_placeholder'):
        return not_on_tc(item)
    cid = item['id']
    t = pick_release(item)
    if t:
        add_to_cloud(get_item(cid) or item, t)


def add_best(cid):
    item = load_item(cid)
    if not item:
        return notify('This list expired, please reopen it')
    if item.get('_placeholder'):
        return not_on_tc(item)
    item = ensure_torrents(item)
    torrents = filter_torrents(item.get('torrents') or [])
    if not torrents:
        return notify('No releases match your filters')
    add_to_cloud(item, torrents[0])


def get_subtitles(item, t, f, link, choose=False):
    """Fetch English subtitles from OpenSubtitles when the release lacks them. Returns [path]."""
    if not (setting_bool('subs_enabled') or choose):
        return []
    osub = OpenSubtitles()
    if not osub.configured:
        if choose:
            notify('Set your OpenSubtitles API key in settings > Subtitles')
        return []
    langs = preferred_langs()
    if not choose and setting_bool('subs_only_missing') and all(l in release_sub_langs(t) for l in langs):
        log('release already has %s subtitles, skipping OpenSubtitles' % ','.join(langs))
        return []
    fname = (f.get('path') or f.get('name') or '').split('/')[-1]
    season, episode = t.get('season'), t.get('episode')
    m = re.search(r'[Ss](\d{1,2})[ ._-]?[Ee](\d{1,3})', fname)
    if m:
        season, episode = int(m.group(1)), int(m.group(2))
    imdb = imdb_num(item.get('imdbId'))
    is_show = item.get('contentType') == 'show'
    progress = xbmcgui.DialogProgressBG()
    progress.create('TorrentClaw', 'Looking for English subtitles...')
    try:
        mh = None
        if setting_bool('subs_moviehash'):
            try:
                mh = oshash_remote(link, int(f.get('size') or 0))
            except (TypeError, ValueError):
                mh = None

        def do_search(hash_):
            if is_show and imdb and season is not None and episode is not None:
                return osub.search(langs, parent_imdb_id=imdb, season=season, episode=episode, moviehash=hash_)
            if not is_show and imdb:
                return osub.search(langs, imdb_id=imdb, moviehash=hash_)
            return osub.search(langs, query=item.get('title') or fname, moviehash=hash_)
        results = do_search(mh)
        if mh and not results:
            results = do_search(None)
        ranked = rank(results, langs, [fname, t.get('rawTitle') or ''])
    except ApiError as e:
        progress.close()
        notify('Subtitles: %s' % e)
        return []
    progress.close()
    if not ranked:
        notify('No English subtitles found on OpenSubtitles')
        return []
    if choose:
        idx = xbmcgui.Dialog().select('English subtitles - %s' % (item.get('title') or ''),
                                      ['No subtitles'] + [result_label(r) for r in ranked[:50]])
        if idx <= 0:
            return []
        chosen = ranked[idx - 1]
    else:
        chosen = ranked[0]
    attrs = chosen.get('attributes') or {}
    try:
        data, sub_name, remaining = osub.download(attrs['files'][0]['file_id'])
    except ApiError as e:
        notify('Subtitle download failed: %s' % e)
        return []
    path = save_sub(data, sub_name, attrs.get('language') or 'en')
    msg = '%s subtitles added' % lang_name(attrs.get('language') or 'en')
    if attrs.get('moviehash_match'):
        msg += ' (exact match)'
    if isinstance(remaining, int) and remaining < 20:
        msg += ' - %d downloads left today' % remaining
    notify(msg)
    return [path]


def start_playback(link, li, subs):
    player = xbmc.Player()
    player.play(link, li)
    if not subs:
        return
    monitor = xbmc.Monitor()
    for _ in range(60):  # wait up to 30s for playback to start
        if player.isPlayingVideo() or monitor.waitForAbort(0.5):
            break
    if player.isPlayingVideo():
        player.setSubtitles(subs[0])
        player.showSubtitles(True)


def play(item, t, choose_subs=False):
    magnet = magnet_of(t, t.get('rawTitle') or item.get('title') or '')
    if not magnet:
        return notify('No magnet link. Set your TorrentClaw API key in settings.')
    try:
        content = Premiumize().directdl(magnet)
    except ApiError as e:
        log('directdl failed: %s' % e)
        return notify('Not cached on Premiumize yet. Add it to your cloud and play once it finishes.')
    files = video_files(content)
    if not files:
        return notify('No playable video in this release (not cached yet?)')
    files.sort(key=lambda f: f.get('path') or '')
    if len(files) == 1:
        f = files[0]
    else:
        files_by_size = sorted(files, key=lambda f: -(int(f.get('size') or 0)))
        if setting_bool('autoplay_largest') and item.get('contentType') != 'show':
            f = files_by_size[0]
        else:
            labels = ['%s  [COLOR grey](%s)[/COLOR]' % ((x.get('path') or '').split('/')[-1], fmt_size(x.get('size')))
                      for x in files]
            i = xbmcgui.Dialog().select('Choose file', labels)
            if i < 0:
                return
            f = files[i]
    link = f.get('link') or f.get('stream_link')
    subs = get_subtitles(item, t, f, link, choose=choose_subs)
    li = xbmcgui.ListItem(label=item.get('title') or '', path=link, offscreen=True)
    set_art(li, item)
    set_info(li, item, mediatype='episode' if item.get('contentType') == 'show' else 'movie')
    start_playback(link, li, subs)


def details(item, t):
    lines = [t.get('rawTitle') or '', '', torrent_summary(t)]
    r = imdb_rating(item)
    if r is not None:
        lines.append('IMDb rating: %.1f' % r)
    for k, label in (('qualityScore', 'Quality score'), ('seeders', 'Seeders'), ('leechers', 'Leechers'),
                     ('source', 'Source'), ('releaseGroup', 'Release group'), ('uploadedAt', 'Uploaded'),
                     ('scanStatus', 'TrueSpec scan'), ('threatLevel', 'Threat check')):
        if t.get(k) not in (None, ''):
            lines.append('%s: %s' % (label, t[k]))
    langs = torrent_langs(t)
    if langs:
        lines.append('Audio: ' + ', '.join(LANG_NAMES.get(l, l.upper()) for l in langs))
    if t.get('subtitleLanguages'):
        lines.append('Subtitles: ' + ', '.join(s.upper() for s in t['subtitleLanguages']))
    h = info_hash(t)
    if h:
        lines += ['', 'Info hash: ' + h]
    xbmcgui.Dialog().textviewer(item.get('title') or 'Release', '\n'.join(lines))


def torrent_menu(cid, key):
    item, t = _lookup(cid, key)
    if not t:
        return
    choice = xbmcgui.Dialog().select(torrent_summary(t),
                                     ['Add to Premiumize cloud', 'Play now via Premiumize',
                                      'Play now - choose subtitles...', 'Release details'])
    if choice == 0:
        add_to_cloud(item, t)
    elif choice == 1:
        play(item, t)
    elif choice == 2:
        play(item, t, choose_subs=True)
    elif choice == 3:
        details(item, t)


# ====================================================================== all torrent sites
SITE_CACHE = 'site_results.json'
SITE_TTL = 15 * 60                 # keep one search's results this long
SITE_MAX_CACHED = 12               # searches kept on disk
SITE_KEEP = 300                    # results kept per search (best seeded first)
SITE_CHECK_MAX = 80                # results checked against the Premiumize cache
SITE_CATS = {'movie': 'Movies', 'show': 'TV shows', 'anime': 'Anime', 'all': 'Everything'}
SXXEYY = re.compile(r's\d{1,2}[\s._-]*e\d{1,3}|(?<!\d)\d{1,2}x\d{2}(?!\d)', re.I)
SITES_FILTER_PAGES = 5             # TMDb pages (of 20) for the advanced filter in this section
SITES_MIN_VOTES = {'en': 300}      # TMDb votes needed; other languages: 30


def _hkey(ctype):
    """Search-history key: this section keeps its own typed-search history."""
    return ('sites_' if SITES else '') + ctype


def site_key(cat, query):
    return '%s|%s' % (cat, query.strip().lower())


def rid_of(r):
    if r.get('hash'):
        return r['hash']
    return ('p' if r.get('page') else 'n') + hashlib.md5((r.get('page') or r.get('name') or '').encode('utf-8')).hexdigest()[:12]


def site_fetch(query, cat):
    """Merged results of all enabled sites for a query (cached 15 min): (results, status, cache key)."""
    ck = site_key(cat, query)
    store = load_json(SITE_CACHE, {})
    hit = store.get(ck)
    if hit and time.time() - hit.get('t', 0) < SITE_TTL:
        return hit['r'], hit.get('s') or {}, ck
    if not sources.enabled():
        raise ApiError('All torrent sites are switched off. Turn some on in settings > Torrent sites.')
    progress = xbmcgui.DialogProgressBG()
    progress.create('TorrentClaw', 'Searching the torrent sites for "%s"...' % query)
    try:
        results, status = sources.search_all(query, cat)
    finally:
        progress.close()
    for r in results:
        r['rid'] = rid_of(r)
    results.sort(key=lambda r: r.get('seeders') or 0, reverse=True)
    results = results[:SITE_KEEP]
    if results:  # an empty answer is not worth keeping: the sites may just have been down
        store[ck] = {'t': int(time.time()), 'r': results, 's': status}
        if len(store) > SITE_MAX_CACHED:
            store = dict(sorted(store.items(), key=lambda kv: kv[1].get('t', 0))[-SITE_MAX_CACHED:])
        save_json(SITE_CACHE, store)
    return results, status, ck


def site_find(ck, rid):
    hit = load_json(SITE_CACHE, {}).get(ck)
    for r in (hit or {}).get('r') or []:
        if r.get('rid') == rid:
            return r
    return None


def site_filter(results, item=None, season=None, episode=None):
    """Apply the quality / seeders / CAM settings, and (for a TMDb title) keep only releases of that title."""
    mq = setting_int('min_quality', 0)
    minq = MIN_QUALITY[mq] if 0 <= mq < len(MIN_QUALITY) else 0
    hide_dead = setting_bool('hide_dead', True)
    hide_cam = setting_bool('hide_cam', True)
    minseed = setting_int('min_seeders', 0)
    out = []
    for r in results:
        n = r.get('name') or ''
        if hide_dead and (r.get('seeders') or 0) <= 0:
            continue
        if minseed and (r.get('seeders') or 0) < minseed:
            continue
        if minq and release.quality_rank(n) < minq:
            continue
        if hide_cam and release.is_cam(n):
            continue
        if item:
            year = item.get('year') if item.get('contentType') != 'show' else None
            if not release.relevant(n, item.get('title'), year, (item.get('titleOriginal'),)):
                continue
            if episode is not None:
                if not release.episode_match(n, season, episode):
                    continue
            elif season is not None and not release.season_match(n, season):
                continue
        out.append(r)
    mode = setting_int('torrent_sort', 0)
    if mode == 1:
        out.sort(key=lambda r: r.get('seeders') or 0, reverse=True)
    elif mode == 2:
        out.sort(key=lambda r: r.get('size') or 0, reverse=True)
    else:
        out.sort(key=lambda r: (release.quality_rank(r.get('name')), r.get('seeders') or 0), reverse=True)
    return out


def site_cache_status(results):
    if not setting_bool('check_cache', True) or not setting('pm_apikey'):
        return {}
    hashes = [r['hash'] for r in results[:SITE_CHECK_MAX] if r.get('hash')]
    if not hashes:
        return {}
    try:
        return Premiumize().check_cache(hashes)
    except ApiError as e:
        log('cache check failed: %s' % e)
        return {}


def status_line(status):
    parts = []
    for name, v in status.items():
        count, err = v[0], v[1]
        if err == 'skipped':
            continue
        parts.append('%s %s' % (name, ('[COLOR red]x[/COLOR]' if err else str(count))))
    return ' · '.join(parts)


def site_label(r, cached=None):
    q = release.quality_label(r.get('name'))
    colour = 'gold' if q in ('4K', '1080p') else 'white'
    label = '[COLOR %s]%s[/COLOR]  %s' % (colour, q, r.get('name') or '')
    extra = [release.fmt_size(r.get('size')), 'S:%s' % (r.get('seeders') or 0)]
    tag = ' '.join(x for x in (release.source_tag(r.get('name')), release.hdr_tag(r.get('name'))) if x)
    if tag:
        extra.insert(0, tag)
    label += '  [COLOR grey]%s[/COLOR]' % ' · '.join(extra)
    sites = r.get('sources') or [r.get('source')]
    label += '  [COLOR grey](%s)[/COLOR]' % ', '.join(s for s in sites if s)
    if cached is True:
        label += '  [COLOR lime]✓ cached[/COLOR]'
    return label


def list_site_results(results, status, ck, cat, item=None, empty_msg='No releases found'):
    cached = site_cache_status(results)
    art = {'poster': (item or {}).get('posterUrl') or ICON, 'fanart': (item or {}).get('backdropUrl') or FANART}
    line = status_line(status)
    if line:
        add_dir('[COLOR grey]Sites: %s[/COLOR]' % line, {'action': 'sites_status', 'ck': ck}, folder=False,
                plot='Tap to see which sites answered and which did not.')
    for r in results:
        h = r.get('hash') or ''
        li = xbmcgui.ListItem(label=site_label(r, cached.get(h) if h in cached else None), offscreen=True)
        li.setArt({'poster': art['poster'], 'thumb': art['poster'], 'icon': art['poster'], 'fanart': art['fanart']})
        plot = '%s\n\nSize: %s\nSeeders: %s  Leechers: %s\nFound on: %s' % (
            r.get('name') or '', release.fmt_size(r.get('size')), r.get('seeders') or 0, r.get('leechers') or 0,
            ', '.join(s for s in (r.get('sources') or [r.get('source')]) if s))
        if h in cached:
            plot += '\nPremiumize: %s' % ('cached - instant' if cached[h] else 'not cached (will download first)')
        if item:
            set_info(li, item, mediatype='video', plot=plot)
        else:
            try:
                li.getVideoInfoTag().setPlot(plot)
            except AttributeError:
                li.setInfo('video', {'plot': plot})
        li.addContextMenuItems([('Add to Premiumize cloud', run_plugin(action='site_add', ck=ck, rid=r['rid'], cat=cat)),
                                ('Release details', run_plugin(action='site_details', ck=ck, rid=r['rid']))])
        xbmcplugin.addDirectoryItem(HANDLE, url_for(action='site_add', ck=ck, rid=r['rid'], cat=cat), li, False)
    if not results:
        notify(empty_msg)
    end_dir('videos')


def sites_menu():
    add_dir('[B]Search Movies[/B]', {'action': 'search', 'type': 'movie'},
            plot='Search by title, actor, director, author or keyword, or use the advanced filter. '
                 'Opening a title lists its releases from all the torrent sites.')
    add_dir('[B]Search TV Shows[/B]', {'action': 'search', 'type': 'show'},
            plot='Same searches for TV. Opening a show lists seasons, then releases from all the torrent sites.')
    add_dir('[B]Search Anime[/B]', {'action': 'sites_new', 'cat': 'anime'},
            plot='Type a name: searches the anime-friendly sites (Nyaa and the rest) for matching releases.')
    add_dir('[B]Search everything[/B]', {'action': 'sites_new', 'cat': 'all'},
            plot='Type anything: searches every torrent site, all categories.')
    store = load_json(HISTORY_FILE, {})
    for cat in ('anime', 'all'):
        for q in store.get('sites_' + cat, []):
            add_dir('[COLOR grey]%s:[/COLOR] %s' % (SITE_CATS[cat], q), {'action': 'sites_results', 'q': q, 'cat': cat},
                    context=[('Remove from history', run_plugin(action='history_del', type=cat, q=q))])
    add_dir('Test the torrent sites', {'action': 'sites_test'}, folder=False,
            plot='Checks which sites answer from this Shield, and your Premiumize account.')
    add_dir('Settings', {'action': 'settings'}, folder=False)
    end_dir('files')


def sites_new(cat):
    """Typed search of one category (anime / everything), straight to the sites."""
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    q = xbmcgui.Dialog().input('Search %s' % SITE_CATS.get(cat, 'torrents').lower()).strip()
    if not q:
        return
    key = 'sites_' + cat
    store = load_json(HISTORY_FILE, {})
    store[key] = ([q] + [h for h in store.get(key, []) if h.lower() != q.lower()])[:20]
    save_json(HISTORY_FILE, store)
    xbmc.executebuiltin('Container.Update(%s)' % url_for(action='sites_results', q=q, cat=cat))


def sites_results(q, cat):
    """A typed search: every release the sites returned, filtered by your settings."""
    results, status, ck = site_fetch(q, cat)
    shown = site_filter(results)
    xbmcplugin.setPluginCategory(HANDLE, '%s - %s' % (SITE_CATS.get(cat, ''), q))
    msg = 'Nothing found for "%s"' % q
    if results and not shown:
        msg = 'Found %d, but your filters (quality, seeders, CAM) hide them all' % len(results)
    list_site_results(shown, status, ck, cat, empty_msg=msg)


def add_site_title(item, tag_tv=False):
    title = item.get('title') or item.get('titleOriginal') or 'Unknown'
    label = '%s (%s)' % (title, item['year']) if item.get('year') else title
    if tag_tv and item.get('contentType') == 'show':
        label = '[COLOR grey][TV][/COLOR] ' + label
    rt = rating_tag(item)
    if rt:
        label += '  ' + rt
    li = xbmcgui.ListItem(label=label, offscreen=True)
    set_art(li, item)
    set_info(li, item)
    ctype = 'show' if item.get('contentType') == 'show' else 'movie'
    ctx = [('Search TorrentClaw for this title',
            'Container.Update(%s)' % url_for(action='search', type=ctype, q=title, mode='tc'))]
    if item.get('tmdbId'):
        ctx.append(('Add to TMDb watchlist', run_plugin(action='tmdb_watch', mt='tv' if ctype == 'show' else 'movie',
                                                      tid=item['tmdbId'], title=title)))
    li.addContextMenuItems(ctx)
    xbmcplugin.addDirectoryItem(HANDLE, url_for(action='sites_title', id=item['id']), li, True)
    return True


def sites_title(cid):
    item = get_item(cid)
    if not item:
        notify('This list expired, please reopen it')
        return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    if item.get('contentType') == 'show' and item.get('tmdbId'):
        try:
            seasons = TMDb().seasons(item['tmdbId'])
        except ApiError as e:
            log('seasons lookup failed: %s' % e)
            seasons = []
        if seasons:
            add_dir('[B]All releases[/B]', {'action': 'sites_releases', 'id': cid})
            for s in seasons:
                li = xbmcgui.ListItem(label='Season %d' % s, offscreen=True)
                set_art(li, item)
                set_info(li, item, mediatype='season')
                xbmcplugin.addDirectoryItem(HANDLE, url_for(action='sites_releases', id=cid, season=s), li, True)
            add_dir('[B]Find a specific episode...[/B]', {'action': 'site_episode', 'id': cid}, folder=False)
            return end_dir('seasons')
    sites_releases(cid)


def site_episode(cid):
    d = xbmcgui.Dialog()
    s = d.numeric(0, 'Season number')
    if not s or not s.strip().isdigit() or int(s) < 1:
        return
    e = d.numeric(0, 'Episode number')
    if not e or not e.strip().isdigit() or int(e) < 1:
        return
    xbmc.executebuiltin('Container.Update(%s)' % url_for(action='sites_releases', id=cid, season=int(s),
                                                         episode=int(e)))


def sites_releases(cid, season=None, episode=None):
    item = get_item(cid)
    if not item:
        notify('This list expired, please reopen it')
        return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    is_show = item.get('contentType') == 'show'
    cat = 'show' if is_show else 'movie'
    names = []
    for n in (item.get('title'), item.get('titleOriginal')):
        n = (n or '').strip()
        if n and n.lower() not in [x.lower() for x in names] and (n == item.get('title') or n.isascii()):
            names.append(n)
    suffix = ''
    if season is not None and episode is not None:
        suffix = ' S%02dE%02d' % (int(season), int(episode))
    elif season is not None:
        suffix = ' S%02d' % int(season)
    queries = []
    for n in names:
        if item.get('year') and not is_show:
            queries.append('%s %s' % (n, item['year']))
        queries.append(n + suffix)
    shown, status, ck, results = [], {}, '', []
    for q in queries:
        results, status, ck = site_fetch(q, cat)
        shown = site_filter(results, item,
                            int(season) if season is not None else None,
                            int(episode) if episode is not None else None)
        if shown:
            break
    title = item.get('title') or ''
    label = title + (' - Season %s' % season if season is not None and episode is None else '')
    if episode is not None:
        label += ' S%02dE%02d' % (int(season), int(episode))
    xbmcplugin.setPluginCategory(HANDLE, label)
    msg = 'No releases of "%s" found on the sites' % title
    if results and not shown:
        msg = 'Found %d results but none match "%s" with your filters' % (len(results), title)
    list_site_results(shown, status, ck, cat, item=item, empty_msg=msg)


def sites_status(ck):
    hit = load_json(SITE_CACHE, {}).get(ck) or {}
    lines = []
    for name, v in (hit.get('s') or {}).items():
        count, err = v[0], v[1]
        if err == 'skipped':
            continue
        lines.append('%s: %s' % (name, ('FAILED - %s' % err) if err else '%d results' % count))
    xbmcgui.Dialog().ok('Torrent sites', '\n'.join(lines) or 'No information (the search expired).')


def site_details(ck, rid):
    r = site_find(ck, rid)
    if not r:
        return notify('This list expired, please reopen it')
    xbmcgui.Dialog().textviewer('Release details', '%s\n\nSize: %s\nSeeders: %s   Leechers: %s\nFound on: %s\nInfo hash: %s' % (
        r.get('name') or '', release.fmt_size(r.get('size')), r.get('seeders') or 0, r.get('leechers') or 0,
        ', '.join(s for s in (r.get('sources') or [r.get('source')]) if s), r.get('hash') or '(fetched when added)'))


def site_add(ck, rid, cat='all'):
    r = site_find(ck, rid)
    if not r:
        return notify('This list expired, please reopen it')
    pm = Premiumize()
    progress = xbmcgui.DialogProgressBG()
    progress.create('TorrentClaw', 'Adding to Premiumize...')
    try:
        magnet = sources.magnet_for(r)
        h = r.get('hash') or release.hash_of_magnet(magnet)
        cached = False
        if h:
            try:
                cached = pm.check_cache([h]).get(h, False)
            except ApiError:
                pass
    except ApiError as e:
        progress.close()
        return notify(str(e))
    progress.close()
    if setting_bool('sites_confirm', True):
        msg = '%s\n\n%s · %s seeders\n%s' % (r.get('name') or '', release.fmt_size(r.get('size')),
                                          r.get('seeders') or 0,
                                          'Cached on Premiumize: ready at once' if cached else 'Not cached: Premiumize will download it first')
        if not xbmcgui.Dialog().yesno('Add to Premiumize cloud?', msg):
            return
    is_show = cat == 'show' or bool(SXXEYY.search(r.get('name') or ''))
    path = setting('folder_shows') if is_show else setting('folder_movies')
    progress = xbmcgui.DialogProgressBG()
    progress.create('TorrentClaw', 'Adding to Premiumize...')
    try:
        folder_id = pm.folder_id_for(path) if path else None
        res = pm.create_transfer(magnet, folder_id)
    finally:
        progress.close()
    name = res.get('name') or r.get('name') or ''
    notify('%s - %s' % (name, 'cached, ready in your cloud' if cached else 'downloading to your cloud'),
           'Added to Premiumize')
    log('Added transfer %s (%s)' % (res.get('id'), name))


def sites_test():
    progress = xbmcgui.DialogProgressBG()
    progress.create('TorrentClaw', 'Testing the torrent sites...')
    try:
        rows = sources.test_all('ubuntu')
    finally:
        progress.close()
    lines = []
    for name, ok, count, secs, err in rows:
        if ok is None:
            lines.append('%s: switched off' % name)
        elif ok:
            lines.append('%s: OK (%d results, %.1f s)' % (name, count, secs))
        else:
            lines.append('%s: FAILED - %s' % (name, err))
    try:
        acc = Premiumize().account()
        until = acc.get('premium_until')
        lines.append('Premiumize: OK (premium until %s)' % (time.strftime('%d %b %Y', time.localtime(int(until))) if until else '?'))
    except ApiError as e:
        lines.append('Premiumize: FAILED - %s' % e)
    xbmcgui.Dialog().ok('Torrent sites - test', '\n'.join(lines))


def fetch_filter_sites(ctype, lang, genre, decade):
    """Advanced filter for the all-sites section: titles from TMDb (language, genre, decade), IMDb-sorted."""
    from concurrent.futures import ThreadPoolExecutor
    lg, dc = _filter_lang(lang), _decade(decade)
    if not lg or not dc:
        return []
    code, _name, countries = lg
    if genre == ARTHOUSE:
        items = fetch_arthouse(ctype, code, dc)[:SITES_FILTER_PAGES * 20]
    else:
        tm = TMDb()
        if not tm.configured:
            raise ApiError('Add a TMDb API key in settings to use the advanced filter')
        langs = ARTHOUSE_TMDB_LANGS.get(code, [code])
        genres = tm.genres(ctype)
        if genre == 'Anime':
            gid, langs, countries = genres.get('Animation'), ['ja'], ['JP']
        else:
            gid = genres.get(genre)
        if not gid:
            raise ApiError('TMDb has no "%s" genre' % genre)
        votes = SITES_MIN_VOTES.get(code, 30)

        def one(page):
            try:
                return tm.discover_filter(ctype, langs, countries, gid, dc[2], dc[3], page, votes), None
            except ApiError as e:
                return [], e

        with ThreadPoolExecutor(max_workers=FILTER_WORKERS) as pool:
            results = list(pool.map(one, range(1, SITES_FILTER_PAGES + 1)))
        seen, items = set(), []
        for chunk, _e in results:
            for it in chunk:
                if it['id'] not in seen:
                    seen.add(it['id'])
                    items.append(it)
        errors = [e for _c, e in results if e]
        if not items and errors:
            raise errors[0]
    note = add_imdb_scores(items)
    if note:
        notify(note)
    items.sort(key=_imdb_sort_key, reverse=True)
    return items


# ====================================================================== transfers
def show_transfers():
    items = Premiumize().transfers()
    add_dir('[B]Clear finished transfers[/B]', {'action': 'clear_finished'}, folder=False)
    for tr in items:
        status = tr.get('status') or '?'
        prog = tr.get('progress')
        pct = ''
        if isinstance(prog, (int, float)) and status not in ('finished', 'seeding'):
            pct = ' %d%%' % int(prog * 100)
        colour = {'finished': 'springgreen', 'seeding': 'springgreen', 'error': 'red',
                  'deleted': 'red', 'banned': 'red'}.get(status, 'gold')
        label = '[COLOR %s][%s%s][/COLOR] %s' % (colour, status, pct, tr.get('name') or '')
        plot = tr.get('message') or ''
        add_dir(label, {'action': 'noop'}, plot=plot, folder=False,
                context=[('Delete transfer', run_plugin(action='del_transfer', tid=tr.get('id'),
                                                        name=(tr.get('name') or '')[:80]))])
    if not items:
        notify('No transfers')
    end_dir('files')


def del_transfer(tid, name):
    if xbmcgui.Dialog().yesno('Delete transfer', 'Delete this transfer from Premiumize?\n\n%s' % name):
        Premiumize().delete_transfer(tid)
        xbmc.executebuiltin('Container.Refresh')


def clear_finished():
    Premiumize().clear_finished()
    notify('Finished transfers cleared')
    xbmc.executebuiltin('Container.Refresh')


# ====================================================================== settings / test
def test_connection():
    lines = []
    tc = TorrentClaw()
    try:
        res = tc.search('inception', ctype='movie', limit=1)
        has_magnet = bool(res.items and (res.items[0].get('torrents') or [{}])[0].get('magnetUrl'))
        lines.append('TorrentClaw: OK (tier: %s)' % (tc.tier or ('key set' if tc.key else 'anonymous')))
        lines.append('  Magnet links: %s' % ('yes' if has_magnet else 'NO - check your API key'))
    except ApiError as e:
        lines.append('TorrentClaw: FAILED - %s' % e)
    try:
        acc = Premiumize().account()
        until = acc.get('premium_until')
        until_s = time.strftime('%d %b %Y', time.localtime(int(until))) if until else '?'
        used = acc.get('space_used')
        lines.append('Premiumize: OK (premium until %s)' % until_s)
        if used is not None:
            lines.append('  Cloud space used: %s' % fmt_size(used))
    except ApiError as e:
        lines.append('Premiumize: FAILED - %s' % e)
    osub = OpenSubtitles()
    if not osub.configured:
        lines.append('OpenSubtitles: not set up (optional)')
    else:
        try:
            osub.login(force=True)
            u = osub.user_info or {}
            level = 'VIP' if u.get('vip') else (u.get('level') or 'logged in')
            lines.append('OpenSubtitles: OK (%s)' % level)
            if u.get('allowed_downloads') is not None:
                lines.append('  Downloads today: %s left of %s' % (u.get('remaining_downloads', '?'),
                                                                 u.get('allowed_downloads')))
        except ApiError as e:
            lines.append('OpenSubtitles: FAILED - %s' % e)
    xbmcgui.Dialog().ok('TorrentClaw - connection test', '\n'.join(lines))


# ====================================================================== router
def router(p):
    action = p.get('action')
    page = int(p.get('page', 1) or 1)
    folder_actions = ('list', 'indian', 'indian_menu', 'indian_lang', 'dubbed', 'east_asia_menu',
                      'region_menu', 'world', 'search', 'person', 'filter', 'torrents', 'transfers',
                      'tmdb_watchlist', 'tmdb_watchlist_menu', 'keyword', 'sites_menu', 'sites_title',
                      'sites_releases', 'sites_results', None)
    try:
        if action is None:
            main_menu()
        elif action == 'list':
            do_list(p.get('src'), p.get('type'), p.get('period'), page)
        elif action == 'indian_menu':
            indian_menu()
        elif action == 'indian':
            do_indian(p.get('src', 'latest'), p.get('lang'), page)
        elif action == 'east_asia_menu':
            east_asia_menu()
        elif action == 'region_menu':
            region_menu(p.get('region'))
        elif action == 'world':
            do_world(p.get('region', 'in'), p.get('src', 'latest'), p.get('lang'), page)
        elif action == 'indian_lang':
            indian_lang_menu(p.get('lang'))
        elif action == 'dubbed':
            do_dubbed(p.get('lang'), page)
        elif action == 'relookup':
            item = load_item(p['id'], force=True)
            if item and not item.get('_placeholder'):
                notify('Found on TorrentClaw')
            elif item:
                not_on_tc(item)
            xbmc.executebuiltin('Container.Refresh')
        elif action == 'search':
            if p.get('q'):
                do_search(p.get('type'), p['q'], page)
            else:
                search_root(p.get('type'))
        elif action == 'search_new':
            search_new(p.get('type'))
        elif action == 'person_new':
            person_new(p.get('type') or 'movie', p.get('role') or 'actor')
        elif action == 'person':
            do_person(p.get('type') or 'movie', p.get('role') or 'actor', p.get('pid'), p.get('name'), page,
                      p.get('scope'))
        elif action == 'keyword_new':
            keyword_new(p.get('type') or 'movie')
        elif action == 'keyword':
            do_keyword(p.get('type') or 'movie', p.get('kid'), p.get('name'), p.get('scope'))
        elif action == 'keyword_history_del':
            keyword_history_del(p.get('type') or 'movie', p.get('kid'))
        elif action == 'tmdb_connect':
            tmdb_connect()
        elif action == 'tmdb_disconnect':
            tmdb_disconnect()
        elif action == 'tmdb_watch':
            tmdb_watch(p.get('mt') or 'movie', p.get('tid'), p.get('title', ''))
        elif action == 'tmdb_list_add':
            tmdb_list_add(p.get('tid'), p.get('title', ''))
        elif action == 'tmdb_watchlist_menu':
            tmdb_watchlist_menu()
        elif action == 'tmdb_watchlist':
            do_tmdb_watchlist(p.get('type') or 'movie', page)
        elif action == 'filter_new':
            filter_new(p.get('type') or 'movie')
        elif action == 'filter':
            do_filter(p.get('type') or 'movie', p.get('lang'), p.get('genre'), p.get('decade'), page)
        elif action == 'filter_fav_add':
            filter_fav_add(p.get('type') or 'movie', p.get('lang'), p.get('genre'), p.get('decade'))
        elif action == 'filter_fav_del':
            filter_fav_del(p.get('type') or 'movie', p.get('lang'), p.get('genre'), p.get('decade'))
        elif action == 'person_history_del':
            person_history_del(p.get('type') or 'movie', p.get('role') or 'actor', p.get('pid'))
        elif action == 'history_del':
            history_del(p.get('type'), p.get('q'))
        elif action == 'torrents':
            show_torrents(p['id'], p.get('season'), p.get('lang'))
        elif action == 'torrent_menu':
            torrent_menu(p['id'], p['t'])
        elif action in ('add', 'play', 'play_subs', 'details'):
            item, t = _lookup(p['id'], p['t'])
            if t:
                if action == 'play_subs':
                    play(item, t, choose_subs=True)
                else:
                    {'add': add_to_cloud, 'play': play, 'details': details}[action](item, t)
        elif action == 'add_pick':
            add_pick(p['id'])
        elif action == 'add_best':
            add_best(p['id'])
        elif action == 'episode_search':
            episode_search(p['id'])
        elif action == 'transfers':
            show_transfers()
        elif action == 'del_transfer':
            del_transfer(p.get('tid'), p.get('name', ''))
        elif action == 'clear_finished':
            clear_finished()
        elif action == 'sites_menu':
            sites_menu()
        elif action == 'sites_new':
            sites_new(p.get('cat') or 'all')
        elif action == 'sites_results':
            sites_results(p.get('q') or '', p.get('cat') or 'all')
        elif action == 'sites_title':
            sites_title(p['id'])
        elif action == 'sites_releases':
            sites_releases(p['id'], p.get('season'), p.get('episode'))
        elif action == 'site_episode':
            site_episode(p['id'])
        elif action == 'sites_status':
            sites_status(p.get('ck'))
        elif action == 'site_add':
            site_add(p.get('ck'), p.get('rid'), p.get('cat') or 'all')
        elif action == 'site_details':
            site_details(p.get('ck'), p.get('rid'))
        elif action == 'sites_test':
            sites_test()
        elif action == 'settings':
            ADDON.openSettings()
        elif action == 'test':
            test_connection()
    except ApiError as e:
        log('API error: %s' % e, xbmc.LOGWARNING)
        notify(str(e))
        if action in folder_actions and HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


if __name__ == '__main__':
    router(PARAMS)
