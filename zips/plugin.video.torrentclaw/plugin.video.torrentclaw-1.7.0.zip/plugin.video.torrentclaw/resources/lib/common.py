# -*- coding: utf-8 -*-
"""Shared helpers: settings, logging, notifications, HTTP and small JSON storage."""
import json
import os
import re

from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
ICON = os.path.join(ADDON_PATH, 'icon.png')
FANART = os.path.join(ADDON_PATH, 'fanart.jpg')
USER_AGENT = 'Kodi-TorrentClaw/%s' % ADDON_VERSION


# Torrent sites often refuse non-browser clients, so page requests look like a normal browser.
BROWSER_UA = ('Mozilla/5.0 (Linux; Android 11; SHIELD Android TV) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/120.0 Safari/537.36')


class ApiError(Exception):
    def __init__(self, message, code=None):
        super().__init__(message)
        self.code = code


# ---------------------------------------------------------------- settings
def setting(sid):
    return (ADDON.getSetting(sid) or '').strip()


def setting_bool(sid, default=False):
    v = (ADDON.getSetting(sid) or '').lower()
    return default if v == '' else v == 'true'


def setting_int(sid, default=0):
    try:
        return int(ADDON.getSetting(sid))
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------- ui
def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def notify(msg, heading=None, ms=5000):
    xbmcgui.Dialog().notification(heading or ADDON_NAME, msg, ICON, ms)


# ---------------------------------------------------------------- http
def http_bytes(url, headers=None, timeout=25, limit=None):
    """GET raw bytes (used for subtitle files and file-hash ranges)."""
    hdrs = {'User-Agent': USER_AGENT}
    if headers:
        hdrs.update(headers)
    try:
        with urlopen(Request(url, headers=hdrs), timeout=timeout) as resp:
            return resp.read(limit) if limit else resp.read()
    except HTTPError as e:
        raise ApiError('HTTP %s' % e.code, e.code)
    except Exception as e:
        raise ApiError('Network error: %s' % e)


def http_json(method, url, params=None, data=None, headers=None, timeout=25, json_body=None):
    """Return (parsed_json, response_headers). Raises ApiError on failure."""
    if params:
        url += ('&' if '?' in url else '?') + urlencode(params, doseq=True)
    body = None
    hdrs = {'User-Agent': USER_AGENT, 'Accept': 'application/json'}
    if headers:
        hdrs.update(headers)
    if json_body is not None:
        body = json.dumps(json_body).encode('utf-8')
        hdrs['Content-Type'] = 'application/json'
    elif data is not None:
        body = urlencode(data, doseq=True).encode('utf-8')
        hdrs['Content-Type'] = 'application/x-www-form-urlencoded'
    req = Request(url, data=body, headers=hdrs, method=method)
    safe_url = url.split('apikey=')[0] + ('apikey=***' if 'apikey=' in url else '')
    log('%s %s' % (method, safe_url), xbmc.LOGDEBUG)
    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode('utf-8', 'replace')
            resp_headers = resp.headers
    except HTTPError as e:
        msg = ''
        try:
            payload = json.loads(e.read().decode('utf-8', 'replace'))
            msg = payload.get('status_message') or payload.get('message') or payload.get('error') or ''
        except Exception:
            pass
        if e.code == 401:
            msg = msg or 'API key rejected'
        elif e.code == 429:
            msg = msg or 'Rate limit reached, try again in a minute'
        raise ApiError('HTTP %s %s' % (e.code, msg).strip(), e.code)
    except URLError as e:
        raise ApiError('Network error: %s' % getattr(e, 'reason', e))
    except Exception as e:  # timeouts etc.
        raise ApiError('Network error: %s' % e)
    try:
        return json.loads(raw), resp_headers
    except ValueError:
        raise ApiError('Unexpected (non-JSON) response from server')


def http_text(url, params=None, headers=None, timeout=15):
    """GET a web page as text (for the torrent-site scrapers). Raises ApiError."""
    if params:
        url += ('&' if '?' in url else '?') + urlencode(params)
    hdrs = {'User-Agent': BROWSER_UA, 'Accept': 'text/html,application/xhtml+xml,application/xml,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.8'}
    if headers:
        hdrs.update(headers)
    log('GET %s' % url, xbmc.LOGDEBUG)
    try:
        with urlopen(Request(url, headers=hdrs), timeout=timeout) as resp:
            text = resp.read().decode('utf-8', 'replace')
    except HTTPError as e:
        raise ApiError('HTTP %s' % e.code, e.code)
    except URLError as e:
        raise ApiError('Network error: %s' % getattr(e, 'reason', e))
    except Exception as e:
        raise ApiError('Network error: %s' % e)
    low = text[:3000].lower()
    if ('just a moment' in low and 'cloudflare' in low) or 'cf-browser-verification' in low:
        raise ApiError('Blocked by a Cloudflare check')
    return text


def strip_tags(s):
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', s or '')).strip()


# ---------------------------------------------------------------- storage
def _path(name):
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)
    return os.path.join(PROFILE, name)


def load_json(name, default):
    try:
        with open(_path(name), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default


def save_json(name, obj):
    try:
        with open(_path(name), 'w', encoding='utf-8') as f:
            json.dump(obj, f, separators=(',', ':'))
    except Exception as e:
        log('Could not save %s: %s' % (name, e), xbmc.LOGWARNING)
