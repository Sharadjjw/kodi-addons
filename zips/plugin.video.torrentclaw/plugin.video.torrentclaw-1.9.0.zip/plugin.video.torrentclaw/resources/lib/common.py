# -*- coding: utf-8 -*-
"""Shared helpers: settings, logging, notifications, HTTP and small JSON storage."""
import http.client
import io
import ipaddress
import json
import os
import re
import socket
import ssl
import threading
import time

from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen, build_opener, HTTPHandler, HTTPSHandler, HTTPCookieProcessor
from urllib.error import HTTPError, URLError

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
ICON = os.path.join(ADDON_PATH, 'icon.png')
FANART = os.path.join(ADDON_PATH, 'fanart.jpg')
USER_AGENT = 'Kodi-TorrentClaw/%s' % ADDON_VERSION


# Torrent sites often refuse non-browser clients, so page requests look like a normal browser.
BROWSER_UA = ('Mozilla/5.0 (Linux; Android 11; SHIELD Android TV) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/120.0 Safari/537.36')


class ApiError(Exception):
    def __init__(self, message, code=None):
        super().__init__(message)
        self.code = code


# ---------------------------------------------------------------- settings
def setting(sid):
    return (ADDON.getSetting(sid) or '').strip()


def setting_bool(sid, default=False):
    v = (ADDON.getSetting(sid) or '').lower()
    return default if v == '' else v == 'true'


def setting_int(sid, default=0):
    try:
        return int(ADDON.getSetting(sid))
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------- ui
def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def notify(msg, heading=None, ms=5000):
    xbmcgui.Dialog().notification(heading or ADDON_NAME, msg, ICON, ms)


# ---------------------------------------------------------------- DNS-over-HTTPS
# Some internet providers block torrent sites by lying in their DNS answers. With DNS-over-HTTPS
# the add-on asks a public resolver (over an encrypted web request) for a site's real address and
# connects to that address itself. The web address and certificate checks are unchanged: the
# connection still goes to the site's own name, only the lookup is done differently.
# The resolvers are reached by IP address, so no DNS lookup is needed to talk to them.
DOH_PROVIDERS = (
    ('Cloudflare', ('https://1.1.1.1/dns-query', 'https://1.0.0.1/dns-query')),
    ('Google', ('https://8.8.8.8/resolve', 'https://8.8.4.4/resolve')),
)
_DOH_CACHE = {}          # host -> (expires, [ipv4, ...])
_DOH_LOCK = threading.Lock()
_DOH_TTL_MIN, _DOH_TTL_MAX = 120, 3600


def doh_enabled():
    return setting_bool('use_doh', True)


def doh_order():
    """Providers in the order to try: the chosen one first, the other as a back-up."""
    first = 1 if setting_int('doh_provider', 0) == 1 else 0
    return [DOH_PROVIDERS[first], DOH_PROVIDERS[1 - first]]


def doh_label():
    return 'DNS-over-HTTPS (%s)' % doh_order()[0][0] if doh_enabled() else 'your internet provider\'s DNS'


def _is_ipv4(text):
    try:
        return isinstance(ipaddress.ip_address(text), ipaddress.IPv4Address)
    except ValueError:
        return False


def doh_resolve(host):
    """IPv4 addresses of a host name, looked up over HTTPS. Cached for a while. Raises OSError."""
    if _is_ipv4(host):
        return [host]
    now = time.time()
    with _DOH_LOCK:
        hit = _DOH_CACHE.get(host)
    if hit and hit[0] > now:
        return list(hit[1])
    last = 'no answer'
    for name, urls in doh_order():
        for base in urls:
            try:
                req = Request(base + '?' + urlencode({'name': host, 'type': 'A'}),
                              headers={'Accept': 'application/dns-json', 'User-Agent': USER_AGENT})
                with urlopen(req, timeout=6) as resp:
                    data = json.loads(resp.read().decode('utf-8', 'replace'))
                answers = [a for a in (data.get('Answer') or []) if a.get('type') == 1 and _is_ipv4(a.get('data'))]
                if answers:
                    ttl = min(_to_ttl(a.get('TTL')) for a in answers)
                    ips = [a['data'] for a in answers]
                    with _DOH_LOCK:
                        _DOH_CACHE[host] = (now + min(max(ttl, _DOH_TTL_MIN), _DOH_TTL_MAX), ips)
                    return list(ips)
                last = '%s: no address for %s' % (name, host)
                break          # this resolver answered, so its other address would say the same
            except Exception as e:
                last = '%s: %s' % (name, e)
    raise OSError('DNS-over-HTTPS lookup failed (%s)' % last)


def _to_ttl(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return _DOH_TTL_MIN


def _doh_socket(host, port, timeout, source_address):
    err = None
    for ip in doh_resolve(host):
        try:
            sock = socket.create_connection((ip, port), timeout, source_address)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            return sock
        except OSError as e:
            err = e
    raise err or OSError('no address for %s' % host)


class _DoHConnection(http.client.HTTPConnection):
    def connect(self):
        if self._tunnel_host:   # going through a proxy: the proxy does the lookup, nothing to do here
            return super().connect()
        try:
            self.sock = _doh_socket(self.host, self.port, self.timeout, self.source_address)
        except OSError as e:
            log('DoH for %s failed (%s), using normal DNS' % (self.host, e), xbmc.LOGWARNING)
            super().connect()


class _BioSocket:
    """A connected TLS socket whose first packet (the ClientHello, which carries the site name in
    clear) is sent in two pieces. Some internet providers reset a connection when they read a
    blocked site name in the first packet; with the name cut in half they do not see it.

    mode 'tcp':    one TLS record, sent as two TCP segments, cut in the middle of the site name.
    mode 'record': the ClientHello is also cut into two TLS records at that point (valid TLS),
                   for providers that put the first packets back together before looking.
    The certificate is still checked against the site's name. After the handshake this acts like a
    normal socket for http.client (sendall / recv / makefile)."""

    def __init__(self, sock, context, host, mode):
        self._sock = sock
        self._io_refs = 0
        self._closed = False
        self._in, self._out = ssl.MemoryBIO(), ssl.MemoryBIO()
        self._tls = context.wrap_bio(self._in, self._out, server_hostname=host)
        first = True
        try:
            while True:
                try:
                    self._tls.do_handshake()
                    done = True
                except ssl.SSLWantReadError:
                    done = False
                out = self._out.read()
                if out:
                    if first:
                        self._send_hello(out, host, mode)
                        first = False
                    else:
                        sock.sendall(out)
                if done:
                    break
                data = sock.recv(65536)
                if not data:
                    raise ssl.SSLEOFError(ssl.SSL_ERROR_EOF, 'connection closed during the handshake')
                self._in.write(data)
        except BaseException:
            self._real_close()
            raise

    def _send_hello(self, data, host, mode):
        name = host.encode('ascii', 'ignore')
        at = data.find(name)
        cut = at + max(1, len(name) // 2) if at > 0 else 2          # inside the site name
        if (mode == 'record' and 5 < cut < len(data) and data[0] == 0x16
                and len(data) == 5 + int.from_bytes(data[3:5], 'big')):
            head = data[:3]
            data = (head + (cut - 5).to_bytes(2, 'big') + data[5:cut] +
                    head + (len(data) - cut).to_bytes(2, 'big') + data[cut:])
        self._sock.sendall(data[:cut])
        time.sleep(0.05)                                            # so it leaves as two packets
        self._sock.sendall(data[cut:])

    def _flush(self):
        out = self._out.read()
        if out:
            self._sock.sendall(out)

    def _read(self, n):
        while True:
            try:
                data = self._tls.read(n)
                self._flush()
                return data
            except ssl.SSLWantReadError:
                self._flush()
                chunk = self._sock.recv(65536)
                if chunk:
                    self._in.write(chunk)
                else:
                    self._in.write_eof()
            except (ssl.SSLZeroReturnError, ssl.SSLEOFError):
                return b''                                          # closed, as a normal socket would

    def sendall(self, data, flags=0):
        self._tls.write(data)
        self._flush()

    def recv(self, n=65536, flags=0):
        return self._read(n)

    def recv_into(self, buffer, nbytes=0, flags=0):
        data = self._read(nbytes or len(buffer))
        buffer[:len(data)] = data
        return len(data)

    def makefile(self, mode='rb', buffering=None, *args, **kwargs):
        self._io_refs += 1
        size = buffering if buffering and buffering > 0 else io.DEFAULT_BUFFER_SIZE
        return io.BufferedReader(socket.SocketIO(self, 'rb'), size)

    def _decref_socketios(self):
        if self._io_refs > 0:
            self._io_refs -= 1
        if self._closed:
            self.close()

    def _real_close(self):
        try:
            self._sock.close()
        except OSError:
            pass

    def close(self):
        self._closed = True
        if self._io_refs <= 0:
            self._real_close()

    def fileno(self):
        return self._sock.fileno()

    def __getattr__(self, name):            # settimeout, gettimeout, getpeername, ...
        if name == '_sock':
            raise AttributeError(name)
        return getattr(self._sock, name)


class _DoHSConnection(http.client.HTTPSConnection):
    frag = None     # None = ordinary TLS; 'tcp' / 'record' = split ClientHello (see _BioSocket)

    def connect(self):
        if self._tunnel_host:   # going through a proxy: the proxy does the lookup, nothing to do here
            return super().connect()
        try:
            sock = _doh_socket(self.host, self.port, self.timeout, self.source_address)
        except OSError as e:
            log('DoH for %s failed (%s), using normal DNS' % (self.host, e), xbmc.LOGWARNING)
            super().connect()
            return
        # Check the certificate against the site's name, not the address we connected to.
        if self.frag:
            self.sock = _BioSocket(sock, self._context, self.host, self.frag)
        else:
            self.sock = self._context.wrap_socket(sock, server_hostname=self.host)


class _SplitTcpConnection(_DoHSConnection):
    frag = 'tcp'


class _SplitRecordConnection(_DoHSConnection):
    frag = 'record'


class _DoHHandler(HTTPHandler):
    def http_open(self, req):
        return self.do_open(_DoHConnection, req)


def _https_handler(conn_class):
    class Handler(HTTPSHandler):
        def https_open(self, req):
            return self.do_open(conn_class, req, context=self._context)
    return Handler()


_CONNECTIONS = {None: _DoHSConnection, 'tcp': _SplitTcpConnection, 'record': _SplitRecordConnection}
_OPENERS = {}
_SPLIT_MODE = {}         # host:port -> the way of connecting that last worked for it


def _opener(mode, jar=None):
    if jar is not None:     # a site that needs a login keeps its cookies in its own jar
        return build_opener(_DoHHandler(), _https_handler(_CONNECTIONS[mode]), HTTPCookieProcessor(jar))
    if mode not in _OPENERS:
        _OPENERS[mode] = build_opener(_DoHHandler(), _https_handler(_CONNECTIONS[mode]))
    return _OPENERS[mode]


def _was_reset(e):
    """True when the connection was cut off by the other end (or something in between)."""
    reason = getattr(e, 'reason', e)
    return isinstance(reason, (ConnectionResetError, ConnectionAbortedError, BrokenPipeError, ssl.SSLEOFError))


def _open(req, timeout, doh=False, jar=None):
    """urlopen, or (doh=True and the setting is on) the same with DNS-over-HTTPS lookups.
    If an https site resets the connection, it is tried again with the first packet split in two
    (see _BioSocket), then split into two TLS records as well.
    jar: an http.cookiejar jar that receives and sends that site's cookies (also on redirects)."""
    if not (doh and doh_enabled()):
        if jar is not None:
            return build_opener(HTTPCookieProcessor(jar)).open(req, timeout=timeout)
        return urlopen(req, timeout=timeout)
    order = [None]
    key = urlparse(req.full_url).netloc
    if req.full_url.lower().startswith('https') and setting_bool('use_frag', True):
        order = [None, 'tcp', 'record']
        pref = _SPLIT_MODE.get(key)
        if pref:                                # start with what worked last time
            order.remove(pref)
            order.insert(0, pref)
    for i, mode in enumerate(order):
        r = req if i == 0 else Request(req.full_url, data=req.data, headers=req.headers, method=req.get_method())
        try:
            resp = _opener(mode, jar).open(r, timeout=timeout)
        except (URLError, OSError) as e:
            if isinstance(e, HTTPError) or not _was_reset(e) or i == len(order) - 1:
                raise
            log('%s reset the connection; trying again with the first packet split (%s)' %
                (key, order[i + 1] or 'normal'), xbmc.LOGWARNING)
            continue
        if mode:
            _SPLIT_MODE[key] = mode
        else:
            _SPLIT_MODE.pop(key, None)
        return resp


# ---------------------------------------------------------------- http
def http_bytes(url, headers=None, timeout=25, limit=None):
    """GET raw bytes (used for subtitle files and file-hash ranges)."""
    hdrs = {'User-Agent': USER_AGENT}
    if headers:
        hdrs.update(headers)
    try:
        with urlopen(Request(url, headers=hdrs), timeout=timeout) as resp:
            return resp.read(limit) if limit else resp.read()
    except HTTPError as e:
        raise ApiError('HTTP %s' % e.code, e.code)
    except Exception as e:
        raise ApiError('Network error: %s' % e)


def http_json(method, url, params=None, data=None, headers=None, timeout=25, json_body=None, doh=False):
    """Return (parsed_json, response_headers). Raises ApiError on failure.
    doh=True looks the host up over DNS-over-HTTPS (when that setting is on)."""
    if params:
        url += ('&' if '?' in url else '?') + urlencode(params, doseq=True)
    body = None
    hdrs = {'User-Agent': USER_AGENT, 'Accept': 'application/json'}
    if headers:
        hdrs.update(headers)
    if json_body is not None:
        body = json.dumps(json_body).encode('utf-8')
        hdrs['Content-Type'] = 'application/json'
    elif data is not None:
        body = urlencode(data, doseq=True).encode('utf-8')
        hdrs['Content-Type'] = 'application/x-www-form-urlencoded'
    req = Request(url, data=body, headers=hdrs, method=method)
    safe_url = url.split('apikey=')[0] + ('apikey=***' if 'apikey=' in url else '')
    log('%s %s' % (method, safe_url), xbmc.LOGDEBUG)
    try:
        with _open(req, timeout, doh) as resp:
            raw = resp.read().decode('utf-8', 'replace')
            resp_headers = resp.headers
    except HTTPError as e:
        msg = ''
        try:
            payload = json.loads(e.read().decode('utf-8', 'replace'))
            msg = payload.get('status_message') or payload.get('message') or payload.get('error') or ''
        except Exception:
            pass
        if e.code == 401:
            msg = msg or 'API key rejected'
        elif e.code == 429:
            msg = msg or 'Rate limit reached, try again in a minute'
        raise ApiError('HTTP %s %s' % (e.code, msg).strip(), e.code)
    except URLError as e:
        hint = ' (your internet provider may be blocking this site)' if doh and _was_reset(e) else ''
        raise ApiError('Network error: %s%s' % (getattr(e, 'reason', e), hint))
    except Exception as e:  # timeouts etc.
        raise ApiError('Network error: %s' % e)
    try:
        return json.loads(raw), resp_headers
    except ValueError:
        raise ApiError('Unexpected (non-JSON) response from server')


def http_text(url, params=None, headers=None, timeout=15, doh=False, data=None, jar=None, encoding='utf-8'):
    """GET (or POST a form when data is given) a web page as text, for the torrent-site scrapers.
    Raises ApiError. doh=True looks the host up over DNS-over-HTTPS (when that setting is on).
    jar keeps cookies for sites that need a login; encoding is the page's character set."""
    if params:
        url += ('&' if '?' in url else '?') + urlencode(params, encoding=encoding, errors='replace')
    body = urlencode(data, encoding=encoding, errors='replace').encode('ascii') if data is not None else None
    hdrs = {'User-Agent': BROWSER_UA, 'Accept': 'text/html,application/xhtml+xml,application/xml,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.8', 'Accept-Encoding': 'identity',
            'Upgrade-Insecure-Requests': '1', 'Referer': '/'.join(url.split('/')[:3]) + '/'}
    if body is not None:
        hdrs['Content-Type'] = 'application/x-www-form-urlencoded'
    if headers:
        hdrs.update(headers)
    log('%s %s' % ('POST' if body is not None else 'GET', url), xbmc.LOGDEBUG)
    try:
        with _open(Request(url, data=body, headers=hdrs), timeout, doh, jar) as resp:
            text = resp.read().decode(encoding, 'replace')
    except HTTPError as e:
        if e.code in (403, 503):
            raise ApiError('The site refuses apps like Kodi (HTTP %s, bot protection). Try another address or switch it off.' % e.code, e.code)
        raise ApiError('HTTP %s' % e.code, e.code)
    except URLError as e:
        hint = ' (your internet provider may be blocking this site)' if doh and _was_reset(e) else ''
        raise ApiError('Network error: %s%s' % (getattr(e, 'reason', e), hint))
    except Exception as e:
        raise ApiError('Network error: %s' % e)
    low = text[:3000].lower()
    if ('just a moment' in low and 'cloudflare' in low) or 'cf-browser-verification' in low:
        raise ApiError('Blocked by a Cloudflare check')
    return text


def strip_tags(s):
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', s or '')).strip()


# ---------------------------------------------------------------- storage
def _path(name):
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)
    return os.path.join(PROFILE, name)


def load_json(name, default):
    try:
        with open(_path(name), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default


def save_json(name, obj):
    try:
        with open(_path(name), 'w', encoding='utf-8') as f:
            json.dump(obj, f, separators=(',', ':'))
    except Exception as e:
        log('Could not save %s: %s' % (name, e), xbmc.LOGWARNING)
