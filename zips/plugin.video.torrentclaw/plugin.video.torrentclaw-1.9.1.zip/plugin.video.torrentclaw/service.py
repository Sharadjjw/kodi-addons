# -*- coding: utf-8 -*-
"""Background service: opens TorrentClaw from a remote button.

A remote-button app (tvQuickActions over ADB) runs
    touch <profile>/open_app
and this service opens the TorrentClaw main menu, like clicking it in Video add-ons.
Works when Kodi was closed too (the ADB command also starts Kodi).
The file is never deleted (the shell user creates it, Kodi only reads it); a newer
modification time means a new press. A press made while Kodi was starting counts.
If a video is loaded in Kodi (e.g. paused), the press rewinds it instead.
"""
import os
import time

import xbmc
import xbmcvfs

ADDON_ID = 'plugin.video.torrentclaw'
TRIGGER_NAME = 'open_app'
TRIGGER_MAX_AGE = 180      # seconds: older presses (e.g. from yesterday) are ignored
STARTUP_WAIT = 30          # seconds: right after Kodi starts, wait for the Home screen


def log(msg):
    xbmc.log('[TorrentClaw service] %s' % msg, xbmc.LOGINFO)


def profile_dir():
    path = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)   # so the ADB "touch" has a folder to write into
    return path


class Trigger:
    def __init__(self):
        self.path = os.path.join(profile_dir(), TRIGGER_NAME)
        mtime = self._mtime()
        self.seen = mtime if (mtime and time.time() - mtime > TRIGGER_MAX_AGE) else 0.0

    def _mtime(self):
        try:
            return os.stat(self.path).st_mtime
        except OSError:
            return 0.0

    def pressed(self):
        mtime = self._mtime()
        if not mtime or mtime == self.seen:
            return False
        self.seen = mtime
        return time.time() - mtime <= TRIGGER_MAX_AGE


def wait_for_home(monitor, started):
    """Kodi just started: give the Home screen time to appear before opening a window."""
    while time.time() - started < STARTUP_WAIT:
        if xbmc.getCondVisibility('Window.IsVisible(home)'):
            monitor.waitForAbort(1)
            return
        if monitor.waitForAbort(0.5):
            return


def open_torrentclaw():
    player = xbmc.Player()
    if player.isPlaying():          # true when paused too
        log('Remote button: a video is loaded, rewinding instead')
        xbmc.executebuiltin('Action(Rewind)')
        return
    log('Remote button: opening TorrentClaw')
    xbmc.executebuiltin('ActivateWindow(Videos,plugin://%s/,return)' % ADDON_ID)


def run():
    started = time.time()
    monitor = xbmc.Monitor()
    trigger = Trigger()
    while not monitor.waitForAbort(1):
        if trigger.pressed():
            wait_for_home(monitor, started)
            if monitor.abortRequested():
                break
            open_torrentclaw()


if __name__ == '__main__':
    run()
