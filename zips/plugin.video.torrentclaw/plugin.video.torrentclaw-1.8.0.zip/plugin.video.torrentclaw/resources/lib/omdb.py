# -*- coding: utf-8 -*-
"""IMDb scores through OMDb (omdbapi.com). Uses this add-on's OMDb key, or the one in Premiumize Library."""
import xbmcaddon

from .common import ApiError, http_json, setting

API = 'https://www.omdbapi.com/'


def api_key():
    key = (setting('omdb_key') or '').strip()
    if key:
        return key
    try:
        return (xbmcaddon.Addon('plugin.video.pmlibrary').getSetting('omdb_key') or '').strip()
    except Exception:
        return ''


class OMDbLimit(ApiError):
    pass


class OMDb(object):
    def __init__(self):
        self.key = api_key()

    @property
    def configured(self):
        return bool(self.key)

    def rating(self, imdb_id):
        """{'r': IMDb score or None, 'v': votes} for a tt... id. Raises OMDbLimit / ApiError."""
        data, _ = http_json('GET', API, params={'i': imdb_id, 'apikey': self.key})
        if str(data.get('Response')).lower() == 'false':
            err = str(data.get('Error') or '')
            if 'limit' in err.lower():
                raise OMDbLimit('OMDb daily limit reached')
            if 'api key' in err.lower():
                raise ApiError('OMDb rejected the API key', 401)
            return {'r': None, 'v': 0}
        try:
            r = float(data.get('imdbRating'))
        except (TypeError, ValueError):
            r = None
        try:
            v = int(str(data.get('imdbVotes') or '0').replace(',', ''))
        except ValueError:
            v = 0
        return {'r': r, 'v': v}
