# -*- coding: utf-8 -*-
"""TorrentClaw API client (https://torrentclaw.com/api/v1)."""
import re
from urllib.parse import quote

from .common import http_json, setting, setting_int

MIRRORS = ['https://torrentclaw.com', 'https://torrentclaw.to']

QUALITY_RANK = {'2160p': 2160, '4k': 2160, 'uhd': 2160, '1440p': 1440, '1080p': 1080,
                '720p': 720, '576p': 576, '540p': 540, '480p': 480, '360p': 360}

# 3-letter codes that sometimes appear in audio tracks -> 2-letter
LANG3 = {'hin': 'hi', 'mal': 'ml', 'tam': 'ta', 'tel': 'te', 'kan': 'kn', 'eng': 'en',
         'ben': 'bn', 'mar': 'mr', 'pan': 'pa', 'guj': 'gu', 'spa': 'es', 'fre': 'fr',
         'fra': 'fr', 'ger': 'de', 'deu': 'de', 'jpn': 'ja', 'kor': 'ko', 'chi': 'zh',
         'zho': 'zh', 'rus': 'ru', 'ara': 'ar', 'ita': 'it', 'por': 'pt'}


class Page(object):
    def __init__(self, items, has_more, notice=None):
        self.items = items
        self.has_more = has_more
        self.notice = notice


class TorrentClaw(object):
    def __init__(self):
        self.key = setting('tc_apikey')
        idx = setting_int('tc_mirror', 0)
        self.base = MIRRORS[idx] if 0 <= idx < len(MIRRORS) else MIRRORS[0]
        self.tier = None

    # ------------------------------------------------------------ low level
    def _get(self, path, params):
        headers = {}
        if self.key:
            headers['Authorization'] = 'Bearer ' + self.key
        params = dict((k, v) for k, v in params.items() if v not in (None, ''))
        data, hdrs = http_json('GET', self.base + '/api/v1/' + path, params=params, headers=headers)
        try:
            self.tier = hdrs.get('X-RateLimit-Tier')
        except Exception:
            self.tier = None
        return data

    @staticmethod
    def _items(data):
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for k in ('results', 'items', 'data', 'content'):
                if isinstance(data.get(k), list):
                    return data[k]
        return []

    def _page(self, data, page, limit, ctype=None):
        items = self._items(data)
        has_more = len(items) >= limit
        if isinstance(data, dict):
            total = data.get('total')
            size = data.get('pageSize') or limit
            if isinstance(total, int):
                has_more = page * size < total
        if ctype:
            items = [i for i in items if not i.get('contentType') or i.get('contentType') == ctype]
        notice = data.get('_notice') if isinstance(data, dict) else None
        return Page(items, has_more, notice)

    # ------------------------------------------------------------ endpoints
    def popular(self, ctype=None, page=1, limit=24):
        return self._page(self._get('popular', {'type': ctype, 'page': page, 'limit': limit}), page, limit, ctype)

    def recent(self, ctype=None, page=1, limit=24):
        return self._page(self._get('recent', {'type': ctype, 'page': page, 'limit': limit}), page, limit, ctype)

    def trending(self, period='daily', ctype=None, page=1, limit=24):
        return self._page(self._get('trending', {'period': period, 'type': ctype, 'page': page, 'limit': limit}),
                          page, limit, ctype)

    def search(self, q, ctype=None, page=1, limit=40, lang=None, season=None, episode=None,
               year=None, sort=None):
        params = {'q': q, 'type': ctype, 'page': page, 'limit': limit, 'lang': lang,
                  'season': season, 'episode': episode, 'sort': sort}
        if year:
            params['year_min'] = year
            params['year_max'] = year
        return self._page(self._get('search', params), page, limit, ctype)

    def discover(self, ctype=None, genre=None, year_min=None, year_max=None, lang=None,
                 country=None, votes_min=None, sort='rating', page=1, limit=50):
        """Search with no title, by filters only.

        lang is the torrent audio language, country the title's country of origin.
        sort is a PRO feature (ignored by TorrentClaw without a PRO key)."""
        params = {'type': ctype, 'genre': genre, 'year_min': year_min, 'year_max': year_max,
                  'lang': lang, 'country': country, 'votes_min': votes_min, 'sort': sort,
                  'page': page, 'limit': limit}
        return self._page(self._get('search', params), page, limit, ctype)


# ---------------------------------------------------------------- torrent helpers
def info_hash(t):
    h = (t.get('infoHash') or '').strip().lower()
    if not h:
        m = re.search(r'btih:([0-9a-zA-Z]{32,40})', t.get('magnetUrl') or '')
        if m:
            h = m.group(1).lower()
    return h


def magnet_of(t, name=''):
    m = t.get('magnetUrl') or t.get('magnet')
    if m:
        return m
    h = info_hash(t)
    if h:
        return 'magnet:?xt=urn:btih:%s&dn=%s' % (h, quote(name or t.get('rawTitle') or h))
    return None


def quality_rank(t):
    q = (t.get('quality') or '').lower()
    if q in QUALITY_RANK:
        return QUALITY_RANK[q]
    m = re.search(r'(\d{3,4})p', q)
    return int(m.group(1)) if m else 0


def torrent_langs(t):
    out = []
    for code in (t.get('languages') or []):
        c = LANG3.get((code or '').lower(), (code or '').lower())
        if c and c not in out:
            out.append(c)
    for tr in (t.get('audioTracks') or []):
        c = (tr.get('lang') or '').lower()
        c = LANG3.get(c, c)
        if c and c != 'und' and c not in out:
            out.append(c)
    return out
