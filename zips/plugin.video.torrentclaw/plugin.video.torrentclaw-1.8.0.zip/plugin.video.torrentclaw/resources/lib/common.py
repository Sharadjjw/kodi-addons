# -*- coding: utf-8 -*-
"""Shared helpers: settings, logging, notifications, HTTP and small JSON storage."""
import http.client
import ipaddress
import json
import os
import re
import socket
import threading
import time

from urllib.parse import urlencode
from urllib.request import Request, urlopen, build_opener, HTTPHandler, HTTPSHandler
from urllib.error import HTTPError, URLError

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
ICON = os.path.join(ADDON_PATH, 'icon.png')
FANART = os.path.join(ADDON_PATH, 'fanart.jpg')
USER_AGENT = 'Kodi-TorrentClaw/%s' % ADDON_VERSION


# Torrent sites often refuse non-browser clients, so page requests look like a normal browser.
BROWSER_UA = ('Mozilla/5.0 (Linux; Android 11; SHIELD Android TV) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/120.0 Safari/537.36')


class ApiError(Exception):
    def __init__(self, message, code=None):
        super().__init__(message)
        self.code = code


# ---------------------------------------------------------------- settings
def setting(sid):
    return (ADDON.getSetting(sid) or '').strip()


def setting_bool(sid, default=False):
    v = (ADDON.getSetting(sid) or '').lower()
    return default if v == '' else v == 'true'


def setting_int(sid, default=0):
    try:
        return int(ADDON.getSetting(sid))
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------- ui
def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def notify(msg, heading=None, ms=5000):
    xbmcgui.Dialog().notification(heading or ADDON_NAME, msg, ICON, ms)


# ---------------------------------------------------------------- DNS-over-HTTPS
# Some internet providers block torrent sites by lying in their DNS answers. With DNS-over-HTTPS
# the add-on asks a public resolver (over an encrypted web request) for a site's real address and
# connects to that address itself. The web address and certificate checks are unchanged: the
# connection still goes to the site's own name, only the lookup is done differently.
# The resolvers are reached by IP address, so no DNS lookup is needed to talk to them.
DOH_PROVIDERS = (
    ('Cloudflare', ('https://1.1.1.1/dns-query', 'https://1.0.0.1/dns-query')),
    ('Google', ('https://8.8.8.8/resolve', 'https://8.8.4.4/resolve')),
)
_DOH_CACHE = {}          # host -> (expires, [ipv4, ...])
_DOH_LOCK = threading.Lock()
_DOH_TTL_MIN, _DOH_TTL_MAX = 120, 3600


def doh_enabled():
    return setting_bool('use_doh', True)


def doh_order():
    """Providers in the order to try: the chosen one first, the other as a back-up."""
    first = 1 if setting_int('doh_provider', 0) == 1 else 0
    return [DOH_PROVIDERS[first], DOH_PROVIDERS[1 - first]]


def doh_label():
    return 'DNS-over-HTTPS (%s)' % doh_order()[0][0] if doh_enabled() else 'your internet provider\'s DNS'


def _is_ipv4(text):
    try:
        return isinstance(ipaddress.ip_address(text), ipaddress.IPv4Address)
    except ValueError:
        return False


def doh_resolve(host):
    """IPv4 addresses of a host name, looked up over HTTPS. Cached for a while. Raises OSError."""
    if _is_ipv4(host):
        return [host]
    now = time.time()
    with _DOH_LOCK:
        hit = _DOH_CACHE.get(host)
    if hit and hit[0] > now:
        return list(hit[1])
    last = 'no answer'
    for name, urls in doh_order():
        for base in urls:
            try:
                req = Request(base + '?' + urlencode({'name': host, 'type': 'A'}),
                              headers={'Accept': 'application/dns-json', 'User-Agent': USER_AGENT})
                with urlopen(req, timeout=6) as resp:
                    data = json.loads(resp.read().decode('utf-8', 'replace'))
                answers = [a for a in (data.get('Answer') or []) if a.get('type') == 1 and _is_ipv4(a.get('data'))]
                if answers:
                    ttl = min(_to_ttl(a.get('TTL')) for a in answers)
                    ips = [a['data'] for a in answers]
                    with _DOH_LOCK:
                        _DOH_CACHE[host] = (now + min(max(ttl, _DOH_TTL_MIN), _DOH_TTL_MAX), ips)
                    return list(ips)
                last = '%s: no address for %s' % (name, host)
                break          # this resolver answered, so its other address would say the same
            except Exception as e:
                last = '%s: %s' % (name, e)
    raise OSError('DNS-over-HTTPS lookup failed (%s)' % last)


def _to_ttl(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return _DOH_TTL_MIN


def _doh_socket(host, port, timeout, source_address):
    err = None
    for ip in doh_resolve(host):
        try:
            sock = socket.create_connection((ip, port), timeout, source_address)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            return sock
        except OSError as e:
            err = e
    raise err or OSError('no address for %s' % host)


class _DoHConnection(http.client.HTTPConnection):
    def connect(self):
        if self._tunnel_host:   # going through a proxy: the proxy does the lookup, nothing to do here
            return super().connect()
        try:
            self.sock = _doh_socket(self.host, self.port, self.timeout, self.source_address)
        except OSError as e:
            log('DoH for %s failed (%s), using normal DNS' % (self.host, e), xbmc.LOGWARNING)
            super().connect()


class _DoHSConnection(http.client.HTTPSConnection):
    def connect(self):
        if self._tunnel_host:   # going through a proxy: the proxy does the lookup, nothing to do here
            return super().connect()
        try:
            sock = _doh_socket(self.host, self.port, self.timeout, self.source_address)
        except OSError as e:
            log('DoH for %s failed (%s), using normal DNS' % (self.host, e), xbmc.LOGWARNING)
            super().connect()
            return
        # Check the certificate against the site's name, not the address we connected to.
        self.sock = self._context.wrap_socket(sock, server_hostname=self.host)


class _DoHHandler(HTTPHandler):
    def http_open(self, req):
        return self.do_open(_DoHConnection, req)


class _DoHSHandler(HTTPSHandler):
    def https_open(self, req):
        return self.do_open(_DoHSConnection, req, context=self._context)


_DOH_OPENER = []


def _open(req, timeout, doh=False):
    """urlopen, or (doh=True and the setting is on) the same with DNS-over-HTTPS lookups."""
    if doh and doh_enabled():
        if not _DOH_OPENER:
            _DOH_OPENER.append(build_opener(_DoHHandler(), _DoHSHandler()))
        return _DOH_OPENER[0].open(req, timeout=timeout)
    return urlopen(req, timeout=timeout)


# ---------------------------------------------------------------- http
def http_bytes(url, headers=None, timeout=25, limit=None):
    """GET raw bytes (used for subtitle files and file-hash ranges)."""
    hdrs = {'User-Agent': USER_AGENT}
    if headers:
        hdrs.update(headers)
    try:
        with urlopen(Request(url, headers=hdrs), timeout=timeout) as resp:
            return resp.read(limit) if limit else resp.read()
    except HTTPError as e:
        raise ApiError('HTTP %s' % e.code, e.code)
    except Exception as e:
        raise ApiError('Network error: %s' % e)


def http_json(method, url, params=None, data=None, headers=None, timeout=25, json_body=None, doh=False):
    """Return (parsed_json, response_headers). Raises ApiError on failure.
    doh=True looks the host up over DNS-over-HTTPS (when that setting is on)."""
    if params:
        url += ('&' if '?' in url else '?') + urlencode(params, doseq=True)
    body = None
    hdrs = {'User-Agent': USER_AGENT, 'Accept': 'application/json'}
    if headers:
        hdrs.update(headers)
    if json_body is not None:
        body = json.dumps(json_body).encode('utf-8')
        hdrs['Content-Type'] = 'application/json'
    elif data is not None:
        body = urlencode(data, doseq=True).encode('utf-8')
        hdrs['Content-Type'] = 'application/x-www-form-urlencoded'
    req = Request(url, data=body, headers=hdrs, method=method)
    safe_url = url.split('apikey=')[0] + ('apikey=***' if 'apikey=' in url else '')
    log('%s %s' % (method, safe_url), xbmc.LOGDEBUG)
    try:
        with _open(req, timeout, doh) as resp:
            raw = resp.read().decode('utf-8', 'replace')
            resp_headers = resp.headers
    except HTTPError as e:
        msg = ''
        try:
            payload = json.loads(e.read().decode('utf-8', 'replace'))
            msg = payload.get('status_message') or payload.get('message') or payload.get('error') or ''
        except Exception:
            pass
        if e.code == 401:
            msg = msg or 'API key rejected'
        elif e.code == 429:
            msg = msg or 'Rate limit reached, try again in a minute'
        raise ApiError('HTTP %s %s' % (e.code, msg).strip(), e.code)
    except URLError as e:
        raise ApiError('Network error: %s' % getattr(e, 'reason', e))
    except Exception as e:  # timeouts etc.
        raise ApiError('Network error: %s' % e)
    try:
        return json.loads(raw), resp_headers
    except ValueError:
        raise ApiError('Unexpected (non-JSON) response from server')


def http_text(url, params=None, headers=None, timeout=15, doh=False):
    """GET a web page as text (for the torrent-site scrapers). Raises ApiError.
    doh=True looks the host up over DNS-over-HTTPS (when that setting is on)."""
    if params:
        url += ('&' if '?' in url else '?') + urlencode(params)
    hdrs = {'User-Agent': BROWSER_UA, 'Accept': 'text/html,application/xhtml+xml,application/xml,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.8', 'Accept-Encoding': 'identity',
            'Upgrade-Insecure-Requests': '1', 'Referer': '/'.join(url.split('/')[:3]) + '/'}
    if headers:
        hdrs.update(headers)
    log('GET %s' % url, xbmc.LOGDEBUG)
    try:
        with _open(Request(url, headers=hdrs), timeout, doh) as resp:
            text = resp.read().decode('utf-8', 'replace')
    except HTTPError as e:
        if e.code in (403, 503):
            raise ApiError('The site refuses apps like Kodi (HTTP %s, bot protection). Try another address or switch it off.' % e.code, e.code)
        raise ApiError('HTTP %s' % e.code, e.code)
    except URLError as e:
        raise ApiError('Network error: %s' % getattr(e, 'reason', e))
    except Exception as e:
        raise ApiError('Network error: %s' % e)
    low = text[:3000].lower()
    if ('just a moment' in low and 'cloudflare' in low) or 'cf-browser-verification' in low:
        raise ApiError('Blocked by a Cloudflare check')
    return text


def strip_tags(s):
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', s or '')).strip()


# ---------------------------------------------------------------- storage
def _path(name):
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)
    return os.path.join(PROFILE, name)


def load_json(name, default):
    try:
        with open(_path(name), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default


def save_json(name, obj):
    try:
        with open(_path(name), 'w', encoding='utf-8') as f:
            json.dump(obj, f, separators=(',', ':'))
    except Exception as e:
        log('Could not save %s: %s' % (name, e), xbmc.LOGWARNING)
