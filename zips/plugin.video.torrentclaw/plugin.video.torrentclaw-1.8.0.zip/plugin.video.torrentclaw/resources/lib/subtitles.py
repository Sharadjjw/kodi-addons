# -*- coding: utf-8 -*-
"""OpenSubtitles.com REST API v1 client + subtitle selection helpers."""
import os
import re
import struct
import time

from .common import (http_json, http_bytes, setting, setting_int, setting_bool, ApiError,
                     load_json, save_json, log, PROFILE, ADDON_VERSION)

API_HOST = 'api.opensubtitles.com'
TOKEN_FILE = 'opensubtitles_token.json'
TOKEN_TTL = 20 * 3600  # tokens last ~24h

# order must match the language spinners in settings.xml
LANGS = [('en', 'English'), ('hi', 'Hindi'), ('ml', 'Malayalam'), ('ta', 'Tamil'), ('te', 'Telugu'),
         ('kn', 'Kannada'), ('bn', 'Bengali'), ('mr', 'Marathi'), ('ar', 'Arabic'), ('fr', 'French'),
         ('es', 'Spanish'), ('de', 'German')]
LANG3 = {'eng': 'en', 'hin': 'hi', 'mal': 'ml', 'tam': 'ta', 'tel': 'te', 'kan': 'kn', 'ben': 'bn',
         'mar': 'mr', 'ara': 'ar', 'fre': 'fr', 'fra': 'fr', 'spa': 'es', 'ger': 'de', 'deu': 'de'}


def lang_name(code):
    return dict(LANGS).get(code, code.upper())


def preferred_langs():
    """Subtitle languages to fetch. English only, as requested."""
    return ['en']


def release_sub_langs(t):
    """Subtitle languages TorrentClaw reports as already inside the release."""
    out = set()
    for c in (t.get('subtitleLanguages') or []):
        c = (c or '').lower()
        out.add(LANG3.get(c, c))
    for tr in (t.get('subtitleTracks') or []):
        c = (tr.get('lang') or '').lower()
        out.add(LANG3.get(c, c))
    out.discard('und')
    out.discard('')
    return out


# ---------------------------------------------------------------- moviehash
def oshash_remote(url, size):
    """OpenSubtitles hash using two 64 KB range requests (no full download)."""
    chunk = 65536
    if not size or size < chunk * 2:
        return None
    try:
        head = http_bytes(url, {'Range': 'bytes=0-%d' % (chunk - 1)}, timeout=15, limit=chunk)
        tail = http_bytes(url, {'Range': 'bytes=%d-%d' % (size - chunk, size - 1)}, timeout=15, limit=chunk)
    except ApiError as e:
        log('moviehash range request failed: %s' % e)
        return None
    if len(head) != chunk or len(tail) != chunk:
        return None  # server ignored the Range header
    h = size
    for block in (head, tail):
        for (v,) in struct.iter_unpack('<Q', block):
            h = (h + v) & 0xFFFFFFFFFFFFFFFF
    return '%016x' % h


# ---------------------------------------------------------------- client
class OpenSubtitles(object):
    def __init__(self):
        self.key = setting('os_apikey')
        self.user = setting('os_username')
        self.password = setting('os_password')
        cached = load_json(TOKEN_FILE, {})
        same_user = cached.get('user') == self.user
        self.token = cached.get('token') if same_user and time.time() - cached.get('at', 0) < TOKEN_TTL else None
        self.host = (cached.get('host') if same_user else None) or API_HOST
        self.user_info = cached.get('info') if same_user else None

    @property
    def configured(self):
        return bool(self.key)

    def _headers(self, auth):
        h = {'Api-Key': self.key, 'User-Agent': 'TorrentClaw Kodi v%s' % ADDON_VERSION}
        if auth and self.token:
            h['Authorization'] = 'Bearer ' + self.token
        return h

    def _req(self, method, path, params=None, body=None, auth=False, retry=True):
        if not self.key:
            raise ApiError('OpenSubtitles API key not set (add-on settings > Subtitles)')
        if auth:
            self.login()
        # OpenSubtitles wants lowercase, alphabetically ordered query params (else it redirects)
        if params:
            params = [(k, str(v).lower()) for k, v in sorted(params.items()) if v not in (None, '')]
        url = 'https://%s/api/v1/%s' % (self.host, path)
        try:
            res, _ = http_json(method, url, params=params, headers=self._headers(auth), json_body=body)
            return res
        except ApiError as e:
            if auth and retry and e.code == 401:
                self.login(force=True)
                return self._req(method, path, params, body, auth, retry=False)
            raise

    def login(self, force=False):
        if self.token and not force:
            return
        if not (self.user and self.password):
            raise ApiError('OpenSubtitles username/password not set (add-on settings > Subtitles)')
        self.host = API_HOST
        url = 'https://%s/api/v1/login' % API_HOST
        res, _ = http_json('POST', url, headers=self._headers(False),
                           json_body={'username': self.user, 'password': self.password})
        self.token = res.get('token')
        if not self.token:
            raise ApiError('OpenSubtitles login failed')
        base = (res.get('base_url') or '').replace('https://', '').replace('http://', '').strip('/')
        self.host = base.split('/')[0] or API_HOST  # VIP accounts get their own host
        self.user_info = res.get('user') or {}
        save_json(TOKEN_FILE, {'token': self.token, 'host': self.host, 'at': time.time(),
                               'user': self.user, 'info': self.user_info})

    def search(self, langs, imdb_id=None, parent_imdb_id=None, season=None, episode=None,
               moviehash=None, query=None):
        params = {'languages': ','.join(langs)}
        if moviehash:
            params['moviehash'] = moviehash
        if parent_imdb_id:
            params['parent_imdb_id'] = parent_imdb_id
            params['season_number'] = season
            params['episode_number'] = episode
        elif imdb_id:
            params['imdb_id'] = imdb_id
        elif query:
            params['query'] = query
        if setting_bool('subs_exclude_hi'):
            params['hearing_impaired'] = 'exclude'
        res = self._req('GET', 'subtitles', params=params)
        return res.get('data') or []

    def download(self, file_id):
        res = self._req('POST', 'download', body={'file_id': int(file_id)}, auth=True)
        link = res.get('link')
        if not link:
            raise ApiError('OpenSubtitles: %s' % (res.get('message') or 'no download link'))
        return http_bytes(link), res.get('file_name') or ('%s.srt' % file_id), res.get('remaining')


# ---------------------------------------------------------------- picking
def imdb_num(imdb_id):
    m = re.search(r'(\d+)', imdb_id or '')
    return str(int(m.group(1))) if m else None


def _tokens(s):
    return set(t for t in re.split(r'[^a-z0-9]+', (s or '').lower()) if len(t) > 1)


def rank(results, langs, release_names):
    """Sort OpenSubtitles results best-first."""
    names = set()
    for n in release_names:
        names |= _tokens(n)

    def key(r):
        a = r.get('attributes') or {}
        lang = (a.get('language') or '').lower()
        lang_pri = langs.index(lang) if lang in langs else 99
        overlap = len(names & _tokens(a.get('release'))) if names else 0
        machine = bool(a.get('machine_translated') or a.get('ai_translated'))
        return (lang_pri, not a.get('moviehash_match'), -overlap, machine, -(a.get('download_count') or 0))
    usable = [r for r in results if ((r.get('attributes') or {}).get('files') or [])]
    return sorted(usable, key=key)


def result_label(r):
    a = r.get('attributes') or {}
    tags = []
    if a.get('moviehash_match'):
        tags.append('[COLOR springgreen]exact match[/COLOR]')
    if a.get('hearing_impaired'):
        tags.append('HI')
    if a.get('machine_translated') or a.get('ai_translated'):
        tags.append('machine')
    return '[%s] %s  [COLOR grey](%s downloads%s)[/COLOR]' % (
        (a.get('language') or '?').upper(), a.get('release') or '?', a.get('download_count') or 0,
        (', ' + ', '.join(tags)) if tags else '')


def save_sub(data, file_name, lang):
    folder = os.path.join(PROFILE, 'subtitles')
    if not os.path.isdir(folder):
        os.makedirs(folder)
    # keep the folder small
    for f in os.listdir(folder):
        p = os.path.join(folder, f)
        if time.time() - os.path.getmtime(p) > 3 * 86400:
            try:
                os.remove(p)
            except OSError:
                pass
    ext = os.path.splitext(file_name)[1] or '.srt'
    safe = re.sub(r'[^A-Za-z0-9._-]+', '_', os.path.splitext(file_name)[0])[:80]
    path = os.path.join(folder, '%s.%s%s' % (safe, lang, ext))
    with open(path, 'wb') as f:
        f.write(data)
    return path
