# -*- coding: utf-8 -*-
"""Helpers for torrent release names: quality, size, magnet links, relevance."""
import re
from urllib.parse import quote

TRACKERS = ('udp://tracker.opentrackr.org:1337/announce', 'udp://open.stealth.si:80/announce',
            'udp://tracker.torrent.eu.org:451/announce', 'udp://tracker.dler.org:6969/announce',
            'udp://opentracker.i2p.rocks:6969/announce', 'udp://exodus.desync.com:6969/announce',
            'udp://tracker.tiny-vps.com:6969/announce', 'udp://open.demonii.com:1337/announce')

_UNITS = {'B': 1, 'KB': 1024, 'KIB': 1024, 'MB': 1024 ** 2, 'MIB': 1024 ** 2, 'GB': 1024 ** 3,
          'GIB': 1024 ** 3, 'TB': 1024 ** 4, 'TIB': 1024 ** 4}


def to_int(v, default=0):
    try:
        return int(str(v).replace(',', '').strip())
    except (TypeError, ValueError):
        return default


def parse_size(text):
    """'1.4 GiB' / '700 MB' / 1234 -> bytes."""
    if isinstance(text, (int, float)):
        return int(text)
    m = re.search(r'([\d.,]+)\s*([KMGT]?I?B)', (text or '').upper())
    if not m:
        return to_int(text)
    try:
        return int(float(m.group(1).replace(',', '')) * _UNITS.get(m.group(2), 1))
    except ValueError:
        return 0


def fmt_size(b):
    try:
        b = float(b)
    except (TypeError, ValueError):
        return '?'
    if b <= 0:
        return '?'
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if b < 1024 or unit == 'TB':
            return ('%.1f %s' % (b, unit)) if unit in ('GB', 'TB') else ('%d %s' % (b, unit))
        b /= 1024.0


def magnet(info_hash, name=''):
    m = 'magnet:?xt=urn:btih:%s' % info_hash
    if name:
        m += '&dn=' + quote(name)
    for t in TRACKERS:
        m += '&tr=' + quote(t, safe='')
    return m


def hash_of_magnet(m):
    mm = re.search(r'btih:([0-9a-zA-Z]{32,40})', m or '')
    return mm.group(1).lower() if mm else ''


def norm(s):
    return re.sub(r'[^a-z0-9]+', ' ', (s or '').lower()).strip()


# ---------------------------------------------------------------- quality
def quality_rank(name):
    n = (name or '').lower()
    if re.search(r'2160p|\b4k\b|\buhd\b', n):
        return 2160
    if '1080p' in n or '1080i' in n:
        return 1080
    if '720p' in n:
        return 720
    if re.search(r'480p|\bdvdrip\b|\bdvd\b', n):
        return 480
    return 0


def quality_label(name):
    r = quality_rank(name)
    return '4K' if r >= 2160 else ('%dp' % r if r else 'SD')


def source_tag(name):
    n = (name or '').lower()
    for pat, label in ((r'remux', 'REMUX'), (r'blu-?ray|bdrip|brrip', 'BluRay'), (r'web-?dl|webrip|\bweb\b', 'WEB'),
                       (r'hdtv', 'HDTV'), (r'dvdrip|\bdvd\b', 'DVD'), (r'hdrip', 'HDRip')):
        if re.search(pat, n):
            return label
    return ''


def hdr_tag(name):
    n = (name or '').lower()
    tags = []
    if re.search(r'dolby.?vision|\bdv\b', n):
        tags.append('DV')
    if re.search(r'hdr10\+|hdr10|\bhdr\b', n):
        tags.append('HDR')
    if re.search(r'x265|h\.?265|hevc', n):
        tags.append('HEVC')
    return ' '.join(tags)


def is_cam(name):
    """Cinema recordings (CAM / telesync) that nobody wants."""
    return bool(re.search(r'\b(cam|camrip|hdcam|hd-cam|ts|hdts|telesync|tc|telecine|pdvd|predvd|scr|screener)\b',
                          (name or '').lower()))


# ---------------------------------------------------------------- relevance
def episode_match(name, season, episode):
    n = (name or '').lower()
    s, e = int(season), int(episode)
    pats = [r's0*%d[\s._-]*e0*%d(?!\d)' % (s, e), r'(?<!\d)%dx0*%d(?!\d)' % (s, e)]
    return any(re.search(p, n) for p in pats)


def season_match(name, season):
    """Season pack or any episode of that season."""
    n = (name or '').lower()
    s = int(season)
    return bool(re.search(r's0*%d(?!\d)' % s, n) or re.search(r'season[\s._-]*0*%d(?!\d)' % s, n)
                or re.search(r'(?<!\d)%dx\d' % s, n))


def relevant(name, title, year=None, titles=()):
    """Does a release name belong to this title? All words of the title must appear in order-free
    form, and a different year (more than 1 apart) rules it out."""
    n = ' ' + norm(name) + ' '
    options = [t for t in ((title,) + tuple(titles)) if t]
    ok = False
    for t in options:
        words = norm(t).split()
        if words and all((' %s ' % w) in n for w in words):
            ok = True
            break
    if not ok:
        return False
    if year:
        years = [int(y) for y in re.findall(r'(?<!\d)((?:19|20)\d\d)(?!\d)', name or '')]
        # a year in the name that is not this title's year (+/-1): a remake or a different film
        if years and not any(abs(y - int(year)) <= 1 for y in years):
            return False
    return True


# ---------------------------------------------------------------- exact phrases ("the night of")
def parse_query(q):
    """'"the night of" 2016' -> ('the night of 2016', ['the night of'], ['2016']).

    Text in double quotes must appear as that exact run of words; other words just have to be present."""
    q = (q or '').replace('\u201c', '"').replace('\u201d', '"')
    phrases = [p.strip() for p in re.findall(r'"([^"]+)"', q) if p.strip()]
    rest = re.sub(r'"[^"]*"', ' ', q).replace('"', ' ')
    text = re.sub(r'\s+', ' ', q.replace('"', ' ')).strip()
    return text, phrases, norm(rest).split()


def phrase_match(name, phrases, words=()):
    """True when the release name holds every quoted phrase as whole consecutive words, and every other word."""
    n = ' ' + norm(name) + ' '
    for p in phrases:
        np_ = norm(p)
        if not np_ or (' %s ' % np_) not in n:
            return False
    return all((' %s ' % w) in n for w in words)
