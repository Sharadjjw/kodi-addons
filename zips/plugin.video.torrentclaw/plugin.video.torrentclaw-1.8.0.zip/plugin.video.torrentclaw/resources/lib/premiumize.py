# -*- coding: utf-8 -*-
"""Premiumize.me API client (https://www.premiumize.me/api)."""
from .common import http_json, setting, ApiError

BASE = 'https://www.premiumize.me/api'
VIDEO_EXT = ('.mkv', '.mp4', '.avi', '.m4v', '.mov', '.wmv', '.ts', '.m2ts', '.webm', '.mpg', '.mpeg')


class Premiumize(object):
    def __init__(self):
        self.key = setting('pm_apikey')

    def _call(self, path, params=None, data=None):
        if not self.key:
            raise ApiError('Premiumize API key not set. Open the add-on settings.')
        p = dict(params or {})
        p['apikey'] = self.key
        method = 'POST' if data is not None else 'GET'
        res, _ = http_json(method, BASE + '/' + path, params=p, data=data)
        if not isinstance(res, dict) or res.get('status') != 'success':
            msg = res.get('message') if isinstance(res, dict) else None
            raise ApiError('Premiumize: %s' % (msg or 'unexpected response'))
        return res

    # ------------------------------------------------------------ account
    def account(self):
        return self._call('account/info')

    # ------------------------------------------------------------ cache
    def check_cache(self, hashes):
        """Return {hash: bool} for the given info hashes."""
        hashes = [h for h in dict.fromkeys(h.lower() for h in hashes if h)]
        result = {}
        for i in range(0, len(hashes), 100):
            chunk = hashes[i:i + 100]
            res = self._call('cache/check', data={'items[]': chunk})
            flags = res.get('response') or []
            for h, ok in zip(chunk, flags):
                result[h] = bool(ok)
        return result

    # ------------------------------------------------------------ transfers
    def create_transfer(self, src, folder_id=None):
        data = {'src': src}
        if folder_id:
            data['folder_id'] = folder_id
        return self._call('transfer/create', data=data)

    def directdl(self, src):
        return self._call('transfer/directdl', data={'src': src}).get('content') or []

    def transfers(self):
        return self._call('transfer/list').get('transfers') or []

    def delete_transfer(self, tid):
        return self._call('transfer/delete', data={'id': tid})

    def clear_finished(self):
        return self._call('transfer/clearfinished', data={})

    # ------------------------------------------------------------ folders
    def folder_id_for(self, path):
        """Resolve (and create if needed) a folder path like 'Movies' or 'Media/Movies'."""
        parent = None
        for name in [p.strip() for p in path.replace('\\', '/').split('/') if p.strip()]:
            params = {'id': parent} if parent else {}
            content = self._call('folder/list', params=params).get('content') or []
            match = None
            for c in content:
                if c.get('type') == 'folder' and (c.get('name') or '').casefold() == name.casefold():
                    match = c.get('id')
                    break
            if not match:
                data = {'name': name}
                if parent:
                    data['parent_id'] = parent
                match = self._call('folder/create', data=data).get('id')
            parent = match
        return parent


def video_files(content):
    files = [c for c in content if (c.get('path') or c.get('name') or '').lower().endswith(VIDEO_EXT)]
    files = [f for f in files if 'sample' not in (f.get('path') or '').lower()] or files
    return files
