# -*- coding: utf-8 -*-
"""Torrent site scrapers.

Each source is a function  fn(base_url, query, cat) -> [result, ...]  registered with @source.
cat is 'movie', 'show', 'anime' or 'all'.  A result is a dict:
    name, hash (info hash, '' if unknown), magnet ('' if it must be fetched from 'page'),
    size (bytes), seeders, leechers, source (site name), page (detail page URL, optional)

To add a site: write one function below and add it to SOURCES. Settings get a switch and a
mirror-URL box for it from resources/settings.xml (see the url_<id> and src_<id> ids).
Sites move domains often, so every source tries its mirrors in order, and the user can
type a working domain in the settings.
"""
import re
import time
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote

from .common import (ApiError, http_json as _http_json, http_text as _http_text, setting, setting_bool,
                     setting_int, log, strip_tags)
from .release import magnet, hash_of_magnet, parse_size, to_int

# id -> dict(name, bases, fn, cats)
SOURCES = {}
ORDER = []


def source(sid, name, bases, cats=('movie', 'show', 'anime', 'all')):
    def deco(fn):
        SOURCES[sid] = {'id': sid, 'name': name, 'bases': bases, 'fn': fn, 'cats': cats}
        ORDER.append(sid)
        return fn
    return deco


# Every request to a torrent site goes through these two, so the DNS-over-HTTPS setting (see
# common.py) applies to all the sites, their mirrors and the magnet-page lookups, and to nothing else.
def http_json(*args, **kw):
    kw.setdefault('doh', True)
    return _http_json(*args, **kw)[0]


def http_text(*args, **kw):
    kw.setdefault('doh', True)
    return _http_text(*args, **kw)


def timeout():
    return max(5, setting_int('site_timeout', 15))


def _res(name, h='', mag='', size=0, seeders=0, leechers=0, source='', page=''):
    h = (h or '').strip().lower()
    if not h and mag:
        h = hash_of_magnet(mag)
    return {'name': strip_tags(name), 'hash': h, 'magnet': mag or '', 'size': size, 'seeders': seeders,
            'leechers': leechers, 'source': source, 'page': page}


# ====================================================================== The Pirate Bay (apibay JSON)
TPB_MOVIE = {201, 202, 207, 209}
TPB_TV = {205, 208}


@source('tpb', 'The Pirate Bay', ['https://apibay.org'])
def tpb(base, q, cat):
    data = http_json('GET', base + '/q.php', params={'q': q, 'cat': 0}, timeout=timeout())
    out = []
    if not isinstance(data, list):
        return out
    for r in data:
        h = (r.get('info_hash') or '').lower()
        if not h or set(h) == {'0'}:   # "No results returned" placeholder
            continue
        c = to_int(r.get('category'))
        if c >= 500 and c < 600:
            continue                    # adult
        if cat == 'movie' and c not in TPB_MOVIE:
            continue
        if cat in ('show',) and c not in TPB_TV:
            continue
        if cat == 'anime' and not (200 <= c < 300):
            continue
        out.append(_res(r.get('name'), h, '', to_int(r.get('size')), to_int(r.get('seeders')),
                        to_int(r.get('leechers')), 'TPB'))
    return out


# ====================================================================== YTS (JSON API, films only)
@source('yts', 'YTS', ['https://yts.mx', 'https://yts.lt'], cats=('movie', 'all'))
def yts(base, q, cat):
    data = http_json('GET', base + '/api/v2/list_movies.json',
                     params={'query_term': q, 'limit': 50, 'sort_by': 'seeds'}, timeout=timeout())
    movies = ((data or {}).get('data') or {}).get('movies') or []
    out = []
    for m in movies:
        title = m.get('title_long') or m.get('title') or ''
        for t in m.get('torrents') or []:
            h = t.get('hash') or ''
            if not h:
                continue
            name = '%s [%s] [%s] [YTS]' % (title, t.get('quality') or '', t.get('type') or '')
            out.append(_res(name, h, '', to_int(t.get('size_bytes')), to_int(t.get('seeds')),
                            to_int(t.get('peers')), 'YTS'))
    return out


# ====================================================================== Nyaa (RSS)
NYAA_NS = '{https://nyaa.si/xmlns/nyaa}'


@source('nyaa', 'Nyaa', ['https://nyaa.si'], cats=('show', 'anime', 'all'))
def nyaa(base, q, cat):
    text = http_text(base + '/', params={'page': 'rss', 'q': q, 'c': '0_0', 'f': 0, 's': 'seeders', 'o': 'desc'},
                     timeout=timeout())
    try:
        root = ET.fromstring(text.encode('utf-8'))
    except ET.ParseError:
        raise ApiError('Unexpected response (not RSS)')
    out = []
    for it in root.iter('item'):
        h = (it.findtext(NYAA_NS + 'infoHash') or '').lower()
        if not h:
            continue
        out.append(_res(it.findtext('title') or '', h, '', parse_size(it.findtext(NYAA_NS + 'size') or ''),
                        to_int(it.findtext(NYAA_NS + 'seeders')), to_int(it.findtext(NYAA_NS + 'leechers')),
                        'Nyaa'))
    return out


# ====================================================================== Knaben (aggregator JSON API)
@source('knaben', 'Knaben', ['https://api.knaben.org/v1'])
def knaben(base, q, cat):
    body = {'search_type': '100%', 'search_field': 'title', 'query': q, 'order_by': 'seeders',
            'order_direction': 'desc', 'from': 0, 'size': 100, 'hide_unsafe': True, 'hide_xxx': True}
    data = http_json('POST', base, json_body=body, timeout=timeout())
    out = []
    for r in (data or {}).get('hits') or []:
        mag = r.get('magnetUrl') or ''
        h = r.get('hash') or hash_of_magnet(mag)
        if not h and not r.get('link'):
            continue
        tracker = r.get('tracker') or 'Knaben'
        out.append(_res(r.get('title') or '', h, mag, to_int(r.get('bytes')), to_int(r.get('seeders')),
                        to_int(r.get('peers')), 'Knaben/%s' % tracker, r.get('link') or ''))
    return out


# ====================================================================== 1337x (HTML)
X_CATS = {'movie': 'Movies', 'show': 'TV', 'anime': 'Anime'}


@source('x1337', '1337x', ['https://1337x.to', 'https://1337xx.to', 'https://1337x.st'])
def x1337(base, q, cat):
    c = X_CATS.get(cat)
    if c:
        url = '%s/sort-category-search/%s/%s/seeders/desc/1/' % (base, quote(q), c)
    else:
        url = '%s/sort-search/%s/seeders/desc/1/' % (base, quote(q))
    html = http_text(url, timeout=timeout())
    out = []
    for row in re.findall(r'<tr>\s*<td class="coll-1[^"]*">(.*?)</tr>', html, re.S):
        m = re.search(r'href="(/torrent/\d+/[^"]+)"[^>]*>(.*?)</a>', row, re.S)
        if not m:
            continue
        seeds = re.search(r'class="coll-2[^"]*">\s*(\d+)', row)
        leech = re.search(r'class="coll-3[^"]*">\s*(\d+)', row)
        size = re.search(r'class="coll-4[^"]*">\s*([\d.,]+\s*[KMGT]?i?B)', row, re.I)
        out.append(_res(m.group(2), '', '', parse_size(size.group(1)) if size else 0,
                        to_int(seeds.group(1)) if seeds else 0, to_int(leech.group(1)) if leech else 0,
                        '1337x', base + m.group(1)))
    return out


def x1337_resolve(page):
    html = http_text(page, timeout=timeout())
    m = re.search(r'href="(magnet:\?xt=urn:btih:[^"]+)"', html)
    if not m:
        raise ApiError('No magnet link on the 1337x page')
    return m.group(1).replace('&amp;', '&')


# ====================================================================== LimeTorrents (HTML)
LIME_CATS = {'movie': 'movies', 'show': 'tv', 'anime': 'anime'}


@source('lime', 'LimeTorrents', ['https://www.limetorrents.lol', 'https://www.limetorrents.info'])
def lime(base, q, cat):
    url = '%s/search/%s/%s/seeds/1/' % (base, LIME_CATS.get(cat, 'all'), quote(q))
    html = http_text(url, timeout=timeout())
    out = []
    for row in re.findall(r'<tr[^>]*>(.*?)</tr>', html, re.S):
        if 'tdseed' not in row:
            continue
        h = re.search(r'torrent/([0-9A-Fa-f]{40})', row)
        name = re.search(r'<a href="[^"]*-torrent-\d+\.html"[^>]*>(.*?)</a>', row, re.S)
        if not (h and name):
            continue
        size = re.search(r'<td class="tdnormal">\s*([\d.,]+\s*[KMGT]?i?B)', row, re.I)
        seeds = re.search(r'class="tdseed">\s*([\d,]+)', row)
        leech = re.search(r'class="tdleech">\s*([\d,]+)', row)
        out.append(_res(name.group(1), h.group(1), '', parse_size(size.group(1)) if size else 0,
                        to_int(seeds.group(1)) if seeds else 0, to_int(leech.group(1)) if leech else 0,
                        'Lime'))
    return out


RESOLVERS = {'1337x': x1337_resolve}


# ====================================================================== running them
def enabled():
    return [s for sid, s in SOURCES.items() if setting_bool('src_' + sid, True)]


def bases_of(src):
    custom = setting('url_' + src['id']).rstrip('/')
    if custom:
        if not custom.startswith('http'):
            custom = 'https://' + custom
        return [custom] + [b for b in src['bases'] if b != custom]
    return list(src['bases'])


def run_source(src, query, cat):
    """-> (results, error text or ''). Tries each mirror until one answers."""
    if cat not in src['cats'] and cat != 'all':
        return [], 'skipped'
    last = ''
    for base in bases_of(src):
        try:
            res = src['fn'](base, query, cat)
            return res, ''
        except ApiError as e:
            last = str(e)
        except Exception as e:  # a site changed its layout: skip it, do not crash the search
            last = 'unreadable page (%s)' % e.__class__.__name__
            log('%s parse error on %s: %r' % (src['name'], base, e))
    return [], last or 'failed'


def search_all(query, cat='all'):
    """Search every enabled site at once. Returns (merged results, status per site).

    status: {site name: (count, error or '')}"""
    srcs = [s for s in enabled() if cat in s['cats'] or cat == 'all']
    status, merged = {}, []
    if not srcs:
        return [], {}
    with ThreadPoolExecutor(max_workers=len(srcs)) as pool:
        for src, (res, err) in zip(srcs, pool.map(lambda s: run_source(s, query, cat), srcs)):
            status[src['name']] = (len(res), err)
            merged += res
    return merge(merged), status


def merge(results):
    """One row per torrent: same info hash = same torrent; keep the best numbers and list all sites."""
    by_key, out = {}, []
    for r in results:
        key = r['hash'] or ('p:' + r['page']) or ('n:' + r['name'].lower())
        cur = by_key.get(key)
        if cur is None:
            r = dict(r, sources=[r['source']])
            by_key[key] = r
            out.append(r)
            continue
        if r['source'] not in cur['sources']:
            cur['sources'].append(r['source'])
        if r['seeders'] > cur['seeders']:
            cur['seeders'], cur['leechers'] = r['seeders'], r['leechers']
        if not cur['size'] and r['size']:
            cur['size'] = r['size']
        if not cur['magnet'] and r['magnet']:
            cur['magnet'] = r['magnet']
        if not cur['page'] and r['page']:
            cur['page'] = r['page']
    return out


def magnet_for(r):
    """Magnet link of a result (fetches the detail page for sites that do not list hashes)."""
    if r.get('magnet'):
        return r['magnet']
    if r.get('hash'):
        return magnet(r['hash'], r.get('name') or '')
    page = r.get('page') or ''
    for site, fn in RESOLVERS.items():
        if r.get('source', '').startswith(site) and page:
            return fn(page)
    if page:
        # unknown site: try to find a magnet on the page itself
        html = http_text(page, timeout=timeout())
        m = re.search(r'href="(magnet:\?xt=urn:btih:[^"]+)"', html)
        if m:
            return m.group(1).replace('&amp;', '&')
    raise ApiError('No magnet link found for this result')


def test_all(query='ubuntu'):
    """For the Test button: [(site, ok, count, seconds, error)]."""
    rows = []
    for src in SOURCES.values():
        if not setting_bool('src_' + src['id'], True):
            rows.append((src['name'], None, 0, 0.0, 'switched off'))
            continue
        t0 = time.time()
        res, err = run_source(src, query, 'all')
        rows.append((src['name'], not err, len(res), time.time() - t0, err))
    return rows
