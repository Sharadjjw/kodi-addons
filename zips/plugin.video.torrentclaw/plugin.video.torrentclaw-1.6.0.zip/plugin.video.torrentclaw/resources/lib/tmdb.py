# -*- coding: utf-8 -*-
"""Minimal TMDb client used for the Indian movie lists.

TorrentClaw's own popular/recent lists are global, so Indian films rarely appear in
them.  TMDb's discover endpoint can list films by original language and country, and
we then look each title up on TorrentClaw when it is opened.
"""
import time

import xbmcaddon

from .common import ApiError, http_json, log, setting

API = 'https://api.themoviedb.org/3/'
IMG = 'https://image.tmdb.org/t/p/'
INDIAN_LANGS = ('hi', 'ml', 'ta', 'te', 'kn')

# TMDb original-language codes: 'zh' Mandarin, 'cn' Cantonese
REGIONS = {
    'in': {'name': 'Indian', 'country': 'IN', 'langs': INDIAN_LANGS, 'best_votes': 100},
    'cn': {'name': 'Chinese', 'country': 'CN', 'langs': ('zh', 'cn'), 'best_votes': 100},
    'jp': {'name': 'Japanese', 'country': 'JP', 'langs': ('ja',), 'best_votes': 200},
    'hk': {'name': 'Hong Kong', 'country': 'HK', 'langs': ('cn', 'zh'), 'best_votes': 100},
    'kr': {'name': 'Korean', 'country': 'KR', 'langs': ('ko',), 'best_votes': 200},
}
EAST_ASIA = ('cn', 'jp', 'hk', 'kr')


def api_key():
    key = (setting('tmdb_key') or '').strip()
    if key:
        return key
    # Reuse the key already entered in the Premiumize Library add-on, if installed
    try:
        return (xbmcaddon.Addon('plugin.video.pmlibrary').getSetting('tmdb_key') or '').strip()
    except Exception:
        return ''


class TMDb(object):
    def __init__(self):
        self.key = api_key()

    @property
    def configured(self):
        return bool(self.key)

    def _get(self, path, params):
        return self._call('GET', path, params)

    def _call(self, method, path, params=None, json_body=None):
        params = dict((k, v) for k, v in (params or {}).items() if v not in (None, ''))
        headers = {'Accept': 'application/json'}
        if len(self.key) > 40:  # v4 read-access token
            headers['Authorization'] = 'Bearer ' + self.key
        else:
            params['api_key'] = self.key
        last = None
        for attempt in range(3):
            try:
                data, _ = http_json(method, API + path, params=params, headers=headers, json_body=json_body)
                return data
            except ApiError as e:
                last = e
                if e.code is not None and 400 <= e.code < 500 and e.code != 429:
                    break
                time.sleep(1 + attempt)
        log('TMDb %s %s failed: %s' % (method, path.split('?')[0], last))
        raise ApiError('TMDb: %s' % last, getattr(last, 'code', None))

    def discover(self, region='in', sort='latest', lang=None, page=1):
        """Films from a region: 'latest' (newest released), 'popular' or 'best' (top rated)."""
        reg = REGIONS.get(region) or REGIONS['in']
        today = time.strftime('%Y-%m-%d')
        params = {'with_origin_country': reg['country'], 'page': page, 'include_adult': 'false',
                  'with_original_language': lang or '|'.join(reg['langs'])}
        if sort == 'popular':
            params['sort_by'] = 'popularity.desc'
            params['vote_count.gte'] = 5
        elif sort == 'best':
            params['sort_by'] = 'vote_average.desc'
            params['vote_count.gte'] = reg['best_votes']
        else:
            params['sort_by'] = 'primary_release_date.desc'
            params['primary_release_date.lte'] = today
            # skip tiny releases with no audience; they almost never have torrents
            params['vote_count.gte'] = 1
        data = self._get('discover/movie', params) or {}
        results = data.get('results') or []
        has_more = (data.get('page') or page) < min(data.get('total_pages') or 0, 500)
        return [placeholder(r, reg['country']) for r in results if r.get('id')], has_more

    def discover_indian(self, sort='latest', lang=None, page=1):
        return self.discover('in', sort, lang, page)

    # ------------------------------------------------------------ keyword lists (art house)
    def keyword_ids(self, queries, names, cache_file='tmdb_keywords.json', ttl=30 * 24 * 3600):
        """TMDb keyword ids whose name matches one of names (compared as lowercase letters/digits).

        Looked up live with search/keyword and cached, so no id is hard-coded."""
        from .common import load_json, save_json
        key = '|'.join(sorted(names))
        cache = load_json(cache_file, {})
        hit = cache.get(key)
        if hit and time.time() - hit.get('t', 0) < ttl and hit.get('ids'):
            return hit['ids']
        want = set(_alnum(n) for n in names)
        ids = set()
        for q in queries:
            data = self._get('search/keyword', {'query': q}) or {}
            for r in data.get('results') or []:
                if r.get('id') and _alnum(r.get('name')) in want:
                    ids.add(int(r['id']))
        ids = sorted(ids)
        if ids:
            cache[key] = {'t': int(time.time()), 'ids': ids}
            save_json(cache_file, cache)
        log('TMDb keywords for %s: %s' % (', '.join(queries), ids or 'none found'))
        return ids

    def discover_keywords(self, ctype, keyword_ids, langs, year_min, year_max, page=1, min_votes=1):
        """Films (or shows) tagged with any of keyword_ids, in the original languages given,
        released in the year range, best TMDb rating first."""
        is_show = ctype == 'show'
        date = 'first_air_date' if is_show else 'primary_release_date'
        params = {'with_keywords': '|'.join(str(i) for i in keyword_ids),
                  'with_original_language': '|'.join(langs), 'include_adult': 'false',
                  date + '.gte': '%d-01-01' % year_min, date + '.lte': '%d-12-31' % year_max,
                  'sort_by': 'vote_average.desc', 'vote_count.gte': min_votes, 'page': page}
        data = self._get('discover/tv' if is_show else 'discover/movie', params) or {}
        results = data.get('results') or []
        has_more = (data.get('page') or page) < min(data.get('total_pages') or 0, 500)
        return [placeholder(r, None, ctype) for r in results if r.get('id')], has_more

    # ------------------------------------------------------------ people (actor / director search)
    def search_people(self, name):
        """People matching a name, most popular first."""
        data = self._get('search/person', {'query': name, 'include_adult': 'false'}) or {}
        return [p for p in (data.get('results') or []) if p.get('id')]

    def person_titles(self, pid, role='actor', ctype='movie'):
        """Main films (or shows) of a person, highest rated first.

        role: 'actor' (cast credits) or 'director' (crew credits with job Director).
        ctype: 'movie' or 'show'."""
        path = 'person/%s/%s' % (pid, 'tv_credits' if ctype == 'show' else 'movie_credits')
        data = self._get(path, {}) or {}
        if role == 'director':
            credits = [c for c in (data.get('crew') or []) if c.get('job') == 'Director']
        else:
            credits = [c for c in (data.get('cast') or []) if _main_role(c, ctype)]
        today = time.strftime('%Y-%m-%d')
        seen, out = set(), []
        for c in credits:
            if not c.get('id') or c['id'] in seen:
                continue
            date = c.get('release_date') or c.get('first_air_date') or ''
            if not date or date > today:
                continue  # not released yet: no torrents and no rating
            if int(c.get('vote_count') or 0) < MIN_VOTES:
                continue  # obscure title, almost never on TorrentClaw
            if set(c.get('genre_ids') or []) & NON_FICTION_TV:
                continue
            seen.add(c['id'])
            out.append(c)
        out.sort(key=lambda c: (float(c.get('vote_average') or 0), int(c.get('vote_count') or 0)),
                 reverse=True)
        items = []
        for c in out:
            it = placeholder(c, None, ctype)
            if role == 'actor' and c.get('character'):
                it['overview'] = '[B]As:[/B] %s\n\n%s' % (c['character'], it.get('overview') or '')
            items.append(it)
        return items


    # ------------------------------------------------------------ author search
    def author_titles(self, pid, ctypes):
        """Films and/or shows based on a writer's work: novel/book/short story, screenplay/writer,
        characters and story credits. ctypes: list of 'movie' and/or 'show'.

        Released titles only; each item carries '_credits' (e.g. ['Novel', 'Screenplay'])."""
        today = time.strftime('%Y-%m-%d')
        found, order = {}, []
        for ctype in ctypes:
            path = 'person/%s/%s' % (pid, 'tv_credits' if ctype == 'show' else 'movie_credits')
            data = self._get(path, {}) or {}
            for c in data.get('crew') or []:
                label = AUTHOR_JOBS.get((c.get('job') or '').strip().lower())
                if not label or not c.get('id'):
                    continue
                date = c.get('release_date') or c.get('first_air_date') or ''
                if not date or date > today:
                    continue  # not released yet
                if ctype == 'show' and set(c.get('genre_ids') or []) & NON_FICTION_TV:
                    continue
                key = (ctype, c['id'])
                if key not in found:
                    found[key] = (c, [])
                    order.append(key)
                if label not in found[key][1]:
                    found[key][1].append(label)
        items = []
        for key in order:
            c, labels = found[key]
            it = placeholder(c, None, key[0])
            it['_credits'] = labels
            it['overview'] = '[B]From the author:[/B] %s\n\n%s' % (', '.join(labels), it.get('overview') or '')
            items.append(it)
        return items

    def imdb_id(self, ctype, tmdb_id):
        """IMDb id (tt...) of a TMDb movie or show, '' if TMDb has none."""
        data = self._get('%s/%s/external_ids' % ('tv' if ctype == 'show' else 'movie', tmdb_id), {}) or {}
        return data.get('imdb_id') or ''

    # ------------------------------------------------------------ TMDb account (watchlist, lists)
    def request_token(self):
        return (self._call('GET', 'authentication/token/new') or {}).get('request_token') or ''

    def create_session(self, request_token):
        data = self._call('POST', 'authentication/session/new', json_body={'request_token': request_token}) or {}
        return data.get('session_id') or ''

    def delete_session(self, session_id):
        self._call('DELETE', 'authentication/session', json_body={'session_id': session_id})

    def account(self, session_id):
        return self._get('account', {'session_id': session_id}) or {}

    def watchlist_add(self, session_id, account_id, media_type, media_id):
        """media_type 'movie' or 'tv'."""
        return self._call('POST', 'account/%s/watchlist' % account_id, {'session_id': session_id},
                          {'media_type': media_type, 'media_id': int(media_id), 'watchlist': True})

    def watchlist(self, session_id, account_id, ctype, page=1):
        data = self._get('account/%s/watchlist/%s' % (account_id, 'tv' if ctype == 'show' else 'movies'),
                         {'session_id': session_id, 'page': page, 'sort_by': 'created_at.desc'}) or {}
        has_more = (data.get('page') or page) < (data.get('total_pages') or 0)
        return [placeholder(r, None, ctype) for r in data.get('results') or [] if r.get('id')], has_more

    def my_lists(self, session_id, account_id, max_pages=5):
        out = []
        for page in range(1, max_pages + 1):
            data = self._get('account/%s/lists' % account_id, {'session_id': session_id, 'page': page}) or {}
            out += [l for l in data.get('results') or [] if l.get('id')]
            if page >= (data.get('total_pages') or 0):
                break
        return out

    def create_list(self, session_id, name):
        data = self._call('POST', 'list', {'session_id': session_id},
                          {'name': name, 'description': 'Made from Kodi', 'language': 'en'}) or {}
        return data.get('list_id')

    def list_add(self, session_id, list_id, media_id):
        """Movies only: TMDb's v3 lists do not take TV shows."""
        return self._call('POST', 'list/%s/add_item' % list_id, {'session_id': session_id},
                          {'media_id': int(media_id)})


# Writing credits that count as "based on the author's work" -> label shown to the user
AUTHOR_JOBS = {
    'novel': 'Novel', 'book': 'Book', 'novella': 'Novella', 'short story': 'Short story', 'author': 'Book',
    'screenplay': 'Screenplay', 'writer': 'Writer', 'teleplay': 'Teleplay', 'scenario writer': 'Screenplay',
    'co-writer': 'Writer', 'characters': 'Characters', 'character': 'Characters',
    'story': 'Story', 'original story': 'Story', 'screenstory': 'Story',
}


def _alnum(text):
    return ''.join(c for c in (text or '').lower() if c.isalnum())


# TMDb vote floor for "main films only"; low enough for regional (e.g. Malayalam) films
MIN_VOTES = 10
# TV genres that are not acting/directing work: News, Reality, Talk
NON_FICTION_TV = {10763, 10764, 10767}
_SELF = ('himself', 'herself', 'themselves', 'self')


def _main_role(c, ctype):
    """True for a real acting role: not uncredited, a cameo as themselves, or a one-off TV guest spot."""
    ch = (c.get('character') or '').lower()
    if 'uncredited' in ch or ch.strip() in _SELF or ch.startswith(('himself', 'herself', 'self ')):
        return False
    if ctype == 'show' and int(c.get('episode_count') or 0) < 2:
        return False
    return True


def person_label(p):
    """'Acting · Known for A, B' line for the person picker."""
    known = [k.get('title') or k.get('name') for k in (p.get('known_for') or []) if k.get('title') or k.get('name')]
    s = p.get('known_for_department') or ''
    if known:
        s += (' · ' if s else '') + 'Known for ' + ', '.join(known[:3])
    return s


def person_photo(p):
    return (IMG + 'w185' + p['profile_path']) if p.get('profile_path') else ''


def placeholder(r, country='IN', ctype='movie'):
    """A TorrentClaw-shaped item built from a TMDb result; resolved later.

    country None: take the title's own origin country from TMDb (if given)."""
    is_show = ctype == 'show'
    year = (r.get('first_air_date' if is_show else 'release_date') or '')[:4]
    title = (r.get('name') or r.get('original_name')) if is_show else (r.get('title') or r.get('original_title'))
    original = r.get('original_name' if is_show else 'original_title') or ''
    countries = [country] if country else list(r.get('origin_country') or [])
    item = {'id': 'tmdb%s:%s' % ('tv' if is_show else '', r['id']), 'tmdbId': r['id'],
            'contentType': 'show' if is_show else 'movie',
            'title': title or '', 'titleOriginal': original,
            'overview': r.get('overview') or '', 'originCountry': countries,
            'originalLanguage': r.get('original_language') or '', '_placeholder': True}
    if year.isdigit():
        item['year'] = int(year)
    if r.get('poster_path'):
        item['posterUrl'] = IMG + 'w500' + r['poster_path']
    if r.get('backdrop_path'):
        item['backdropUrl'] = IMG + 'w1280' + r['backdrop_path']
    try:
        if float(r.get('vote_average') or 0) > 0 and int(r.get('vote_count') or 0) >= 3:
            item['ratingTmdb'] = float(r['vote_average'])
    except (TypeError, ValueError):
        pass
    return item
