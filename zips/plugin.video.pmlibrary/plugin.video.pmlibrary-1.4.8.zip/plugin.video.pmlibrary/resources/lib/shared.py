# -*- coding: utf-8 -*-
"""Manual matches shared between Shields through a small file in the Premiumize cloud.

Every Shield keeps its matches in overrides.json (sections files / shows / episodes).
Each change is also recorded in overrides['_items'] as "<section>:<key>" ->
{'v': value or None (removed), 't': time of the change}. The items of all Shields are
merged (the newest change of each key wins; a tie goes to the cloud copy) and stored
as JSON in a folder in the user's Premiumize cloud, which every Shield can read.
"""
import json
import time

from . import net, utils

FOLDER = 'Kodi Premiumize Library - shared matches'
FILENAME = 'manual-matches.json'
SECTIONS = ('files', 'shows', 'episodes')
LEGACY_TIME = 1        # matches made before sharing existed


class SharedError(Exception):
    pass


# ------------------------------------------------------------------ local items

def items_of(overrides):
    """The change log of these overrides, created from older overrides when missing."""
    for section in SECTIONS:
        overrides.setdefault(section, {})
    items = overrides.setdefault('_items', {})
    for section in SECTIONS:
        for key, value in overrides[section].items():
            items.setdefault('%s:%s' % (section, key), {'v': value, 't': LEGACY_TIME})
    return items


def set_match(overrides, section, key, value, now=None):
    """Set (or with value None remove) one match and record the change."""
    items = items_of(overrides)
    if value is None:
        if key not in overrides[section] and '%s:%s' % (section, key) not in items:
            return
        overrides[section].pop(key, None)
    else:
        overrides[section][key] = value
    items['%s:%s' % (section, key)] = {'v': value, 't': time.time() if now is None else now}


def rebuild(overrides):
    """Make the sections match the change log."""
    items = items_of(overrides)
    for section in SECTIONS:
        overrides[section] = {}
    for name, item in items.items():
        section, _, key = name.partition(':')
        if section in SECTIONS and item.get('v') is not None:
            overrides[section][key] = item['v']


def merge(local, remote):
    """Merge two change logs. Returns (merged, names whose local value changed)."""
    merged = dict(local)
    changed = set()
    for name, theirs in (remote or {}).items():
        if not isinstance(theirs, dict) or 't' not in theirs:
            continue
        mine = local.get(name)
        if mine is None or theirs['t'] > mine.get('t', 0) or \
                (theirs['t'] == mine.get('t', 0) and theirs.get('v') != mine.get('v')):
            merged[name] = theirs
            if (mine or {}).get('v') != theirs.get('v'):
                changed.add(name)
    return merged, changed


def affected_files(names, index_files):
    """Library file ids that must be processed again after these matches changed."""
    ids = set()
    for name in names:
        section, _, key = name.partition(':')
        if section in ('files', 'episodes'):
            ids.add(key)
        elif section == 'shows':
            ids.update(fid for fid, e in index_files.items() if e.get('tkey') == key)
    return ids


# ------------------------------------------------------------------ cloud copy

class CloudCopy(object):
    """Reads and writes the shared file in the Premiumize cloud."""

    def __init__(self, pm):
        self.pm = pm

    def folder_id(self, create=False):
        root = self.pm.list_folder(None)
        for item in root.get('content') or []:
            if item.get('type') == 'folder' and item.get('name') == FOLDER:
                return str(item['id'])
        if not create:
            return None
        return str(self.pm.create_folder(FOLDER).get('id') or '') or self.folder_id(False)

    def _copies(self, folder):
        listing = self.pm.list_folder(folder)
        files = [i for i in listing.get('content') or []
                 if i.get('type') != 'folder' and i.get('name') == FILENAME]
        return sorted(files, key=lambda i: (i.get('created_at') or 0, str(i.get('id'))))

    @staticmethod
    def signature(copies):
        return ','.join(str(c.get('id')) for c in copies)

    def peek(self):
        """Cheap check: a string that changes whenever the shared file changes ('' = none)."""
        folder = self.folder_id(False)
        return self.signature(self._copies(folder)) if folder else ''

    def read(self):
        """Returns (items, folder id or None, copies). Raises SharedError if unreadable."""
        folder = self.folder_id(False)
        if not folder:
            return {}, None, []
        copies = self._copies(folder)
        items = {}
        for copy in copies:     # normally one; several only if two Shields wrote at once
            raw = net.get_bytes(copy.get('link') or '') if copy.get('link') else None
            if raw is None:
                raise SharedError('could not download the shared matches file')
            try:
                doc = json.loads(raw.decode('utf-8'))
            except ValueError:
                utils.log('Ignoring an unreadable shared matches file')
                continue
            items = merge(items, doc.get('items') or {})[0]
        return items, folder, copies

    def write(self, items, folder, old_copies):
        """Upload the merged file, then remove the copies it replaces. Returns the new signature."""
        folder = folder or self.folder_id(True)
        if not folder:
            raise SharedError('could not create the shared folder')
        body = json.dumps({'version': 1, 'app': utils.ADDON_ID, 'items': items},
                          ensure_ascii=False, sort_keys=True).encode('utf-8')
        info = self.pm.upload_info(folder)
        net.post_file(info['url'], {'token': info['token']}, FILENAME, body)
        for copy in old_copies:
            try:
                self.pm.delete_item(copy['id'])
            except Exception as exc:  # noqa: BLE001 - an extra copy is merged next time
                utils.log('Could not remove an old shared matches file: %s' % exc)
        return self.signature(self._copies(folder))
