# -*- coding: utf-8 -*-
"""Premiumize.me API client (only the calls this add-on needs)."""
import time

from . import net

API_BASE = 'https://www.premiumize.me/api'


class PremiumizeError(Exception):
    pass


class AuthError(PremiumizeError):
    pass


def _looks_like_auth_error(text):
    low = text.lower()
    return ('logged in' in low or 'api key' in low or 'apikey' in low
            or 'customer_id' in low or 'invalid token' in low)


class Premiumize(object):
    def __init__(self, api_key, sleeper=time.sleep, abort=None):
        self.api_key = api_key
        self.sleeper = sleeper
        self.abort = abort

    def _call(self, endpoint, params=None, data=None):
        headers = {'Authorization': 'Bearer %s' % self.api_key}
        for attempt in range(4):
            try:
                status, data = net.get_json('%s/%s' % (API_BASE, endpoint), params=params,
                                            headers=headers, sleeper=self.sleeper,
                                            abort=self.abort, data=data,
                                            retries=3 if data is None else 1)
            except net.NetError as exc:
                raise PremiumizeError(str(exc))
            if status in (401, 403):
                raise AuthError('Premiumize rejected the API key')
            if not isinstance(data, dict):
                raise PremiumizeError('Unexpected response from Premiumize (HTTP %s)' % status)
            if data.get('status') == 'success':
                return data
            message = str(data.get('message') or data.get('error') or 'Premiumize error')
            low = (message + ' ' + str(data.get('error', ''))).lower()
            if 'rate_limit' in low or 'too many' in low:
                self.sleeper(5 * (attempt + 1))
                continue
            if _looks_like_auth_error(low):
                raise AuthError(message)
            raise PremiumizeError(message)
        raise PremiumizeError('Premiumize rate limit reached, try again later')

    # ------------------------------------------------------------- endpoints

    def account_info(self):
        return self._call('account/info')

    def list_folder(self, folder_id=None):
        params = {'id': folder_id} if folder_id else None
        return self._call('folder/list', params)

    def details(self, file_id):
        return self._call('item/details', {'id': file_id})

    def create_folder(self, name, parent_id=None):
        data = {'name': name}
        if parent_id:
            data['parent_id'] = parent_id
        return self._call('folder/create', data=data)

    def upload_info(self, folder_id=None):
        """{'token', 'url'} for one upload into folder_id (the token is single-use)."""
        return self._call('folder/uploadinfo', {'id': folder_id} if folder_id else None)

    def delete_item(self, file_id):
        return self._call('item/delete', data={'id': file_id})

    def delete_folder(self, folder_id):
        return self._call('folder/delete', data={'id': folder_id})

    # ----------------------------------------------------------------- files

    @staticmethod
    def _normalize(item, dirs):
        try:
            size = int(item.get('size') or 0)
        except (TypeError, ValueError):
            size = 0
        return {
            'id': str(item['id']),
            'name': item.get('name') or '',
            'size': size,
            'mime': item.get('mime_type') or '',
            'dirs': dirs,
        }

    def list_files(self):
        """All files in the cloud as dicts: id, name, size, mime, dirs (folder names)."""
        try:
            data = self._call('item/listall')
            files = data.get('files')
            if isinstance(files, list):
                if not files:
                    return []
                if all('path' in entry and 'id' in entry for entry in files):
                    return [self._normalize(entry, self._dirs_from_path(entry)) for entry in files]
        except AuthError:
            raise
        except PremiumizeError:
            pass  # fall back to walking the folder tree
        return list(self._walk())

    @staticmethod
    def _dirs_from_path(entry):
        parts = [p for p in (entry.get('path') or '').split('/') if p]
        if parts and parts[-1] == entry.get('name'):
            parts.pop()
        return parts

    def _walk(self):
        stack = [(None, [])]
        while stack:
            if self.abort and self.abort():
                raise net.Aborted()
            folder_id, dirs = stack.pop()
            data = self.list_folder(folder_id)
            for item in data.get('content') or []:
                if item.get('type') == 'folder':
                    stack.append((item['id'], dirs + [item.get('name') or '']))
                elif 'id' in item:
                    yield self._normalize(item, dirs)

    # --------------------------------------------------------------- playback

    def resolve_link(self, file_id):
        """Return a fresh direct download URL for a file."""
        details = self.details(file_id)
        url = details.get('link')
        if not url and details.get('folder_id'):
            listing = self.list_folder(details['folder_id'])
            for item in listing.get('content') or []:
                if str(item.get('id')) == str(file_id) and item.get('link'):
                    url = item['link']
                    break
        if not url:
            raise PremiumizeError('Premiumize returned no playable link for this file')
        return url
