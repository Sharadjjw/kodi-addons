# -*- coding: utf-8 -*-
"""Small HTTP helper shared by the Premiumize, TMDb and OMDb clients.

Error messages never include the request URL, because URLs carry API keys.
"""
import time

import requests

USER_AGENT = 'plugin.video.pmlibrary/1.0'

_session = None


class NetError(Exception):
    """Network failure or unusable HTTP response (message is safe to log)."""

    def __init__(self, message, status=None):
        Exception.__init__(self, message)
        self.status = status


class Aborted(Exception):
    """Raised when Kodi is shutting down or the user cancelled."""


def _get_session():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update({'User-Agent': USER_AGENT})
    return _session


def get_bytes(url, timeout=30, attempts=3, sleeper=time.sleep):
    """Body of a plain GET (with retries on dropped connections), or None."""
    for attempt in range(attempts):
        try:
            resp = _get_session().get(url, timeout=timeout)
            if resp.status_code < 400:
                return resp.content
            if resp.status_code < 500:
                return None
        except requests.RequestException:
            pass
        if attempt < attempts - 1:
            sleeper(2 * (attempt + 1))
    return None


def url_ok(url, timeout=8):
    """True when the server answers a one-byte ranged GET for url with success."""
    try:
        resp = _get_session().get(url, headers={'Range': 'bytes=0-0'}, stream=True,
                                  timeout=timeout, allow_redirects=True)
        try:
            return resp.status_code in (200, 206)
        finally:
            resp.close()
    except requests.RequestException:
        return False


def measure(url, max_bytes=1536 * 1024, max_seconds=1.5, timeout=5):
    """Download speed of url in bytes per second, from a short ranged read.

    Reads up to max_bytes or for max_seconds (whichever comes first), counting the
    time to the first byte too. Returns 0 when the server does not answer usefully.
    """
    started = time.time()
    try:
        resp = _get_session().get(url, headers={'Range': 'bytes=0-%d' % (max_bytes - 1)},
                                  stream=True, timeout=timeout, allow_redirects=True)
    except requests.RequestException:
        return 0
    got = 0
    try:
        if resp.status_code not in (200, 206):
            return 0
        for chunk in resp.iter_content(chunk_size=65536):
            got += len(chunk)
            if got >= max_bytes or time.time() - started >= max_seconds:
                break
    except requests.RequestException:
        pass
    finally:
        resp.close()
    elapsed = max(time.time() - started, 0.05)
    return int(got / elapsed) if got >= 64 * 1024 else 0


def post_file(url, fields, filename, content, timeout=60):
    """multipart/form-data POST of one file (form field 'file'). Raises NetError on failure."""
    try:
        resp = _get_session().post(url, data=fields, files={'file': (filename, content, 'application/json')},
                                   timeout=timeout)
    except requests.RequestException as exc:
        raise NetError('Upload failed (%s)' % type(exc).__name__)
    if resp.status_code >= 400:
        raise NetError('HTTP %d from server' % resp.status_code, resp.status_code)
    try:
        payload = resp.json()
    except ValueError:
        payload = None
    if isinstance(payload, dict) and payload.get('status') not in (None, 'success'):
        raise NetError('Upload refused: %s' % (payload.get('message') or payload.get('status')))
    return payload


def get_json(url, params=None, headers=None, timeout=30, retries=3,
             sleeper=time.sleep, abort=None, data=None):
    """GET url (or POST the form fields in data) and return (http_status, parsed_json_or_None).

    Retries network errors, HTTP 429 and 5xx with backoff. Other HTTP errors
    are returned to the caller together with any JSON body, because the APIs
    used here report problems (bad key, rate limit) in the body.
    """
    last = None
    for attempt in range(retries + 1):
        if abort and abort():
            raise Aborted()
        try:
            if data is None:
                resp = _get_session().get(url, params=params, headers=headers, timeout=timeout)
            else:
                resp = _get_session().post(url, params=params, data=data, headers=headers,
                                           timeout=timeout)
        except (requests.ConnectionError, requests.Timeout) as exc:
            last = NetError('Network error (%s)' % type(exc).__name__)
            if attempt < retries:
                sleeper(min(2 ** attempt, 8))
                continue
            raise last
        except requests.RequestException as exc:
            raise NetError('Request failed (%s)' % type(exc).__name__)

        if resp.status_code == 429 or resp.status_code >= 500:
            last = NetError('HTTP %d from server' % resp.status_code, resp.status_code)
            if attempt < retries:
                try:
                    wait = float(resp.headers.get('Retry-After', ''))
                except ValueError:
                    wait = 2 ** attempt
                sleeper(max(1, min(wait, 30)))
                continue
            raise last

        try:
            payload = resp.json()
        except ValueError:
            payload = None
        if resp.status_code >= 400 and payload is None:
            raise NetError('HTTP %d from server' % resp.status_code, resp.status_code)
        return resp.status_code, payload
    raise last or NetError('Request failed')
