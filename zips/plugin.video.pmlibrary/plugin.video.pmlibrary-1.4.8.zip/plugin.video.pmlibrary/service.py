# -*- coding: utf-8 -*-
"""Background service: runs the library sync on start-up, on a schedule and on request."""
import threading
import time
import traceback

import xbmc
import xbmcgui

from resources.lib import net, premiumize, shared, subfetch, sync, utils, vaultui

RUNNING = 'pmlib.running'
REQUEST = 'pmlib.request'
STARTUP_DELAY = 45          # seconds after Kodi starts before the first sync
RETRY_GAP = 30 * 60         # minimum seconds between automatic attempts
SHARED_POLL = 15 * 60       # how often to look for matches made on another Shield


def shared_changed():
    """True when another Shield changed the shared manual matches since our last sync."""
    key = utils.setting('pm_api_key').strip()
    if not key or not utils.setting_bool('share_matches', True):
        return False
    try:
        signature = shared.CloudCopy(premiumize.Premiumize(key)).peek()
    except Exception as exc:  # noqa: BLE001 - offline, rate limited...: try again later
        utils.log('Could not check the shared matches: %s' % exc)
        return False
    seen = utils.load_json(sync.STATE_FILE, {}).get('shared_seen')
    return signature != (seen or '') if seen is not None or signature else False


def run_sync(monitor, mode):
    win = utils.home_window()
    if win.getProperty(RUNNING) == '1':
        return
    manual = mode != 'auto'
    win.setProperty(RUNNING, '1')
    state = utils.load_json(sync.STATE_FILE, {})
    state['last_attempt'] = time.time()
    utils.save_json(sync.STATE_FILE, state)
    try:
        engine = sync.SyncEngine(monitor)
        summary = engine.run('rebuild' if mode == 'rebuild' else 'sync')
        if summary.get('aborted'):
            return
        message = sync.format_summary(summary)
        if manual or sync.has_changes(summary):
            utils.notify('Sync finished: %s' % message)
    except sync.SyncError as exc:
        utils.notify(str(exc), icon=xbmcgui.NOTIFICATION_ERROR, ms=8000)
    except premiumize.AuthError:
        utils.notify('Premiumize rejected the API key. Check it in the settings.',
                     icon=xbmcgui.NOTIFICATION_ERROR, ms=8000)
    except premiumize.PremiumizeError as exc:
        utils.notify('Premiumize problem: %s' % exc, icon=xbmcgui.NOTIFICATION_ERROR, ms=8000)
    except net.Aborted:
        pass
    except Exception:  # noqa: BLE001 - never let the service die
        utils.log('Sync crashed:\n%s' % traceback.format_exc(), xbmc.LOGERROR)
        utils.notify('Sync failed, see the Kodi log for details.',
                     icon=xbmcgui.NOTIFICATION_ERROR, ms=8000)
    finally:
        win.clearProperty(RUNNING)


def start_subtitle_worker():
    thread = threading.Thread(target=subfetch.worker, args=(xbmc.Monitor(),), name='pmlib-subtitles')
    thread.daemon = True
    thread.start()
    return thread


def start_settings_check():
    """Offer to fill in keys from the private repository on a Shield that is not set up yet."""
    thread = threading.Thread(target=vaultui.startup_check, args=(xbmc.Monitor(),), name='pmlib-settings')
    thread.daemon = True
    thread.start()
    return thread


def main():
    monitor = xbmc.Monitor()
    win = utils.home_window()
    win.clearProperty(RUNNING)
    win.clearProperty(REQUEST)
    start_subtitle_worker()
    start_settings_check()
    if monitor.waitForAbort(STARTUP_DELAY):
        return
    first = True
    last_peek = time.time()
    while not monitor.abortRequested():
        mode = win.getProperty(REQUEST)
        if mode:
            win.clearProperty(REQUEST)
        elif not first and time.time() - last_peek >= SHARED_POLL and win.getProperty(RUNNING) != '1':
            last_peek = time.time()
            if shared_changed():
                utils.log('Manual matches changed on another Shield; syncing')
                mode = 'auto'
        elif utils.setting('pm_api_key').strip():
            state = utils.load_json(sync.STATE_FILE, {})
            now = time.time()
            since_attempt = now - state.get('last_attempt', 0)
            interval = utils.setting_int('sync_interval', 12) * 3600
            if first and utils.setting_bool('sync_on_start', True) and since_attempt >= RETRY_GAP:
                mode = 'auto'
            elif interval and now - state.get('last_run', 0) >= interval and since_attempt >= RETRY_GAP:
                mode = 'auto'
        first = False
        if mode:
            run_sync(monitor, mode)
        if monitor.waitForAbort(2):
            break


if __name__ == '__main__':
    main()
