# -*- coding: utf-8 -*-
"""How long a video took to start, split into the add-on's part and Kodi's part.

The play action notes its own timings just before it hands the link to Kodi
(note_resolved). The service's Player (StartWatcher) sees the first picture
(onAVStarted) and reports: the add-on part (Python start-up, index, link, subtitles)
and the Kodi part (opening the stream, reading the file, buffering, refresh-rate
switch, seeking to the resume point).
"""
import json
import time

import xbmc

from . import utils

PROP = 'pmlib.starttime'
STALE = 180          # seconds: an older note belongs to a video that never started


def note_resolved(t0, parts, name='', now=None):
    """parts: list of (label, seconds) for the add-on's steps, in order."""
    utils.home_window().setProperty(PROP, json.dumps({
        't0': t0, 'resolved': time.time() if now is None else now,
        'parts': [[label, round(float(sec), 3)] for label, sec in parts], 'name': name}))


def secs(value):
    return '%.1f s' % value


def summary(data, now):
    """(log line, pop-up text) or (None, None) for a missing or stale note."""
    try:
        t0 = float(data['t0'])
        resolved = float(data['resolved'])
    except (KeyError, TypeError, ValueError):
        return None, None
    if now - resolved > STALE or now < resolved:
        return None, None
    addon = max(resolved - t0, 0.0)
    kodi = now - resolved
    total = addon + kodi
    steps = ', '.join('%s %s' % (label, secs(sec)) for label, sec in data.get('parts') or [])
    line = ('Start-up time %s: add-on %s (%s) + Kodi opening the video %s%s'
            % (secs(total), secs(addon), steps, secs(kodi),
               (' - %s' % data['name']) if data.get('name') else ''))
    popup = 'Started in %s  (add-on %s, Kodi %s)' % (secs(total), secs(addon), secs(kodi))
    return line, popup


def report(now=None):
    win = utils.home_window()
    raw = win.getProperty(PROP)
    if not raw:
        return None
    win.clearProperty(PROP)
    try:
        data = json.loads(raw)
    except ValueError:
        return None
    line, popup = summary(data, time.time() if now is None else now)
    if not line:
        return None
    utils.log(line)
    if utils.setting_bool('start_notify', True):
        utils.notify(popup, heading='Start-up time', ms=6000)
    return line


class StartWatcher(xbmc.Player):
    """Created once by the service; Kodi calls these when playback events happen."""

    def onAVStarted(self):
        try:
            report()
        except Exception as exc:  # noqa: BLE001 - never disturb playback
            utils.log('Start-up timing failed: %s' % type(exc).__name__, xbmc.LOGWARNING)

    def onPlayBackError(self):
        utils.home_window().clearProperty(PROP)

    def onPlayBackStopped(self):
        utils.home_window().clearProperty(PROP)
