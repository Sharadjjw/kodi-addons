# -*- coding: utf-8 -*-
"""Back on the Home screen: from a tile, jump to the left menu; from the menu, normal Back
(which returns to the playing video). Run by the keymap installed by resources/lib/keymap.py."""
import xbmc

MENU = 9000  # Estuary's left menu

if xbmc.getCondVisibility('Control.HasFocus(%d)' % MENU):
    xbmc.executebuiltin('Action(Back)')
else:
    xbmc.executebuiltin('Control.SetFocus(%d)' % MENU)
