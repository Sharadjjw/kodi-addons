# -*- coding: utf-8 -*-
"""PIN-locked settings shared through the add-on delivery repository.

A configured Shield creates `locked-settings.json` (settings of this add-on and
TorrentClaw, locked with a PIN). It is stored next to the add-on zips, under
settings/ of the delivery repository that repository.sjjkodi points to. That
repository is public, so the file is only as strong as the PIN: many PBKDF2
rounds make every guess slow, and the PIN must be at least MIN_PIN characters.
A new Shield downloads it, asks for the PIN once and fills in its settings.

The lock uses only the Python standard library, so nothing extra is installed:
  key   = PBKDF2-HMAC-SHA256(PIN, random salt, many rounds) -> encryption + MAC keys
  text  = settings JSON XOR keystream, keystream = HMAC-SHA256(enc key, nonce|counter)
  tag   = HMAC-SHA256(mac key, header|salt|nonce|ciphertext), checked before decrypting
A wrong PIN fails the tag check; nothing is decrypted with it.
Nothing here writes keys or the PIN to the log.
"""
import base64
import hashlib
import hmac
import json
import os
import re
import struct
import time

from . import utils

FILE_NAME = 'locked-settings.json'
FORMAT = 'sjjkodi-locked-settings'
ROUNDS = 600000          # slow on purpose: the file sits in a public repository
MIN_PIN = 8
REPO_ADDON = 'repository.sjjkodi'
TC_ID = 'plugin.video.torrentclaw'

# Settings copied to other Shields. library_path is left out on purpose: a Shield Pro
# may keep its library on a USB drive the regular Shield does not have.
PM_KEYS = tuple(k for k in utils.EXPORT_KEYS if k != 'library_path')
TC_KEYS = ('tc_apikey', 'tc_mirror', 'pm_apikey', 'tmdb_key', 'lang_filter', 'min_quality', 'torrent_sort',
           'hide_dead', 'hide_no_torrents', 'check_cache', 'folder_movies', 'folder_shows',
           'autoplay_largest', 'subs_enabled', 'os_apikey', 'os_username', 'os_password',
           'subs_only_missing', 'subs_moviehash', 'subs_exclude_hi',
           'src_rutracker', 'rt_username', 'rt_password')
# The setting that tells whether an add-on has been set up on this Shield yet.
MAIN_KEY = {utils.ADDON_ID: 'pm_api_key', TC_ID: 'tc_apikey'}


class WrongPin(Exception):
    pass


class VaultError(Exception):
    """Message is safe to show to the user."""


# ------------------------------------------------------------------ crypto

def _keys(pin, salt, rounds):
    raw = hashlib.pbkdf2_hmac('sha256', pin.encode('utf-8'), salt, rounds, dklen=64)
    return raw[:32], raw[32:]


def _stream(key, nonce, length):
    out = bytearray()
    counter = 0
    while len(out) < length:
        out += hmac.new(key, nonce + struct.pack('>Q', counter), hashlib.sha256).digest()
        counter += 1
    return bytes(out[:length])


def _xor(data, stream):
    return bytes(a ^ b for a, b in zip(data, stream))


def _header(rounds):
    return ('%s|1|%d' % (FORMAT, rounds)).encode('ascii')


def lock(data, pin, rounds=ROUNDS):
    """Lock bytes with a PIN. Returns a JSON-ready dict."""
    salt, nonce = os.urandom(16), os.urandom(16)
    enc_key, mac_key = _keys(pin, salt, rounds)
    ct = _xor(data, _stream(enc_key, nonce, len(data)))
    tag = hmac.new(mac_key, _header(rounds) + salt + nonce + ct, hashlib.sha256).digest()
    b64 = lambda b: base64.b64encode(b).decode('ascii')
    return {'format': FORMAT, 'version': 1, 'rounds': rounds, 'created': int(time.time()),
            'salt': b64(salt), 'nonce': b64(nonce), 'data': b64(ct), 'tag': b64(tag)}


def unlock(box, pin):
    """Bytes from a locked dict. Raises WrongPin, or VaultError for a damaged file."""
    try:
        if box.get('format') != FORMAT or int(box.get('version', 0)) != 1:
            raise ValueError
        rounds = int(box['rounds'])
        salt, nonce, ct, tag = (base64.b64decode(box[k]) for k in ('salt', 'nonce', 'data', 'tag'))
    except (KeyError, TypeError, ValueError, AttributeError):
        raise VaultError('The locked settings file is damaged or not a settings file.')
    if not 1000 <= rounds <= 5000000:
        raise VaultError('The locked settings file is damaged or not a settings file.')
    enc_key, mac_key = _keys(pin, salt, rounds)
    want = hmac.new(mac_key, _header(rounds) + salt + nonce + ct, hashlib.sha256).digest()
    if not hmac.compare_digest(want, tag):
        raise WrongPin()
    return _xor(ct, _stream(enc_key, nonce, len(ct)))


# --------------------------------------------------------------- settings

def _tc_addon():
    import xbmcaddon
    try:
        return xbmcaddon.Addon(TC_ID)
    except Exception:  # noqa: BLE001 - raised when TorrentClaw is not installed
        return None


def _addon_for(addon_id):
    return utils.addon() if addon_id == utils.ADDON_ID else _tc_addon()


def collect():
    """This Shield's settings for both add-ons: {addon_id: {key: value}}."""
    from . import playback
    out = {utils.ADDON_ID: dict((k, utils.setting(k)) for k in PM_KEYS)}
    if not out[utils.ADDON_ID].get('pm_dir_url'):
        base, _where = playback.find_dir_link()   # carry the HTTP folder link found in Kodi's sources
        if base:
            out[utils.ADDON_ID]['pm_dir_url'] = base
    tc = _tc_addon()
    if tc is not None:
        out[TC_ID] = dict((k, tc.getSetting(k)) for k in TC_KEYS)
    return out


def needs_setup():
    """Add-on ids installed here whose main key is still empty (a fresh Shield)."""
    fresh = []
    for addon_id, key in MAIN_KEY.items():
        addon = _addon_for(addon_id)
        if addon is not None and not (addon.getSetting(key) or '').strip():
            fresh.append(addon_id)
    return fresh


def apply(bundle, only=None):
    """Write the bundle's settings. only: add-on ids to fill (None = all installed).

    Returns {addon_id: number of settings written}."""
    allowed = {utils.ADDON_ID: set(PM_KEYS), TC_ID: set(TC_KEYS)}
    done = {}
    for addon_id, values in (bundle.get('addons') or {}).items():
        if addon_id not in allowed or (only is not None and addon_id not in only):
            continue
        addon = _addon_for(addon_id)
        if addon is None or not isinstance(values, dict):
            continue
        count = 0
        for key, value in values.items():
            if key in allowed[addon_id] and value is not None:
                addon.setSetting(key, str(value))
                count += 1
        done[addon_id] = count
    return done


def make_bundle():
    return {'addons': collect(), 'made': int(time.time())}


def lock_bundle(bundle, pin):
    return lock(json.dumps(bundle, sort_keys=True).encode('utf-8'), pin)


def unlock_bundle(box, pin):
    try:
        bundle = json.loads(unlock(box, pin).decode('utf-8'))
    except (ValueError, UnicodeDecodeError):
        raise VaultError('The locked settings file is damaged.')
    if not isinstance(bundle, dict) or not isinstance(bundle.get('addons'), dict):
        raise VaultError('The locked settings file is damaged.')
    return bundle


# ------------------------------------------------------------ repository

def _kodi_url(url):
    """Split a Kodi URL into (plain URL, HTTP headers) for requests.

    Kodi sends unknown |name=value options as HTTP headers ('!' hides the value in its log)."""
    from urllib.parse import unquote
    base, _sep, opts = url.partition('|')
    headers = {}
    for part in opts.split('&'):
        if '=' not in part:
            continue
        name, value = part.split('=', 1)
        name, value = unquote(name), unquote(value)
        if name.startswith('!'):
            name = name[1:]
        if name and name.lower() not in ('auth', 'verifypeer', 'user-agent'):
            headers[name] = value
    return base, headers


def repo_settings_url():
    """(URL, headers) of settings/locked-settings.json in the delivery repository, from the
    installed repository add-on. ('', {}) when it is not installed."""
    try:
        path = utils.translate('special://home/addons/%s/addon.xml' % REPO_ADDON)
        with open(path, 'r', encoding='utf-8') as handle:
            text = handle.read()
    except OSError:
        return '', {}
    m = re.search(r'<datadir[^>]*>\s*([^<\s]+?)\s*</datadir>', text)
    if not m:
        return '', {}
    base, headers = _kodi_url(m.group(1))
    base = base.rstrip('/')
    if base.endswith('/zips'):
        base = base[:-len('/zips')]
    return base + '/settings/' + FILE_NAME, headers


def download_locked():
    """The locked settings dict from the repository, None if there is none yet.

    Raises VaultError when the repository add-on is missing or GitHub cannot be reached."""
    import requests
    url, headers = repo_settings_url()
    if not url:
        raise VaultError('The SJJ Kodi Repository add-on is not installed on this Shield.')
    headers = dict(headers, **{'Cache-Control': 'no-cache'})
    try:
        resp = requests.get(url, timeout=20, headers=headers)
    except requests.RequestException:
        raise VaultError('Could not reach GitHub. Check the internet connection and try again.')
    if resp.status_code == 404:
        return None
    if resp.status_code in (401, 403):
        raise VaultError('GitHub refused the repository key (it may have expired).')
    if resp.status_code >= 400:
        raise VaultError('GitHub returned an error (HTTP %d).' % resp.status_code)
    try:
        return resp.json()
    except ValueError:
        raise VaultError('The locked settings file in the repository is damaged.')


def pin_ok(pin):
    return len(pin or '') >= MIN_PIN
