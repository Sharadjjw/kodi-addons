# -*- coding: utf-8 -*-
"""Sync engine: Premiumize cloud -> .strm + .nfo files that Kodi scans as a library."""
import time

import xbmc
import xbmcvfs

from . import metadata, net, nfo, parser, playback, premiumize, shared, utils

PLAY_URL = 'plugin://%s/?action=play&id=%s'
INDEX_FILE = 'index.json'
CACHE_FILE = 'cache.json'
OVERRIDES_FILE = 'overrides.json'
STATE_FILE = 'state.json'
MOVIES_DIR = 'Movies'
TV_DIR = 'TV Shows'
SAVE_EVERY = 25
MAX_CONSECUTIVE_ERRORS = 5
MAX_RESCANS = 3


class SyncError(Exception):
    """A problem the user should read about (bad key, too many errors, ...)."""


def format_summary(summary):
    parts = []
    new = summary.get('movies', 0) + summary.get('episodes', 0)
    if new:
        parts.append('%d new (%d movies, %d episodes)' % (new, summary['movies'], summary['episodes']))
    if summary.get('rematched'):
        parts.append('%d matched on retry' % summary['rematched'])
    if summary.get('removed'):
        parts.append('%d removed' % summary['removed'])
    if summary.get('no_tmdb'):
        parts.append('no TMDb key, so no artwork or ratings')
    elif summary.get('unmatched'):
        parts.append('%d without artwork (not matched)' % summary['unmatched'])
    if summary.get('deferred'):
        parts.append('%d waiting for the next sync' % summary['deferred'])
    return ', '.join(parts) or 'Nothing changed'


def has_changes(summary):
    """True when a sync added, re-matched or removed something worth telling the user."""
    return bool(summary.get('movies') or summary.get('episodes') or summary.get('rematched')
                or summary.get('removed') or summary.get('no_tmdb'))


class SyncEngine(object):
    def __init__(self, monitor=None, sleeper=None, progress=None):
        self.monitor = monitor
        self._sleeper = sleeper
        self.progress = progress or utils.BgProgress()
        self.changed_movies = False
        self.changed_tv = False

    # ------------------------------------------------------------- plumbing

    def _sleep(self, seconds):
        if self._sleeper:
            self._sleeper(seconds)
        elif self.monitor:
            self.monitor.waitForAbort(seconds)
        else:
            time.sleep(seconds)

    def aborted(self):
        return bool(self.monitor and self.monitor.abortRequested())

    def load(self):
        """Load index/overrides from disk and make sure the library folders exist."""
        self.root = utils.library_root()
        self.movies_root = utils.join(self.root, MOVIES_DIR)
        self.tv_root = utils.join(self.root, TV_DIR)
        kodi_root = utils.library_root_kodi()
        self.kodi_movies = utils.join(kodi_root, MOVIES_DIR)
        self.kodi_tv = utils.join(kodi_root, TV_DIR)
        utils.fs_mkdirs(self.movies_root)
        utils.fs_mkdirs(self.tv_root)
        self.index = utils.load_json(INDEX_FILE, {})
        if not isinstance(self.index, dict):
            self.index = {}
        self.index.setdefault('version', 1)
        self.files = self.index.setdefault('files', {})
        self.overrides = utils.load_json(OVERRIDES_FILE, {})
        self.overrides.setdefault('files', {})
        self.overrides.setdefault('shows', {})
        self.overrides.setdefault('episodes', {})   # file id -> {tmdb, season, episodes}
        self.claimed = {e['strm'].lower(): fid for fid, e in self.files.items() if e.get('strm')}

    def save(self):
        utils.save_json(INDEX_FILE, self.index)

    @staticmethod
    def _sig(f):
        return '%s|%s' % (f['name'], '/'.join(f['dirs']))

    # ---------------------------------------------------------- file removal

    def _prune(self, rel_dir):
        """Delete now-empty folders (only our .nfo sidecar files may remain in them)."""
        parts = rel_dir.split('/')
        while len(parts) > 1:  # never remove the Movies / TV Shows root
            path = utils.join(self.root, *parts)
            if utils.fs_exists(path):
                dirs, files = utils.fs_listdir(path)
                if dirs or any(not f.lower().endswith('.nfo') for f in files):
                    return
                for f in files:
                    utils.fs_delete(utils.join(path, f))
                utils.fs_rmdir(path)
            parts.pop()

    def drop_entries(self, ids):
        """Remove the generated files of the given cloud file ids. Returns how many."""
        count = 0
        for fid in list(ids):
            entry = self.files.pop(fid, None)
            if not entry:
                continue
            strm = entry.get('strm')
            self.claimed.pop((strm or '').lower(), None)
            for rel in [strm] + list(entry.get('nfo') or []):
                if rel:
                    utils.fs_delete(utils.join(self.root, rel))
            if strm:
                self._prune(strm.rsplit('/', 1)[0])
            count += 1
        return count

    def apply_manual_match(self, fid, kind, tmdb_id, season=None, episode=None):
        """Remember a user-chosen TMDb match and queue the affected files for re-sync.

        kind 'movie' and 'tv' (whole show, files with an episode code) as before;
        kind 'episode' ties one file to a show, season and episode chosen by hand.
        """
        entry = self.files.get(fid) or {}
        if kind == 'movie':
            shared.set_match(self.overrides, 'files', fid, int(tmdb_id))
            shared.set_match(self.overrides, 'episodes', fid, None)
            ids = [fid]
        elif kind == 'episode':
            shared.set_match(self.overrides, 'episodes', fid,
                             {'tmdb': int(tmdb_id), 'season': int(season), 'episodes': [int(episode)]})
            shared.set_match(self.overrides, 'files', fid, None)
            ids = [fid]
        else:
            tkey = entry.get('tkey')
            if not tkey:
                return 0
            shared.set_match(self.overrides, 'shows', tkey, int(tmdb_id))
            ids = [i for i, e in self.files.items() if e.get('tkey') == tkey]
        count = self.drop_entries(ids)
        utils.save_json(OVERRIDES_FILE, self.overrides)
        self.save()
        state = utils.load_json(STATE_FILE, {})
        state['pending_clean'] = True
        utils.save_json(STATE_FILE, state)
        return count

    def apply_episode_matches(self, matches):
        """Tie several files to episodes in one go: [(file id, tmdb id, season, episode)].

        Same as apply_manual_match(kind='episode') for each file, saved once.
        Returns how many library entries were dropped for re-sync.
        """
        for fid, tmdb_id, season, episode in matches:
            shared.set_match(self.overrides, 'episodes', fid,
                             {'tmdb': int(tmdb_id), 'season': int(season), 'episodes': [int(episode)]})
            shared.set_match(self.overrides, 'files', fid, None)
        count = self.drop_entries([m[0] for m in matches])
        utils.save_json(OVERRIDES_FILE, self.overrides)
        self.save()
        state = utils.load_json(STATE_FILE, {})
        state['pending_clean'] = True
        utils.save_json(STATE_FILE, state)
        return count

    def share_matches(self):
        """Exchange manual matches with the other Shields through the Premiumize cloud.

        Matches made elsewhere are applied here (their files are processed again in
        this sync); matches made here are uploaded. Returns how many changed here.
        Never raises: sharing problems are logged and retried at the next sync.
        """
        if not utils.setting_bool('share_matches', True):
            return 0
        cloud = shared.CloudCopy(self.pm)
        try:
            remote, folder, copies = cloud.read()
        except Exception as exc:  # noqa: BLE001
            utils.log('Shared matches not read (%s); keeping this Shield\'s matches' % exc,
                      xbmc.LOGWARNING)
            return 0
        local = shared.items_of(self.overrides)
        merged, changed = shared.merge(local, remote)
        if changed:
            self.overrides['_items'] = merged
            shared.rebuild(self.overrides)
            utils.save_json(OVERRIDES_FILE, self.overrides)
            dropped = self.drop_entries(shared.affected_files(changed, self.files))
            self.save()
            utils.log('Applied %d manual match(es) made on another Shield (%d file(s) to redo)'
                      % (len(changed), dropped))
        elif local != self.overrides.get('_items'):
            utils.save_json(OVERRIDES_FILE, self.overrides)   # first run: log created from old matches
        signature = cloud.signature(copies)
        if merged != remote and merged:
            try:
                signature = cloud.write(merged, folder, copies)
                utils.log('Shared %d manual match(es) with the other Shields' % len(merged))
            except Exception as exc:  # noqa: BLE001
                utils.log('Shared matches not uploaded (%s); will retry next sync' % exc, xbmc.LOGWARNING)
                signature = None
        if signature is not None:
            state = utils.load_json(STATE_FILE, {})
            state['shared_seen'] = signature
            utils.save_json(STATE_FILE, state)
        return len(changed)

    # ------------------------------------------------------------------ run

    def run(self, mode='sync'):
        key = utils.setting('pm_api_key').strip()
        if not key:
            raise SyncError('Enter your Premiumize API key in the add-on settings first.')
        counts = {'movies': 0, 'episodes': 0, 'removed': 0, 'unmatched': 0,
                  'deferred': 0, 'errors': 0, 'rematched': 0}
        started = time.time()
        self.progress.start('Reading Premiumize cloud...')
        try:
            summary = self._run(key, mode, counts)
        finally:
            self.progress.close()
        summary['seconds'] = int(time.time() - started)
        state = utils.load_json(STATE_FILE, {})
        state['last_summary'] = summary
        if not summary.get('aborted'):
            state['last_run'] = time.time()
        utils.save_json(STATE_FILE, state)
        return summary

    def _run(self, key, mode, counts):
        self.load()
        self.cache = metadata.Cache(lambda: utils.load_json(CACHE_FILE, {}),
                                    lambda data: utils.save_json(CACHE_FILE, data))
        self.md = metadata.Metadata(
            utils.setting('tmdb_key'), utils.setting('omdb_key'),
            utils.setting('tmdb_language', 'en-US'), cache=self.cache,
            defer_on_limit=utils.setting_bool('defer_on_omdb_limit', True),
            episode_ratings=utils.setting_bool('fetch_episode_ratings', False),
            sleeper=self._sleep, abort=self.aborted)
        self.pm = premiumize.Premiumize(key, sleeper=self._sleep, abort=self.aborted)
        self.changed_movies = self.changed_tv = False
        removed_any = bool(utils.load_json(STATE_FILE, {}).get('pending_clean'))
        deferred_stop = False
        if self.index.get('version', 1) < 2:
            # Version 1 cached "nothing found" answers for 30 days and never retried
            # unmatched files; forget those answers so everything is looked up again.
            purged = self.cache.purge_negative()
            utils.log('Upgraded library index; cleared %d cached empty lookups' % purged)
            self.index['version'] = 2
        if not self.md.enabled:
            utils.log('No TMDb key set: files are added without artwork, ratings or titles',
                      xbmc.LOGWARNING)
        try:
            if self.share_matches():
                removed_any = True
            if mode == 'rebuild':
                counts['removed'] += self.drop_entries(list(self.files))
                removed_any = True

            cloud = self._cloud()
            gone = [fid for fid in self.files if fid not in cloud]
            if gone and not cloud:
                utils.log('Premiumize returned no videos; keeping existing library files')
                gone = []
            changed = [fid for fid, f in cloud.items()
                       if fid in self.files and self.files[fid].get('sig') != self._sig(f)]
            self.drop_entries(gone + changed)
            counts['removed'] += len(gone)
            removed_any = removed_any or bool(gone or changed)

            # Files that could not be matched before get another lookup on every sync.
            # They have no NFO, so Kodi never added them and dropping them is harmless.
            retry = set()
            if self.md.enabled:
                retry = {fid for fid, e in self.files.items() if fid in cloud and not e.get('matched')}
                self.drop_entries(retry)

            todo = sorted((f for fid, f in cloud.items() if fid not in self.files),
                          key=lambda f: ('/'.join(f['dirs']).lower(), f['name'].lower()))
            total = len(todo)
            errors_in_row = 0
            for i, f in enumerate(todo):
                if self.aborted():
                    break
                self.progress.update(100.0 * i / max(total, 1), f['name'])
                try:
                    if f['id'] in retry:
                        flags = (self.changed_movies, self.changed_tv)
                        self._process(f, dict.fromkeys(counts, 0))
                        if self.files[f['id']].get('matched'):
                            counts['rematched'] += 1
                        else:
                            # Same files written back; Kodi has nothing new to scan.
                            counts['unmatched'] += 1
                            self.changed_movies, self.changed_tv = flags
                    else:
                        self._process(f, counts)
                    errors_in_row = 0
                except net.Aborted:
                    break
                except metadata.TmdbAuthError:
                    raise SyncError('TMDb rejected your API key. Check it in the add-on settings.')
                except metadata.OmdbAuthError:
                    raise SyncError('OMDb rejected your API key. Check it in the add-on settings.')
                except metadata.OmdbLimit:
                    counts['deferred'] += total - i
                    deferred_stop = True
                    utils.log('OMDb daily limit reached; %d files wait for the next sync' % (total - i))
                    break
                except (metadata.TmdbError, metadata.OmdbError) as exc:
                    counts['errors'] += 1
                    counts['deferred'] += 1
                    errors_in_row += 1
                    utils.log('Lookup failed for "%s": %s' % (f['name'], exc))
                    if errors_in_row >= MAX_CONSECUTIVE_ERRORS:
                        raise SyncError('Too many lookup errors in a row: %s' % exc)
                if (i + 1) % SAVE_EVERY == 0:
                    self.cache.flush()
                    self.save()
            self._attach_paths_and_subtitles(cloud)
        finally:
            self.cache.flush()
            self.save()

        if removed_any or self.changed_movies or self.changed_tv:
            self._update_kodi(removed_any)
        missing = 0
        if not self.aborted() and utils.setting_bool('scan_after_sync', True):
            missing = self._ensure_in_kodi()
        state = utils.load_json(STATE_FILE, {})
        if state.pop('pending_clean', None):
            utils.save_json(STATE_FILE, state)
        summary = dict(counts, aborted=self.aborted(), omdb_limit=deferred_stop,
                       no_tmdb=not self.md.enabled, rescan=missing)
        total_unmatched = sum(1 for e in self.files.values() if not e.get('matched'))
        utils.log('Sync summary: %d files in library (%d not matched), new movies %d, new episodes %d, '
                  'matched on retry %d, removed %d, deferred %d, lookup errors %d, TMDb key %s, '
                  'Kodi rescan for %d missing, scan paths %s | %s' % (
                      len(self.files), total_unmatched, counts['movies'], counts['episodes'],
                      counts['rematched'], counts['removed'], counts['deferred'], counts['errors'],
                      'set' if self.md.enabled else 'MISSING', missing, self.kodi_movies, self.kodi_tv))
        return summary

    # ------------------------------------------------------------ cloud list

    def _cloud(self):
        min_size = utils.setting_int('min_size_mb', 50) * 1024 * 1024
        out = {}
        self.subs = {}
        for f in self.pm.list_files():
            if playback.is_subtitle(f['name']):
                key = playback.subtitle_folder_key(f['dirs'])
                self.subs.setdefault(key, []).append(
                    {'id': f['id'], 'name': f['name'], 'path': '/'.join(f['dirs'] + [f['name']])})
                continue
            if not parser.is_video(f['name'], f['mime']):
                continue
            if f['size'] and f['size'] < min_size:
                continue
            if parser.is_junk(f['name'], f['dirs'], f['size']):
                continue
            out[f['id']] = f
        return out

    def _ids_from_nfo(self, entry):
        """IMDb/TMDb ids from the NFO written earlier (movie NFO, or the show's tvshow.nfo)."""
        import xml.etree.ElementTree as ET
        strm = entry.get('strm') or ''
        if entry.get('kind') == 'episode':
            parts = strm.split('/')
            rel = '/'.join(parts[:2] + ['tvshow.nfo']) if len(parts) >= 3 else ''
        else:
            rel = strm[:-5] + '.nfo' if strm.endswith('.strm') else ''
        ids = {}
        if not rel:
            return ids
        try:
            text = utils.fs_read(utils.join(self.root, rel))
            root = ET.fromstring(text.split('?>', 1)[-1])
        except Exception:  # noqa: BLE001 - missing or unreadable NFO
            return ids
        for el in root.findall('uniqueid'):
            if el.get('type') in ('imdb', 'tmdb') and (el.text or '').strip():
                ids[el.get('type')] = el.text.strip()
        return ids

    def _attach_paths_and_subtitles(self, cloud):
        """Store each file's cloud path and nearby subtitles in the index (used at play time)."""
        per_folder = {}
        for f in cloud.values():
            key = '/'.join(f['dirs'])
            per_folder[key] = per_folder.get(key, 0) + 1
        for fid, entry in self.files.items():
            f = cloud.get(fid)
            if not f:
                continue
            entry['path'] = '/'.join(f['dirs'] + [f['name']])
            entry['size'] = f['size']
            if entry.get('matched') and not (entry.get('ids') or {}).get('imdb') \
                    and not (entry.get('ids') or {}).get('tmdb'):
                entry['ids'] = self._ids_from_nfo(entry)
            key = '/'.join(f['dirs'])
            subs = playback.pick_subtitles(f['name'], self.subs.get(key, []), per_folder.get(key) == 1)
            if subs:
                entry['subs'] = subs
            else:
                entry.pop('subs', None)

    # ------------------------------------------------------------ processing

    def _claim(self, directory, base, fid, quality):
        """Pick a unique .strm name inside directory. Returns (name, relative path)."""
        name, attempt = base, 0
        while True:
            rel = '%s/%s.strm' % (directory, name)
            owner = self.claimed.get(rel.lower())
            if owner in (None, fid):
                self.claimed[rel.lower()] = fid
                return name, rel
            attempt += 1
            if attempt == 1 and quality:
                suffix = quality
            elif attempt <= 2:
                suffix = fid[:6]
            else:
                suffix = fid
            name = '%s - %s' % (base, suffix)

    def _process(self, f, counts):
        manual = self.overrides['episodes'].get(f['id'])
        if manual:
            parsed = parser.parse(f['name'], f['dirs'], force_movie=True)
            parsed.update(kind='episode', season=int(manual['season']),
                          episodes=[int(e) for e in manual['episodes']])
            self._process_episode(f, parsed, counts, show_id=manual['tmdb'])
            return
        override = self.overrides['files'].get(f['id'])
        parsed = parser.parse(f['name'], f['dirs'], force_movie=bool(override))
        if parsed['kind'] == 'movie':
            self._process_movie(f, parsed, override, counts)
        else:
            self._process_episode(f, parsed, counts)

    def _process_movie(self, f, parsed, override, counts):
        meta = None
        if self.md.enabled:
            if override:
                meta = self.md.movie_by_id(override)
            else:
                meta = self.md.lookup_movie(parsed['title'], parsed['year'], parsed['alt_title'])
        title = meta['title'] if meta else parsed['title']
        year = meta['year'] if meta else parsed['year']
        folder = utils.safe_name('%s (%s)' % (title, year) if year else title)
        name, strm_rel = self._claim('%s/%s' % (MOVIES_DIR, folder), folder, f['id'], parsed['quality'])

        utils.fs_write(utils.join(self.root, strm_rel), PLAY_URL % (utils.ADDON_ID, f['id']))
        nfo_rels = []
        if meta:
            nfo_rel = strm_rel[:-5] + '.nfo'
            utils.fs_write(utils.join(self.root, nfo_rel), nfo.movie_nfo(meta))
            nfo_rels.append(nfo_rel)
        self.files[f['id']] = {
            'sig': self._sig(f), 'name': f['name'], 'dirs': f['dirs'], 'kind': 'movie',
            'matched': bool(meta), 'strm': strm_rel, 'nfo': nfo_rels,
            'title': title, 'year': year, 'poster': meta.get('poster') if meta else None,
            'ids': {'imdb': meta.get('imdb_id'), 'tmdb': meta.get('tmdb_id')} if meta else {},
        }
        counts['movies'] += 1
        if not meta:
            counts['unmatched'] += 1
        self.changed_movies = True

    def _process_episode(self, f, parsed, counts, show_id=None):
        if show_id:
            tkey = 'tmdb:%d' % int(show_id)
            override = int(show_id)
        else:
            tkey = '%s|%s' % (parser.normalize(parsed['title']), parsed['year'] or '')
            override = self.overrides['shows'].get(tkey)
        show = None
        if self.md.enabled:
            if override:
                show = self.md.show_by_id(override)
            else:
                show = self.md.lookup_show(parsed['title'], parsed['year'], parsed['alt_title'])
        season, episodes = parsed['season'], parsed['episodes']
        infos = self.md.episode_infos(show, season, episodes) if show else None

        title = show['title'] if show else parsed['title']
        year = show['year'] if show else parsed['year']
        show_folder = utils.safe_name('%s (%s)' % (title, year) if year else title)
        season_folder = 'Season %02d' % season if season else 'Specials'
        code = 'S%02d' % season + ''.join('E%02d' % e for e in episodes)
        base = '%s - %s' % (utils.safe_name(title), code)
        directory = '%s/%s/%s' % (TV_DIR, show_folder, season_folder)
        name, strm_rel = self._claim(directory, base, f['id'], parsed['quality'])

        utils.fs_write(utils.join(self.root, strm_rel), PLAY_URL % (utils.ADDON_ID, f['id']))
        nfo_rels = []
        if show:
            utils.fs_write(utils.join(self.root, '%s/%s/tvshow.nfo' % (TV_DIR, show_folder)),
                           nfo.tvshow_nfo(show), only_if_changed=True)
            nfo_rel = strm_rel[:-5] + '.nfo'
            utils.fs_write(utils.join(self.root, nfo_rel), nfo.episode_nfo(show['title'], season, infos))
            nfo_rels.append(nfo_rel)
        self.files[f['id']] = {
            'sig': self._sig(f), 'name': f['name'], 'dirs': f['dirs'], 'kind': 'episode',
            'matched': bool(show), 'strm': strm_rel, 'nfo': nfo_rels, 'tkey': tkey,
            'manual': bool(show_id),
            'title': title, 'year': year, 'season': season, 'episodes': episodes,
            'poster': show.get('poster') if show else None,
            'ids': {'imdb': show.get('imdb_id'), 'tmdb': show.get('tmdb_id')} if show else {},
        }
        counts['episodes'] += 1
        if not show:
            counts['unmatched'] += 1
        self.changed_tv = True

    # ------------------------------------------------------- Kodi integration

    def _update_kodi(self, removed_any):
        if removed_any and utils.setting_bool('clean_after_sync', True):
            self._scoped_clean()
        if utils.setting_bool('scan_after_sync', True):
            for changed, path in ((self.changed_movies, self.kodi_movies),
                                  (self.changed_tv, self.kodi_tv)):
                if changed:
                    utils.jsonrpc('VideoLibrary.Scan', {'directory': path + '/', 'showdialogs': False})

    def _ensure_in_kodi(self):
        """Ask Kodi to scan again when matched items are missing from its library.

        Kodi ignores a scan request while it is busy (for example right after start-up),
        so the single request made after a sync can be lost. This only runs once Kodi
        already holds some of our items (showing the library folders were added as
        sources), and gives up on an item after MAX_RESCANS tries so a file Kodi refuses
        is not rescanned forever. Returns how many items were missing.
        """
        def real(path):
            return xbmcvfs.translatePath(path).replace('\\', '/')
        movies = utils.jsonrpc('VideoLibrary.GetMovies', {'properties': ['file']}).get('movies') or []
        episodes = utils.jsonrpc('VideoLibrary.GetEpisodes', {'properties': ['file']}).get('episodes') or []
        known = {real(x.get('file', '')) for x in movies + episodes}
        root = self.root.replace('\\', '/') + '/'
        if not any(k.startswith(root) for k in known):
            return 0
        state = utils.load_json(STATE_FILE, {})
        before = dict(state.get('rescans') or {})
        tries = dict(before)
        want = {'movie': False, 'episode': False}
        missing = []
        for fid, entry in self.files.items():
            if not entry.get('matched') or not entry.get('strm'):
                continue
            if real(utils.join(self.root, entry['strm'])) in known:
                tries.pop(fid, None)
                continue
            if tries.get(fid, 0) >= MAX_RESCANS:
                continue
            tries[fid] = tries.get(fid, 0) + 1
            missing.append(str(entry.get('title') or entry.get('name')))
            want[entry.get('kind', 'movie')] = True
        tries = {k: v for k, v in tries.items() if k in self.files}
        if missing:
            utils.log('Not in the Kodi library yet, asking Kodi to scan again: %s'
                      % ', '.join(sorted(set(missing))[:10]))
            for flag, path in ((want['movie'], self.kodi_movies), (want['episode'], self.kodi_tv)):
                if flag:
                    utils.jsonrpc('VideoLibrary.Scan', {'directory': path + '/', 'showdialogs': False})
        if tries != before:
            state['rescans'] = tries
            utils.save_json(STATE_FILE, state)
        return len(missing)

    def _inside(self, path):
        real = xbmcvfs.translatePath(path).replace('\\', '/')
        return real.startswith(self.root.replace('\\', '/') + '/')

    def _scoped_clean(self):
        """Remove library entries whose files vanished, but only inside our own folders.

        Kodi's global "clean library" could also drop items from other sources that are
        temporarily offline, so we remove just the items that live under our folder.
        """
        movies = utils.jsonrpc('VideoLibrary.GetMovies', {'properties': ['file']}).get('movies') or []
        for m in movies:
            if self._inside(m.get('file', '')) and not utils.fs_exists(m['file']):
                utils.jsonrpc('VideoLibrary.RemoveMovie', {'movieid': m['movieid']})
        episodes = utils.jsonrpc('VideoLibrary.GetEpisodes', {'properties': ['file']}).get('episodes') or []
        for e in episodes:
            if self._inside(e.get('file', '')) and not utils.fs_exists(e['file']):
                utils.jsonrpc('VideoLibrary.RemoveEpisode', {'episodeid': e['episodeid']})
        shows = utils.jsonrpc('VideoLibrary.GetTVShows', {'properties': ['file']}).get('tvshows') or []
        for s in shows:
            path = s.get('file', '')
            if path and self._inside(path) and not utils.fs_exists(path):
                utils.jsonrpc('VideoLibrary.RemoveTVShow', {'tvshowid': s['tvshowid']})
