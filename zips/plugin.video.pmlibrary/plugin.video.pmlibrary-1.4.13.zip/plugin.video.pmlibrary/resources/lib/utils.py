# -*- coding: utf-8 -*-
"""Kodi-facing helpers: settings, logging, storage, file access, JSON-RPC."""
import json
import os
import re

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = 'plugin.video.pmlibrary'
HOME_WINDOW = 10000

# Every user setting, for Export/Import settings (tests check this matches settings.xml).
EXPORT_KEYS = (
    'pm_api_key', 'tmdb_key', 'omdb_key', 'pm_dir_url', 'use_dir_link', 'speed_test', 'route_notify',
    'library_path', 'tmdb_language', 'min_size_mb', 'fetch_episode_ratings', 'defer_on_omdb_limit',
    'share_matches',
    'sync_on_start', 'sync_interval', 'scan_after_sync', 'clean_after_sync',
    'os_enabled', 'os_username', 'os_password', 'os_api_key', 'os_show', 'os_hearing_impaired',
    'os_notify',
)


def addon():
    # A fresh instance each time so a long-running service sees changed settings.
    return xbmcaddon.Addon(ADDON_ID)


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, message), level)


# ---------------------------------------------------------------- settings

def setting(key, default=''):
    try:
        value = addon().getSetting(key)
    except Exception:  # noqa: BLE001 - Kodi raises generic errors here
        value = ''
    return value if value != '' else default


def setting_bool(key, default=False):
    value = setting(key, '')
    if value == '':
        return default
    return value.lower() == 'true'


def setting_int(key, default=0):
    try:
        return int(float(setting(key, str(default))))
    except (TypeError, ValueError):
        return default


# ----------------------------------------------------------- profile storage

def profile_dir():
    path = xbmcvfs.translatePath(addon().getAddonInfo('profile'))
    os.makedirs(path, exist_ok=True)
    return path


def load_json(name, default):
    path = os.path.join(profile_dir(), name)
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def save_json(name, obj):
    path = os.path.join(profile_dir(), name)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as handle:
        json.dump(obj, handle, ensure_ascii=False)
    os.replace(tmp, path)


# ---------------------------------------------------------- library file I/O

def join(base, *parts):
    return base.rstrip('/\\') + '/' + '/'.join(p.strip('/\\') for p in parts)


def library_root():
    custom = setting('library_path', '').strip()
    if custom:
        root = xbmcvfs.translatePath(custom)
    else:
        root = os.path.join(profile_dir(), 'library')
    return root.rstrip('/\\')


def translate(path):
    return xbmcvfs.translatePath(path)


def library_root_kodi():
    """The library folder spelled the way Kodi stores it for a source.

    Kodi matches library scans against the source path string, so the default
    location is given as special://profile/... (what the setup guide tells the user
    to type) rather than the translated /storage/... path.
    """
    custom = setting('library_path', '').strip()
    if custom:
        return custom.rstrip('/\\')
    return 'special://profile/addon_data/%s/library' % ADDON_ID


def fs_exists(path):
    return xbmcvfs.exists(path)


def fs_mkdirs(path):
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)


def fs_read(path):
    handle = xbmcvfs.File(path)
    try:
        return handle.read()
    finally:
        handle.close()


def fs_write(path, text, only_if_changed=False):
    """Write text (UTF-8). Returns True when the file was (re)written."""
    if only_if_changed and xbmcvfs.exists(path):
        try:
            if fs_read(path) == text:
                return False
        except Exception:  # noqa: BLE001
            pass
    fs_mkdirs(path.rsplit('/', 1)[0])
    handle = xbmcvfs.File(path, 'w')
    try:
        handle.write(bytearray(text.encode('utf-8')))
    finally:
        handle.close()
    return True


def fs_delete(path):
    if xbmcvfs.exists(path):
        xbmcvfs.delete(path)


def fs_listdir(path):
    return xbmcvfs.listdir(path)


def fs_rmdir(path):
    xbmcvfs.rmdir(path)


_BAD_CHARS = re.compile(r'[<>"/\\|?*\x00-\x1f]')


def safe_name(text, maxlen=120):
    text = (text or '').replace(':', ' -')
    text = _BAD_CHARS.sub('', text)
    text = re.sub(r'\s+', ' ', text).strip(' .')
    return text[:maxlen].strip(' .') or 'Unknown'


# --------------------------------------------------------------------- Kodi UI

def notify(message, heading='Premiumize Library', icon=xbmcgui.NOTIFICATION_INFO, ms=5000):
    xbmcgui.Dialog().notification(heading, message, icon, ms)


def home_window():
    return xbmcgui.Window(HOME_WINDOW)


class BgProgress(object):
    """Background progress dialog that never raises."""

    def __init__(self, heading='Premiumize Library'):
        self.heading = heading
        self._dialog = None

    def start(self, message=''):
        try:
            self._dialog = xbmcgui.DialogProgressBG()
            self._dialog.create(self.heading, message)
        except Exception:  # noqa: BLE001
            self._dialog = None

    def update(self, percent, message=''):
        if self._dialog is not None:
            try:
                self._dialog.update(int(percent), self.heading, message)
            except Exception:  # noqa: BLE001
                pass

    def close(self):
        if self._dialog is not None:
            try:
                self._dialog.close()
            except Exception:  # noqa: BLE001
                pass
            self._dialog = None


def jsonrpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params:
        request['params'] = params
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except ValueError:
        return {}
    if 'error' in response:
        log('JSON-RPC %s failed: %s' % (method, response['error'].get('message', '')), xbmc.LOGWARNING)
        return {}
    return response.get('result') or {}
