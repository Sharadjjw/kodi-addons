# -*- coding: utf-8 -*-
"""Match several unmatched files to one TV show at once.

Pure logic only (no dialogs), so it can be tested without Kodi:
- similar(): which other unmatched files look like the same show as one file;
- propose(): which season and episode each file is, from its episode code, the
  TMDb episode title in its name, or (last resort) its place in the list.
"""
import os
import re

from . import parser

MIN_PREFIX_CHARS = 6        # "inspectormorse" yes, "the" no
MIN_TITLE_CHARS = 5         # shorter episode titles are too easy to find by accident
_GENERIC_EP = re.compile(r'^(?:episode|ep|part|chapter|show)\d+$')


def _tokens(entry):
    stem = os.path.splitext(entry.get('name') or '')[0]
    stem = re.sub(r'^\s*\[[^\]]*\]\s*', '', stem)          # [group] prefix
    return [t.lower() for t in parser._prep(stem).replace('-', ' ').split()]


def _leading_chars(a, b):
    """Characters in the words two names start with in common."""
    n = 0
    for x, y in zip(a, b):
        if x != y:
            break
        n += len(re.sub(r'\W', '', x))
    return n


def _show_title(entry):
    return parser.normalize(parser.parse(entry.get('name') or '', entry.get('dirs'))['title'])


def similar(file_id, files):
    """Ids of the other unmatched files that look like the same show as file_id.

    Same folder (not the cloud root), the same title read from the name, or names
    that start with the same words count as similar. Used only to pre-tick files.
    """
    me = files.get(file_id) or {}
    my_dirs = tuple(me.get('dirs') or [])
    my_title = _show_title(me)
    my_tokens = _tokens(me)
    out = []
    for fid, entry in files.items():
        if fid == file_id or entry.get('matched'):
            continue
        if my_dirs and tuple(entry.get('dirs') or []) == my_dirs:
            out.append(fid)
        elif len(my_title) >= 3 and _show_title(entry) == my_title:
            out.append(fid)
        elif _leading_chars(my_tokens, _tokens(entry)) >= MIN_PREFIX_CHARS:
            out.append(fid)
    return out


def common_title(entries):
    """Search text for the TMDb box: the words all the names start with, else the parsed title."""
    entries = [e for e in entries if e]
    if not entries:
        return ''
    first = parser.parse(entries[0].get('name') or '', entries[0].get('dirs'))['title']
    if len(entries) == 1:
        return first
    lists = [_tokens(e) for e in entries]
    # the longest start of the name shared by at least half of the files (an odd
    # name like "Morse 03" among "Inspector Morse - ..." files does not spoil it)
    # and stops when fewer files share the next word ("Inspector Morse The ...")
    need = max(2, (len(lists) + 1) // 2)
    common = []
    for k in range(1, max(len(t) for t in lists) + 1):
        counts = {}
        for t in lists:
            if len(t) >= k:
                counts[tuple(t[:k])] = counts.get(tuple(t[:k]), 0) + 1
        best = max(counts.items(), key=lambda kv: kv[1]) if counts else None
        if not best or best[1] < need:
            break
        need = best[1]
        common = list(best[0])
    # stop before an episode code, a year or a quality word
    cut = []
    for w in common:
        if re.match(r'^(?:s\d{1,2}(?:e\d+)?|\d{1,2}x\d+|season|series|episode|ep|part)$', w) \
                or parser._is_year(w) or parser._STRONG_RE.match(w):
            break
        cut.append(w)
    text = ' '.join(cut).strip(' -')
    if len(re.sub(r'\W', '', text)) >= 3:
        return text.title()
    return first


def season_hint(rows):
    """Season named by the folders of these files (e.g. "Season 05"), else None."""
    for _fid, entry in rows:
        season = parser.season_from_dirs(entry.get('dirs') or [])
        if season is not None:
            return season
    return None


def propose(rows, catalog, season=None, taken=()):
    """Work out season and episode for each file.

    rows:    [(file id, index entry)] in the order shown to the user
    catalog: {season number: [(episode number, title)]} of the chosen show
    season:  season for files recognised by neither code nor title (None = leave them)
    taken:   (season, episode) pairs already used by other files

    Returns {file id: (season, episode, how) or None}; how is 'code', 'title' or 'order'.
    """
    valid = {(s, n) for s, eps in catalog.items() for n, _t in eps}
    used = set(taken)
    out = {}

    # 1. An episode code in the name (S05E02, 5x02, Season 5 Episode 2 ...).
    for fid, entry in rows:
        p = parser.parse(entry.get('name') or '', entry.get('dirs'))
        if p['kind'] == 'episode':
            key = (p['season'], p['episodes'][0])
            if (not catalog or key in valid) and key not in used:
                out[fid] = key + ('code',)
                used.add(key)

    # 2. The TMDb episode title inside the name ("Inspector Morse - The Dead of Jericho").
    titles = []
    for s, eps in catalog.items():
        for n, title in eps:
            key = parser.normalize(title)
            if len(key) >= MIN_TITLE_CHARS and not _GENERIC_EP.match(key):
                titles.append((key, s, n))
    for fid, entry in rows:
        if fid in out:
            continue
        stem = parser.normalize(os.path.splitext(entry.get('name') or '')[0])
        hits = [(len(key), s == season, -s, -n, s, n) for key, s, n in titles
                if key in stem and (s, n) not in used]
        if hits:
            best = max(hits)
            out[fid] = (best[4], best[5], 'title')
            used.add((best[4], best[5]))

    # 3. Still unknown: a number in the name if it fits the season, else next free episode.
    episodes = [n for n, _t in catalog.get(season, [])] if season is not None else []
    for fid, entry in rows:
        if fid in out:
            continue
        if not episodes:
            out[fid] = None
            continue
        _s, number = parser.guess_numbers(entry.get('name') or '', entry.get('dirs'))
        if number in episodes and (season, number) not in used:
            pick = number
        else:
            pick = next((n for n in episodes if (season, n) not in used), None)
        if pick is None:
            out[fid] = None
            continue
        out[fid] = (season, pick, 'order')
        used.add((season, pick))
    return out


def duplicates(proposal):
    """(season, episode) pairs given to more than one file."""
    seen, twice = set(), set()
    for value in proposal.values():
        if not value:
            continue
        key = value[:2]
        (twice if key in seen else seen).add(key)
    return twice
