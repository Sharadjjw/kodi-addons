# -*- coding: utf-8 -*-
"""Plugin entry point: browse the cloud, play files, fix matches, and helper actions."""
import json
import sys
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import (bulkmatch, delete, metadata, net, opensubs, parser, playback, premiumize, subfetch,
                           subservice, sync, utils, vaultui)

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
BASE_URL = sys.argv[0] if sys.argv else 'plugin://%s/' % utils.ADDON_ID
RUNNING = 'pmlib.running'
REQUEST = 'pmlib.request'
HEADING = 'Premiumize Library'


def build_url(**params):
    return '%s?%s' % (BASE_URL, urlencode(params))


def set_info(item, title=None, plot=None, year=None, mediatype=None):
    try:  # Kodi 20+
        tag = item.getVideoInfoTag()
        if title:
            tag.setTitle(title)
        if plot:
            tag.setPlot(plot)
        if year:
            tag.setYear(int(year))
        if mediatype:
            tag.setMediaType(mediatype)
    except AttributeError:  # Kodi 19
        info = {}
        if title:
            info['title'] = title
        if plot:
            info['plot'] = plot
        if year:
            info['year'] = int(year)
        if mediatype:
            info['mediatype'] = mediatype
        item.setInfo('video', info)


def finish(succeeded=True):
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=succeeded)


def action_done():
    """Close a click-through action item (not a list) cleanly."""
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False, cacheToDisc=False)


def pm_client():
    key = utils.setting('pm_api_key').strip()
    if not key:
        xbmcgui.Dialog().ok(HEADING, 'Enter your Premiumize API key in the add-on settings first.')
        return None
    return premiumize.Premiumize(key)


def make_metadata():
    cache = metadata.Cache(lambda: utils.load_json(sync.CACHE_FILE, {}),
                           lambda data: utils.save_json(sync.CACHE_FILE, data))
    md = metadata.Metadata(utils.setting('tmdb_key'), utils.setting('omdb_key'),
                           utils.setting('tmdb_language', 'en-US'), cache=cache)
    return md, cache


# ------------------------------------------------------------------- listings

def root_menu():
    index = utils.load_json(sync.INDEX_FILE, {})
    unmatched = sum(1 for e in (index.get('files') or {}).values() if not e.get('matched'))
    entries = []
    if not utils.setting('pm_api_key').strip() or not utils.setting('tmdb_key').strip():
        entries.append(('[B]Enter API keys[/B]', build_url(action='enter_keys'), False))
    entries += [
        ('Browse Premiumize cloud', build_url(action='browse'), True),
        ('Not matched to a movie or show (%d)' % unmatched, build_url(action='unmatched'), True),
        ('Sync library now', build_url(action='sync_now'), False),
        ('Sync subtitles of the video playing now', build_url(action='sync_subs'), False),
        ('How to add the library to Kodi', build_url(action='setup'), False),
        ('Settings', build_url(action='settings'), False),
    ]
    for label, url, is_folder in entries:
        xbmcplugin.addDirectoryItem(HANDLE, url, xbmcgui.ListItem(label=label), is_folder)
    finish()


def _file_item(file_id, name, entry):
    item = xbmcgui.ListItem(label=name)
    item.setProperty('IsPlayable', 'true')
    if entry:
        set_info(item, title=entry.get('title'), year=entry.get('year'), mediatype='video')
        if entry.get('poster'):
            item.setArt({'thumb': entry['poster'], 'poster': entry['poster']})
    else:
        set_info(item, title=name, mediatype='video')
    menu = [('Match to a different movie or show...',
             'RunPlugin(%s)' % build_url(action='fix', id=file_id))]
    if entry and not entry.get('matched'):
        menu.append(('Match several files to one show...',
                     'RunPlugin(%s)' % build_url(action='match_many', id=file_id)))
    menu.append(('Delete from Premiumize...',
                 'RunPlugin(%s)' % build_url(action='delete', id=file_id, name=name)))
    item.addContextMenuItems(menu)
    return item


def browse(folder_id=None):
    pm = pm_client()
    if pm is None:
        return finish(False)
    try:
        data = pm.list_folder(folder_id)
    except premiumize.PremiumizeError as exc:
        xbmcgui.Dialog().ok(HEADING, 'Could not read the folder: %s' % exc)
        return finish(False)
    index = (utils.load_json(sync.INDEX_FILE, {}).get('files')) or {}
    for entry in data.get('content') or []:
        name = entry.get('name') or ''
        if entry.get('type') == 'folder':
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action='browse', id=entry['id']),
                                        xbmcgui.ListItem(label=name), True)
        elif parser.is_video(name, entry.get('mime_type', '')):
            fid = str(entry['id'])
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action='play', id=fid),
                                        _file_item(fid, name, index.get(fid)), False)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
    xbmcplugin.setContent(HANDLE, 'files')
    finish()


def unmatched():
    index = (utils.load_json(sync.INDEX_FILE, {}).get('files')) or {}
    rows = sorted(((e.get('name', ''), fid, e) for fid, e in index.items() if not e.get('matched')),
                  key=lambda r: r[0].lower())
    if len(rows) > 1:
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action='match_many'),
                                    xbmcgui.ListItem(label='[B]Match several files to one show...[/B]'),
                                    False)
    for name, fid, entry in rows:
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action='play', id=fid),
                                    _file_item(fid, name, entry), False)
    xbmcplugin.setContent(HANDLE, 'files')
    finish()


# ------------------------------------------------------------------- playback

def _api_link(pm, file_id):
    try:
        return pm.resolve_link(file_id), None
    except (premiumize.PremiumizeError, net.NetError) as exc:
        return None, exc


def choose_link(file_id, entry, base):
    """Pick the faster of the HTTP folder link and the Premiumize API link.

    Both are speed-tested with a short read when a video starts; the result is reused
    for ROUTE_TTL so later plays start at once. Returns (link or None, Premiumize client).
    """
    win = utils.home_window()
    dir_link = playback.file_url(base, entry['path']) if base and entry.get('path') else None
    pm = None

    if dir_link and playback.remembered_route(win) == 'dir':
        if net.url_ok(dir_link):
            return dir_link, pm
        utils.log('HTTP folder link did not answer; using the API link and testing again next time')
        win.clearProperty(playback.ROUTE_PROP)
        dir_link_ok = False
    else:
        dir_link_ok = True

    pm = pm_client()
    if pm is None:
        return None, pm
    api_link, error = _api_link(pm, file_id)

    if dir_link and dir_link_ok and api_link and not playback.remembered_route(win):
        dir_speed = net.measure(dir_link)
        api_speed = net.measure(api_link)
        route = playback.pick_faster(dir_speed, api_speed)
        utils.log('Speed test: HTTP folder link %s, Premiumize API link %s -> using %s'
                  % (playback.mbps(dir_speed), playback.mbps(api_speed),
                     {'dir': 'the folder link', 'api': 'the API link'}.get(route, 'the API link')))
        if route:
            playback.remember_route(win, route)
            if utils.setting_bool('route_notify', True):
                if route == 'dir':
                    msg = 'Playing via folder link (%s vs %s)' % (playback.short_mbps(dir_speed),
                                                                  playback.short_mbps(api_speed))
                else:
                    msg = 'Playing via direct link (%s vs %s)' % (playback.short_mbps(api_speed),
                                                                  playback.short_mbps(dir_speed))
                utils.notify(msg, ms=4000)
        if route == 'dir':
            return dir_link, pm
        return api_link, pm

    if api_link:
        return api_link, pm
    if dir_link and dir_link_ok and net.url_ok(dir_link):
        return dir_link, pm
    utils.notify('Could not play: %s' % (error or 'no link'), icon=xbmcgui.NOTIFICATION_ERROR, ms=7000)
    return None, pm


def play(file_id):
    entry = ((utils.load_json(sync.INDEX_FILE, {}).get('files')) or {}).get(file_id) or {}
    base = ''
    if utils.setting_bool('use_dir_link', True):
        base, _where = playback.find_dir_link()

    link, pm = choose_link(file_id, entry, base)
    if link is None:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    item = xbmcgui.ListItem(path=link)
    subs = []
    chosen = subfetch.chosen_file(file_id)     # picked by the user: switched on after start
    cached = None if chosen else subfetch.cached_file(file_id)
    if cached:
        subs.append(cached)
    for sub in entry.get('subs') or []:
        if base and link.startswith(base):
            subs.append(playback.file_url(base, sub['path']))
            continue
        try:
            pm = pm or premiumize.Premiumize(utils.setting('pm_api_key').strip())
            subs.append(pm.resolve_link(sub['id']))
        except (premiumize.PremiumizeError, net.NetError):
            pass
    if subs:
        item.setSubtitles(subs)
    subfetch.leave_note(file_id, bool(subs) or bool(chosen), chosen)
    subservice.remember_current(file_id, link)
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


# -------------------------------------------------------------------- actions

def request_sync(mode):
    win = utils.home_window()
    if win.getProperty(RUNNING) == '1':
        utils.notify('A sync is already running.')
    else:
        win.setProperty(REQUEST, mode)
        utils.notify('Sync requested. It runs in the background.')
    action_done()


def rebuild():
    ok = xbmcgui.Dialog().yesno(
        HEADING, 'Rebuild the library?\n\nThis deletes the generated library files and creates '
                 'them again. Your Premiumize files are not touched, but watched marks in Kodi '
                 'for these items are lost.')
    if ok:
        request_sync('rebuild')
    else:
        action_done()


def setup_guide():
    root = utils.library_root_kodi()
    text = (
        'Your library folders are:\n'
        '  Movies:    %s/Movies/\n'
        '  TV shows:  %s/TV Shows/\n\n'
        '1. Run "Sync library now" and wait for the "Sync finished" message.\n\n'
        '2. In Kodi: Videos > Files > Add videos... Do not press Browse. Select the empty '
        'path box, type the Movies path above exactly, and press OK.\n\n'
        '3. "This directory contains": Movies. "Choose information provider": '
        '"Local information only". Turn on "Movies are in separate folders that match the movie '
        'title". Press OK.\n\n'
        '4. Repeat for TV Shows: type the TV Shows path, content "TV shows", provider '
        '"Local information only", and leave "Selected folder contains a single TV show" off.\n\n'
        '5. Say Yes when Kodi offers to scan. After this, every sync updates the library by '
        'itself.\n\n'
        'Files that could not be matched to a movie or show are not shown in the library. '
        'Find them under "Not matched" in this add-on.' % (root, root))
    xbmcgui.Dialog().textviewer(HEADING, text)
    action_done()


def enter_keys():
    """Backup way to type the keys, straight from the add-on menu."""
    dialog = xbmcgui.Dialog()
    fields = [('pm_api_key', 'Premiumize API key'),
              ('tmdb_key', 'TMDb API key'),
              ('omdb_key', 'OMDb API key (optional, for IMDb ratings)')]
    addon = utils.addon()
    for key, heading in fields:
        value = dialog.input(heading, defaultt=addon.getSetting(key))
        if value.strip():
            addon.setSetting(key, value.strip())
    action_done()
    test_keys_dialog()
    xbmc.executebuiltin('Container.Refresh')


def test_keys():
    test_keys_dialog()
    action_done()


def test_keys_dialog():
    lines = []
    key = utils.setting('pm_api_key').strip()
    if not key:
        lines.append('Premiumize: no API key entered')
    else:
        try:
            info = premiumize.Premiumize(key).account_info()
            lines.append('Premiumize: OK (account %s)' % info.get('customer_id', ''))
        except premiumize.PremiumizeError as exc:
            lines.append('Premiumize: %s' % exc)
    md, _ = make_metadata()
    checks = md.check_keys()
    lines.append('TMDb: %s' % checks['tmdb'][1])
    lines.append('OMDb: %s' % checks['omdb'][1])
    base, where = playback.find_dir_link()
    if not utils.setting_bool('use_dir_link', True):
        lines.append('HTTP folder link: switched off in settings')
    elif not base:
        lines.append('HTTP folder link: not found (playback uses API links)')
    else:
        found = 'from your Kodi sources' if where == 'sources' else 'from settings'
        state = 'OK' if net.url_ok(base + '/') else 'found but not answering'
        lines.append('HTTP folder link: %s (%s)' % (state, found))
    xbmcgui.Dialog().ok(HEADING, '\n'.join(lines))


def os_test():
    client = opensubs.OpenSubtitles(utils.setting('os_api_key'), utils.setting('os_username'),
                                    utils.setting('os_password'))
    if not client.configured:
        msg = 'Enter your OpenSubtitles username, password and API key first.'
    else:
        try:
            client.token(force=True)
            info = client.user_info()
            remaining = info.get('remaining_downloads')
            allowed = info.get('allowed_downloads')
            level = info.get('level') or ('VIP' if info.get('vip') else 'standard')
            msg = 'OpenSubtitles: OK\nAccount level: %s\nDownloads left today: %s of %s' % (
                level, remaining if remaining is not None else '?', allowed if allowed is not None else '?')
            if not utils.setting_bool('os_enabled', False):
                msg += '\n\nNote: "Fetch English subtitles" is switched off.'
        except opensubs.OSError_ as exc:
            msg = 'OpenSubtitles: %s' % exc
    xbmcgui.Dialog().ok(HEADING, msg)
    action_done()


EXPORT_NAME = 'pmlibrary-settings.json'


def export_settings():
    dialog = xbmcgui.Dialog()
    folder = dialog.browse(3, 'Choose where to save the settings (e.g. your USB stick)', 'files')
    if not folder:
        return action_done()
    data = {'addon': utils.ADDON_ID, 'version': 1, 'settings': {}}
    for key in utils.EXPORT_KEYS:
        data['settings'][key] = utils.setting(key)
    if not data['settings'].get('pm_dir_url'):
        base, _where = playback.find_dir_link()   # carry the HTTP folder link to the other device
        if base:
            data['settings']['pm_dir_url'] = base
    path = folder.rstrip('/\\') + '/' + EXPORT_NAME
    try:
        utils.fs_write(path, json.dumps(data, indent=1))
    except Exception:  # noqa: BLE001
        dialog.ok(HEADING, 'Could not write to that folder. Try another one.')
        return action_done()
    dialog.ok(HEADING, 'Settings saved as %s.\n\nThe file contains your API keys and passwords, so '
                       'delete it from the USB stick after importing it on the other device.' % EXPORT_NAME)
    action_done()


def import_settings():
    dialog = xbmcgui.Dialog()
    path = dialog.browse(1, 'Choose %s' % EXPORT_NAME, 'files', '.json')
    if not path:
        return action_done()
    try:
        data = json.loads(utils.fs_read(path))
        values = data['settings']
        if data.get('addon') != utils.ADDON_ID or not isinstance(values, dict):
            raise ValueError
    except Exception:  # noqa: BLE001
        dialog.ok(HEADING, 'That file is not a Premiumize Library settings file.')
        return action_done()
    addon = utils.addon()
    count = 0
    for key in utils.EXPORT_KEYS:
        if key in values and values[key] is not None:
            addon.setSetting(key, str(values[key]))
            count += 1
    dialog.ok(HEADING, 'Imported %d settings. Use "Test connections" to check them, then run '
                       '"Sync library now".' % count)
    action_done()


def fix(file_id):
    dialog = xbmcgui.Dialog()
    if utils.home_window().getProperty(RUNNING) == '1':
        dialog.ok(HEADING, 'A sync is running. Try again when it has finished.')
        return
    engine = sync.SyncEngine()
    engine.load()
    entry = engine.files.get(file_id)
    if not entry:
        dialog.ok(HEADING, 'This file is not part of the library (it may be too small, a sample, '
                           'or not synced yet).')
        return
    md, cache = make_metadata()
    if not md.enabled:
        dialog.ok(HEADING, 'Enter your TMDb API key in the add-on settings first.')
        return
    parsed = parser.parse(entry['name'], entry.get('dirs'))
    choice = dialog.select('Match this file as...', ['Movie', 'TV show'],
                           preselect=0 if parsed['kind'] == 'movie' else 1)
    if choice < 0:
        return
    kind = 'movie' if choice == 0 else 'tv'
    # No episode code in the name (or matched by hand before): pick show, season and
    # episode for this one file instead of asking for a rename.
    by_hand = kind == 'tv' and (not entry.get('tkey') or entry.get('manual'))
    query = dialog.input('Search TMDb for', defaultt=parsed['title'])
    if not query:
        return
    try:
        candidates = md.search_candidates(kind, query)
        cache.flush()
    except metadata.TmdbError as exc:
        dialog.ok(HEADING, 'TMDb search failed: %s' % exc)
        return
    if not candidates:
        dialog.ok(HEADING, 'No results for "%s".' % query)
        return
    picked = dialog.select('Choose the right match', [c['label'] for c in candidates])
    if picked < 0:
        return
    show_id = candidates[picked]['id']
    show_label = candidates[picked]['label']
    others = _others_like(engine, file_id) if kind == 'tv' else []
    if by_hand:
        numbers = _pick_episode(md, show_id, entry)
        cache.flush()
        if numbers is None:
            return
        engine.apply_manual_match(file_id, 'episode', show_id, numbers[0], numbers[1])
        more = _offer_others(engine, md, cache, show_id, show_label, others, taken={numbers})
        utils.home_window().setProperty(REQUEST, 'sync')
        if more:
            utils.notify('Matched %d file(s) to %s. Updating the library in the background.'
                         % (more + 1, show_label))
        else:
            utils.notify('Matched as season %d, episode %d. Updating the library in the background.'
                         % numbers)
        return
    count = engine.apply_manual_match(file_id, kind, show_id)
    if kind == 'tv':
        count += _offer_others(engine, md, cache, show_id, show_label, others)
    utils.home_window().setProperty(REQUEST, 'sync')
    utils.notify('Re-matching %d file(s) in the background.' % count)


def _ask_number(heading, default):
    value = xbmcgui.Dialog().numeric(0, heading, str(default))
    try:
        return int(value) if str(value).strip() else None
    except ValueError:
        return None


def _pick_episode(md, show_id, entry):
    """Ask which season and episode this file is. Returns (season, episode) or None."""
    dialog = xbmcgui.Dialog()
    if entry.get('manual') and entry.get('season') is not None and entry.get('episodes'):
        guess_season, guess_ep = entry['season'], entry['episodes'][0]
    else:
        guess_season, guess_ep = parser.guess_numbers(entry.get('name', ''), entry.get('dirs'))
    try:
        seasons = md.season_list(show_id)
    except metadata.TmdbError:
        seasons = []
    if len(seasons) == 1:
        season = seasons[0][0]
    elif seasons:
        labels = ['%s (%d episode%s)' % (name, n, '' if n == 1 else 's') for _, name, n in seasons]
        pre = next((i for i, x in enumerate(seasons) if x[0] == guess_season), 0)
        i = dialog.select('Which season is this file?', labels, preselect=pre)
        if i < 0:
            return None
        season = seasons[i][0]
    else:
        season = _ask_number('Season number (0 for specials)', guess_season)
        if season is None:
            return None
    try:
        episodes = md.episode_list(show_id, season)
    except metadata.TmdbError:
        episodes = []
    if episodes:
        labels = ['%d. %s' % (n, t) if t else 'Episode %d' % n for n, t in episodes]
        pre = next((i for i, x in enumerate(episodes) if x[0] == guess_ep), 0)
        i = dialog.select('Which episode is this file?', labels, preselect=pre)
        if i < 0:
            return None
        return season, episodes[i][0]
    episode = _ask_number('Episode number', guess_ep)
    if not episode:
        return None
    return season, episode


# ------------------------------------------------- several files to one show

def _others_like(engine, file_id):
    """Other unmatched files that look like the same show and a whole-show match would miss."""
    tkey = (engine.files.get(file_id) or {}).get('tkey')
    entry = engine.files.get(file_id) or {}
    out = []
    for fid in bulkmatch.similar(file_id, engine.files):
        other = engine.files[fid]
        if tkey and not entry.get('manual') and other.get('tkey') == tkey:
            continue        # re-matched with the show already
        out.append(fid)
    return out


def _offer_others(engine, md, cache, show_id, show_label, others, taken=()):
    """After one file was matched by hand: offer the similar files too. Returns how many."""
    others = [fid for fid in others if fid in engine.files]
    if not others:
        return 0
    names = sorted(engine.files[fid].get('name') or '' for fid in others)
    shown = '\n'.join(names[:4]) + ('\n... and %d more' % (len(names) - 4) if len(names) > 4 else '')
    ok = xbmcgui.Dialog().yesno(
        HEADING, '%d other unmatched file%s look like the same show:\n%s\n\nMatch %s to %s too? '
                 'You can check every episode before anything changes.'
        % (len(others), '' if len(others) == 1 else 's', shown,
           'it' if len(others) == 1 else 'them', show_label))
    if not ok:
        return 0
    return _assign(engine, md, cache, show_id, show_label, others, taken)


def _search_show(md, cache, default):
    """Search TMDb for a TV show. Returns (id, label) or None."""
    dialog = xbmcgui.Dialog()
    query = dialog.input('Search TMDb for the TV show', defaultt=default)
    if not query:
        return None
    try:
        candidates = md.search_candidates('tv', query)
        cache.flush()
    except metadata.TmdbError as exc:
        dialog.ok(HEADING, 'TMDb search failed: %s' % exc)
        return None
    if not candidates:
        dialog.ok(HEADING, 'No TV shows found for "%s".' % query)
        return None
    picked = dialog.select('Choose the right show', [c['label'] for c in candidates])
    if picked < 0:
        return None
    return candidates[picked]['id'], candidates[picked]['label']


def _catalog(md, show_id):
    """All seasons and episodes of a show: {season: {'name': ..., 'eps': [(number, title)]}}."""
    seasons = md.season_list(show_id)
    out = {}
    progress = xbmcgui.DialogProgress()
    progress.create(HEADING, 'Reading the episode list from TMDb...')
    try:
        for i, (season, name, _count) in enumerate(seasons):
            progress.update(int(100.0 * i / max(len(seasons), 1)), name)
            try:
                eps = md.episode_list(show_id, season)
            except metadata.TmdbError:
                eps = []
            out[season] = {'name': name, 'eps': eps}
    finally:
        progress.close()
    return out


def _season_order(catalog):
    return sorted(catalog, key=lambda s: (s == 0, s))     # specials last


def _ask_season(catalog, hint, count):
    seasons = _season_order(catalog)
    labels = ['%s (%d episode%s)' % (catalog[s]['name'], len(catalog[s]['eps']),
                                     '' if len(catalog[s]['eps']) == 1 else 's') for s in seasons]
    labels.append('None of these: I will set them one by one')
    pre = seasons.index(hint) if hint in seasons else 0
    i = xbmcgui.Dialog().select('Season of the %d file%s not recognised by name?'
                                % (count, '' if count == 1 else 's'), labels, preselect=pre)
    if i < 0 or i >= len(seasons):
        return None
    return seasons[i]


def _pick_from_catalog(catalog, current):
    """Choose season and episode from the show's list. Returns (season, episode) or None."""
    dialog = xbmcgui.Dialog()
    seasons = _season_order(catalog)
    cur_season = current[0] if current else None
    cur_ep = current[1] if current else None
    if len(seasons) == 1:
        season = seasons[0]
    else:
        labels = ['%s (%d episodes)' % (catalog[s]['name'], len(catalog[s]['eps'])) for s in seasons]
        pre = seasons.index(cur_season) if cur_season in seasons else 0
        i = dialog.select('Which season?', labels, preselect=pre)
        if i < 0:
            return None
        season = seasons[i]
    eps = catalog[season]['eps']
    if not eps:
        number = _ask_number('Episode number', cur_ep or 1)
        return (season, number) if number else None
    labels = ['%d. %s' % (n, t) if t else 'Episode %d' % n for n, t in eps]
    pre = next((i for i, x in enumerate(eps) if x[0] == cur_ep), 0)
    i = dialog.select('Which episode?', labels, preselect=pre)
    if i < 0:
        return None
    return season, eps[i][0]


def _row_label(entry, value, catalog, dups):
    if not value:
        return 'S??E??  [I]not recognised: left out[/I]  <  %s' % entry.get('name', '')
    season, number, how = value
    title = dict((catalog.get(season) or {}).get('eps') or []).get(number, '')
    if how == 'order':
        title += ' [I](guessed from the order)[/I]'
    if (season, number) in dups:
        title = '[COLOR red]twice![/COLOR] ' + title
    return 'S%02dE%02d  %s  <  %s' % (season, number, title.strip(), entry.get('name', ''))


def _assign(engine, md, cache, show_id, show_label, file_ids, taken=()):
    """Work out the episode of each file, let the user check the list, then match them.

    Returns how many files were matched (0 when cancelled; nothing is changed then).
    """
    dialog = xbmcgui.Dialog()
    rows = sorted(((fid, engine.files[fid]) for fid in file_ids if fid in engine.files),
                  key=lambda r: (r[1].get('name') or '').lower())
    if not rows:
        return 0
    try:
        catalog = _catalog(md, show_id)
        cache.flush()
    except metadata.TmdbError as exc:
        dialog.ok(HEADING, 'Could not read the episode list from TMDb: %s' % exc)
        return 0
    if not catalog:
        dialog.ok(HEADING, 'TMDb has no seasons for %s.' % show_label)
        return 0
    eps = dict((s, c['eps']) for s, c in catalog.items())
    proposal = bulkmatch.propose(rows, eps, None, taken)
    unknown = [r for r in rows if not proposal.get(r[0])]
    if unknown:
        season = _ask_season(catalog, bulkmatch.season_hint(unknown), len(unknown))
        if season is not None:
            proposal = bulkmatch.propose(rows, eps, season, taken)

    while True:
        dups = bulkmatch.duplicates(proposal)
        ready = sum(1 for v in proposal.values() if v)
        labels = ['[B]Match %d file%s to %s[/B]' % (ready, '' if ready == 1 else 's', show_label)]
        labels += [_row_label(entry, proposal.get(fid), catalog, dups) for fid, entry in rows]
        i = dialog.select('Check the episodes, then choose the first line', labels)
        if i < 0:
            utils.notify('Nothing was changed.')
            return 0
        if i == 0:
            if not ready:
                dialog.ok(HEADING, 'No file has an episode yet. Choose a file in the list to set it.')
                continue
            if dups and not dialog.yesno(
                    HEADING, 'Some files have the same episode (marked "twice!"). That is fine for two '
                             'copies of one episode, otherwise change one of them.\n\nMatch them anyway?'):
                continue
            break
        fid, entry = rows[i - 1]
        act = dialog.select(entry.get('name', ''), ['Choose the season and episode',
                                                    'Leave this file out'])
        if act == 0:
            pick = _pick_from_catalog(catalog, proposal.get(fid))
            if pick:
                proposal[fid] = (pick[0], pick[1], 'hand')
        elif act == 1:
            proposal[fid] = None

    matches = [(fid, show_id, proposal[fid][0], proposal[fid][1]) for fid, _e in rows if proposal.get(fid)]
    engine.apply_episode_matches(matches)
    return len(matches)


def match_many(file_id=None):
    """Tick several unmatched files, pick the show once, check the episodes, match them all."""
    dialog = xbmcgui.Dialog()
    if utils.home_window().getProperty(RUNNING) == '1':
        dialog.ok(HEADING, 'A sync is running. Try again when it has finished.')
        return
    engine = sync.SyncEngine()
    engine.load()
    rows = sorted(((e.get('name') or '', fid) for fid, e in engine.files.items() if not e.get('matched')),
                  key=lambda r: r[0].lower())
    if not rows:
        dialog.ok(HEADING, 'Every file is matched.')
        return
    ids = [fid for _n, fid in rows]
    preselect = []
    if file_id and file_id in ids:
        like = set(bulkmatch.similar(file_id, engine.files)) | {file_id}
        preselect = [i for i, fid in enumerate(ids) if fid in like]
    labels = []
    for name, fid in rows:
        dirs = engine.files[fid].get('dirs') or []
        labels.append('%s   [I](%s)[/I]' % (name, dirs[-1]) if dirs else name)
    try:
        chosen = dialog.multiselect('Tick the files of one TV show', labels, preselect=preselect)
    except TypeError:       # very old Kodi without preselect
        chosen = dialog.multiselect('Tick the files of one TV show', labels)
    if not chosen:
        return
    md, cache = make_metadata()
    if not md.enabled:
        dialog.ok(HEADING, 'Enter your TMDb API key in the add-on settings first.')
        return
    fids = [ids[i] for i in chosen]
    default = bulkmatch.common_title([engine.files[f] for f in fids])
    picked = _search_show(md, cache, default)
    if not picked:
        return
    count = _assign(engine, md, cache, picked[0], picked[1], fids)
    if count:
        utils.home_window().setProperty(REQUEST, 'sync')
        utils.notify('Matched %d file(s) to %s. Updating the library in the background.'
                     % (count, picked[1]))


# --------------------------------------------------------------------- router

def main():
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    if action is None:
        root_menu()
    elif action == 'browse':
        browse(params.get('id'))
    elif action == 'unmatched':
        unmatched()
    elif action == 'play':
        play(params.get('id', ''))
    elif action == 'sync_now':
        request_sync('sync')
    elif action == 'rebuild':
        rebuild()
    elif action == 'setup':
        setup_guide()
    elif action == 'test_keys':
        test_keys()
    elif action == 'enter_keys':
        enter_keys()
    elif action == 'os_test':
        os_test()
    elif action == 'search':                       # Kodi: Subtitles > Download
        subservice.search(HANDLE)
    elif action == 'manualsearch':
        subservice.search(HANDLE, manual_query=params.get('searchstring', ''))
    elif action == 'sub_download':
        subservice.download(HANDLE, params.get('file_id', ''))
    elif action == 'sub_sync':
        subservice.sync_action(HANDLE)
    elif action == 'sub_unsync':
        subservice.unsync_action(HANDLE)
    elif action == 'sync_subs':
        subservice.sync_from_menu()
        action_done()
    elif action == 'os_forget':
        count = subfetch.forget_failed_searches()
        xbmcgui.Dialog().ok(HEADING, 'Forgot %d failed subtitle search%s. The next play of those '
                                     'videos searches OpenSubtitles again.' % (count, '' if count == 1 else 'es'))
        action_done()
    elif action == 'export_settings':
        export_settings()
    elif action == 'import_settings':
        import_settings()
    elif action == 'vault_export':
        action_done()
        vaultui.export_locked()
    elif action == 'vault_import':
        action_done()
        vaultui.fill_in(auto=False)
    elif action == 'fix':
        fix(params.get('id', ''))
    elif action == 'match_many':
        match_many(params.get('id'))
    elif action == 'delete':
        fid = params.get('id', '')
        delete.delete(params.get('name') or fid, [fid] if fid else [])
    elif action == 'settings':
        xbmc.executebuiltin('Addon.OpenSettings(%s)' % utils.ADDON_ID)
        action_done()


if __name__ == '__main__':
    main()
