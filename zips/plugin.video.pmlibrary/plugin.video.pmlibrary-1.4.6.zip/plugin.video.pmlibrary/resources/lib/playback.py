# -*- coding: utf-8 -*-
"""Playback through the Premiumize HTTP folder link (dir.premiumize.me) plus subtitles.

The HTTP folder link mirrors the cloud as a browsable web folder, so Kodi can open the
folder of the playing file (needed for "Browse for subtitle") and nearby subtitle files
can be handed to the player directly.
"""
import os
import re
from urllib.parse import quote

from . import utils

SUB_EXT = ('.srt', '.ass', '.ssa', '.vtt')
SUB_DIRS = ('subs', 'sub', 'subtitles', 'subtitle')
MAX_SUBS = 8
_DIR_RE = re.compile(r'https?://dir\.premiumize\.me(?::443)?/[A-Za-z0-9_\-]+', re.I)


def is_subtitle(name):
    return os.path.splitext(name)[1].lower() in SUB_EXT


def subtitle_folder_key(dirs):
    """Subtitles in a 'Subs' folder belong to the folder above it."""
    dirs = list(dirs or [])
    if dirs and dirs[-1].strip().lower() in SUB_DIRS:
        dirs = dirs[:-1]
    return '/'.join(dirs)


def pick_subtitles(video_name, subs, only_video_in_folder):
    """Subtitles for one video: names that start with the video's name, or every
    subtitle in the folder when the video is the only one there. The closest name
    comes first (Kodi turns on the first one), English-looking names win ties."""
    from .opensubs import name_similarity
    stem = os.path.splitext(video_name)[0].lower()
    matched = [s for s in subs if os.path.splitext(s['name'])[0].lower().startswith(stem)]
    if not matched and only_video_in_folder:
        matched = list(subs)

    def key(s):
        english = bool(re.search(r'(?i)(^|[^a-z])(en|eng|english)([^a-z]|$)', s['name']))
        return (-round(name_similarity(video_name, s['name']), 3), not english, s['name'].lower())
    matched.sort(key=key)
    return matched[:MAX_SUBS]


def _normalize(url):
    url = (url or '').strip().rstrip('/')
    if not url:
        return ''
    url = re.sub(r'(?i)^http://(?=dir\.premiumize\.me)', 'https://', url)
    return re.sub(r'(?i)(://dir\.premiumize\.me):443(?=/)', r'\1', url)


def find_dir_link():
    """The user's HTTP folder link, from the setting or from Kodi's sources.

    Returns (link, where) with where = 'setting', 'sources' or ''.
    """
    typed = _normalize(utils.setting('pm_dir_url'))
    if typed:
        return typed, 'setting'
    try:
        path = utils.translate('special://profile/sources.xml')
        with open(path, 'r', encoding='utf-8', errors='replace') as handle:
            match = _DIR_RE.search(handle.read())
    except OSError:
        match = None
    if match:
        return _normalize(match.group(0)), 'sources'
    return '', ''


ROUTE_PROP = 'pmlib.route'
ROUTE_TTL = 15 * 60       # seconds a speed test result is reused
ROUTE_MARGIN = 1.25       # the API link must be this much faster to be preferred


def remembered_route(window, now=None):
    """'dir' or 'api' when a recent speed test decided, else ''."""
    import json
    import time
    try:
        data = json.loads(window.getProperty(ROUTE_PROP) or '{}')
    except ValueError:
        return ''
    now = time.time() if now is None else now
    if data.get('route') in ('dir', 'api') and now - float(data.get('at', 0)) < ROUTE_TTL:
        return data['route']
    return ''


def remember_route(window, route, now=None):
    import json
    import time
    window.setProperty(ROUTE_PROP, json.dumps({'route': route, 'at': time.time() if now is None else now}))


def pick_faster(dir_speed, api_speed):
    """'dir' or 'api' (or '' when neither answered). The folder link wins ties."""
    if dir_speed <= 0 and api_speed <= 0:
        return ''
    if api_speed > dir_speed * ROUTE_MARGIN:
        return 'api'
    return 'dir' if dir_speed > 0 else 'api'


def mbps(bytes_per_second):
    return '%.1f Mbit/s' % (bytes_per_second * 8 / 1e6)


def file_url(base, cloud_path):
    parts = [quote(p, safe='') for p in cloud_path.split('/') if p]
    return base.rstrip('/') + '/' + '/'.join(parts)
