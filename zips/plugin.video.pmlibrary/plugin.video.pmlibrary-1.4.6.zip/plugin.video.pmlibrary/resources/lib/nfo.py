# -*- coding: utf-8 -*-
"""Build Kodi NFO files (movie, tvshow, episodedetails) from metadata dicts."""
import re
import xml.etree.ElementTree as ET

HEADER = '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
_CTRL = re.compile('[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]')
MAX_CAST = 15


def _txt(value):
    return _CTRL.sub('', str(value))


def _add(parent, tag, value=None, **attrs):
    if value is None or value == '':
        return None
    el = ET.SubElement(parent, tag, {k: str(v) for k, v in attrs.items()})
    el.text = _txt(value)
    return el


def _indent(elem, level=0):
    i = '\n' + level * '  '
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + '  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            _indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


def _render(root):
    _indent(root)
    return ET.tostring(root, encoding='unicode')


def _ratings(parent, ratings):
    if not ratings:
        return
    box = ET.SubElement(parent, 'ratings')
    for r in ratings:
        el = ET.SubElement(box, 'rating', {
            'name': _txt(r['name']), 'max': '10',
            'default': 'true' if r.get('default') else 'false'})
        ET.SubElement(el, 'value').text = '%.1f' % float(r['value'])
        if r.get('votes'):
            ET.SubElement(el, 'votes').text = str(int(r['votes']))


def _uniqueids(parent, ids, default):
    for kind in ('imdb', 'tmdb', 'tvdb'):
        value = ids.get(kind)
        if value:
            _add(parent, 'uniqueid', value, type=kind, default='true' if kind == default else 'false')


def _cast(parent, cast):
    for person in (cast or [])[:MAX_CAST]:
        actor = ET.SubElement(parent, 'actor')
        _add(actor, 'name', person.get('name'))
        _add(actor, 'role', person.get('role'))
        _add(actor, 'order', person.get('order'))
        _add(actor, 'thumb', person.get('thumb'))


def _art(parent, poster, fanart):
    _add(parent, 'thumb', poster, aspect='poster')
    if fanart:
        box = ET.SubElement(parent, 'fanart')
        _add(box, 'thumb', fanart)


def movie_nfo(m):
    root = ET.Element('movie')
    _add(root, 'title', m.get('title'))
    _add(root, 'originaltitle', m.get('original_title'))
    _add(root, 'year', m.get('year'))
    _add(root, 'premiered', m.get('premiered'))
    _add(root, 'plot', m.get('plot'))
    _add(root, 'tagline', m.get('tagline'))
    _add(root, 'runtime', m.get('runtime'))
    _add(root, 'mpaa', m.get('mpaa'))
    for tag, key in (('genre', 'genres'), ('studio', 'studios'), ('country', 'countries'),
                     ('director', 'directors'), ('credits', 'writers')):
        for value in m.get(key) or []:
            _add(root, tag, value)
    _add(root, 'set', m.get('collection'))
    _ratings(root, m.get('ratings'))
    _uniqueids(root, {'imdb': m.get('imdb_id'), 'tmdb': m.get('tmdb_id')}, 'imdb' if m.get('imdb_id') else 'tmdb')
    _art(root, m.get('poster'), m.get('fanart'))
    _cast(root, m.get('cast'))
    return HEADER + _render(root) + '\n'


def tvshow_nfo(s):
    root = ET.Element('tvshow')
    _add(root, 'title', s.get('title'))
    _add(root, 'originaltitle', s.get('original_title'))
    _add(root, 'showtitle', s.get('title'))
    _add(root, 'year', s.get('year'))
    _add(root, 'premiered', s.get('premiered'))
    _add(root, 'plot', s.get('plot'))
    _add(root, 'status', s.get('status'))
    _add(root, 'mpaa', s.get('mpaa'))
    for tag, key in (('genre', 'genres'), ('studio', 'studios')):
        for value in s.get(key) or []:
            _add(root, tag, value)
    _ratings(root, s.get('ratings'))
    _uniqueids(root, {'imdb': s.get('imdb_id'), 'tmdb': s.get('tmdb_id'), 'tvdb': s.get('tvdb_id')}, 'tmdb')
    _add(root, 'thumb', s.get('poster'), aspect='poster')
    for number, url in sorted((s.get('season_posters') or {}).items(), key=lambda kv: int(kv[0])):
        _add(root, 'thumb', url, aspect='poster', type='season', season=int(number))
    if s.get('fanart'):
        box = ET.SubElement(root, 'fanart')
        _add(box, 'thumb', s['fanart'])
    _cast(root, s.get('cast'))
    return HEADER + _render(root) + '\n'


def episode_nfo(show_title, season, infos):
    """One <episodedetails> block per episode; several blocks make a multi-episode file."""
    blocks = []
    for info in infos:
        root = ET.Element('episodedetails')
        _add(root, 'title', info.get('title') or 'Episode %d' % info['episode'])
        _add(root, 'showtitle', show_title)
        _add(root, 'season', season)
        _add(root, 'episode', info['episode'])
        _add(root, 'aired', info.get('aired'))
        _add(root, 'plot', info.get('plot'))
        _add(root, 'runtime', info.get('runtime'))
        _ratings(root, info.get('ratings'))
        _uniqueids(root, {'imdb': info.get('imdb_id')}, 'imdb')
        _add(root, 'thumb', info.get('still'))
        blocks.append(_render(root))
    return HEADER + '\n'.join(blocks) + '\n'
