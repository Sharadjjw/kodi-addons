# -*- coding: utf-8 -*-
"""Dialogs for PIN-locked settings: create the locked file, and fill in a new Shield."""
import json

import xbmc
import xbmcgui

from . import utils, vault

HEADING = 'Premiumize Library'
REQUEST = 'pmlib.request'
MAX_TRIES = 3
NAMES = {utils.ADDON_ID: 'Premiumize Library', vault.TC_ID: 'TorrentClaw'}


def _ask_pin(dialog, heading):
    return dialog.input(heading, type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT) or ''


# ------------------------------------------------------------------ export

def export_locked():
    """On a Shield that is already set up: save locked-settings.json, locked with a PIN."""
    dialog = xbmcgui.Dialog()
    if not utils.setting('pm_api_key').strip():
        dialog.ok(HEADING, 'This Shield has no Premiumize API key yet. Create the locked settings on a '
                           'Shield that is fully set up.')
        return
    dialog.ok(HEADING, 'You will choose a settings PIN (at least %d characters, letters and numbers mixed '
                       'is best). A new Shield asks for it once.\n\nWrite it down somewhere safe: it cannot '
                       'be recovered.' % vault.MIN_PIN)
    pin = _ask_pin(dialog, 'Choose your settings PIN')
    if not pin:
        return
    if not vault.pin_ok(pin):
        dialog.ok(HEADING, 'The PIN must have at least %d characters.' % vault.MIN_PIN)
        return
    if _ask_pin(dialog, 'Type the PIN again') != pin:
        dialog.ok(HEADING, 'The two PINs were different. Nothing was saved.')
        return
    folder = dialog.browse(3, 'Choose where to save it (e.g. your USB stick)', 'files')
    if not folder:
        return
    progress = utils.BgProgress()
    progress.start('Locking your settings...')
    try:
        bundle = vault.make_bundle()
        box = vault.lock_bundle(bundle, pin)
    finally:
        progress.close()
    path = folder.rstrip('/\\') + '/' + vault.FILE_NAME
    try:
        utils.fs_write(path, json.dumps(box, indent=1))
    except Exception:  # noqa: BLE001
        dialog.ok(HEADING, 'Could not write to that folder. Try another one.')
        return
    included = [NAMES[a] for a in (utils.ADDON_ID, vault.TC_ID) if a in bundle['addons']]
    utils.log('Locked settings saved for: %s' % ', '.join(included))
    dialog.ok(HEADING, 'Saved %s (settings of %s).\n\nNext: send this file to Claude, who puts it next to your '
                       'add-ons. Only your PIN can unlock it.'
              % (vault.FILE_NAME, ' and '.join(included)))


# ------------------------------------------------------------------ import

def _summary(done):
    parts = ['%s (%d settings)' % (NAMES.get(a, a), n) for a, n in done.items()]
    return ', '.join(parts) or 'nothing'


def fill_in(auto=False):
    """Download the locked settings from the repository and fill in this Shield.

    auto=True is the start-up check: it only asks when an installed add-on has no keys yet,
    stays silent when there is nothing to do, and fills in only those fresh add-ons, so
    nothing already set up on this Shield is overwritten."""
    dialog = xbmcgui.Dialog()
    fresh = vault.needs_setup()
    if auto and not fresh:
        return 'already set up'
    try:
        box = vault.download_locked()
    except vault.VaultError as exc:
        if auto:
            utils.log('Locked settings not checked: %s' % exc)
            return 'unavailable'
        dialog.ok(HEADING, str(exc))
        return 'unavailable'
    if box is None:
        if not auto:
            dialog.ok(HEADING, 'Your repository has no locked settings yet. Create them on a Shield that is set '
                               'up: Settings > Sync > Create locked settings for new Shields.')
        return 'none in repository'
    if auto:
        names = ' and '.join(NAMES[a] for a in fresh)
        if not dialog.yesno(HEADING, '%s %s not set up on this Shield yet.\n\nFill in your keys and settings '
                                     'from your repository? You need your settings PIN.'
                            % (names, 'are' if len(fresh) > 1 else 'is'),
                            nolabel='Not now', yeslabel='Enter PIN'):
            return 'declined'
    elif not fresh and not dialog.yesno(HEADING, 'Replace the settings of Premiumize Library and TorrentClaw on '
                                                 'this Shield with the ones in your repository?'):
        return 'declined'
    bundle = None
    for attempt in range(MAX_TRIES):
        pin = _ask_pin(dialog, 'Your settings PIN' if attempt == 0 else 'Wrong PIN - try again')
        if not pin:
            return 'cancelled'
        try:
            bundle = vault.unlock_bundle(box, pin)
            break
        except vault.WrongPin:
            continue
        except vault.VaultError as exc:
            dialog.ok(HEADING, str(exc))
            return 'damaged'
    if bundle is None:
        dialog.ok(HEADING, 'Wrong PIN %d times. You can try again any time: Settings > Sync > Fill in '
                           'settings from my repository.' % MAX_TRIES)
        return 'wrong pin'
    done = vault.apply(bundle, only=fresh if auto else None)
    utils.log('Filled in settings from the repository: %s' % _summary(done))
    note = ''
    if vault.TC_ID in bundle.get('addons', {}) and vault.TC_ID not in done:
        note = ('\n\nTorrentClaw is not installed here yet. Install it from the SJJ Kodi Repository, then use '
                '"Fill in settings from my repository" again.')
    if utils.ADDON_ID in done:
        utils.home_window().setProperty(REQUEST, 'sync')
        note += '\n\nYour library sync starts now.'
    dialog.ok(HEADING, 'Settings filled in: %s.%s' % (_summary(done), note))
    return 'filled'


def startup_check(monitor, delay=15):
    """Run from the service a little after Kodi starts."""
    if monitor.waitForAbort(delay):
        return
    try:
        status = fill_in(auto=True)
        utils.log('Start-up settings check: %s' % status)
    except Exception as exc:  # noqa: BLE001 - never stop the service over this
        utils.log('Start-up settings check failed: %s' % type(exc).__name__, xbmc.LOGWARNING)
