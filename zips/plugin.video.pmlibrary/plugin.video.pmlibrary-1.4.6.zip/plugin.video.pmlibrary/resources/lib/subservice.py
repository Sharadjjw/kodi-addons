# -*- coding: utf-8 -*-
"""Kodi subtitle service (Subtitles > Download) and the on-screen subtitle sync.

Kodi calls plugin://plugin.video.pmlibrary/?action=search (or manualsearch) when the
user opens Subtitles > Download and picks this service, and calls the URL of the chosen
result to download it. Besides OpenSubtitles results the list offers "Sync the current
subtitle to the dialogue", which re-times the subtitle from lines the viewer marks.
"""
import json
import os
import time
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcplugin

from . import opensubs, playback, premiumize, subfetch, subsync, sync, utils

CURRENT_PROP = 'pmlib.current'
SYNC_FILE = 'subs_sync.json'
HEADING = 'Premiumize Library'
ADDON_URL = 'plugin://%s/' % utils.ADDON_ID
WINDOW_BEFORE = 90       # seconds of lines shown before "now"
WINDOW_AFTER = 150       # and after


# --------------------------------------------------------- what is playing

def remember_current(file_id, url):
    utils.home_window().setProperty(CURRENT_PROP, json.dumps({'id': file_id, 'url': url, 't': time.time()}))


def current_entry(player=None):
    """(file_id, index entry) for the library video playing now, or (None, None)."""
    player = player or xbmc.Player()
    try:
        playing = player.getPlayingFile()
    except RuntimeError:
        return None, None
    try:
        note = json.loads(utils.home_window().getProperty(CURRENT_PROP) or '{}')
    except ValueError:
        note = {}
    if not note.get('id') or note.get('url') != playing:
        return None, None
    entry = ((utils.load_json(sync.INDEX_FILE, {}).get('files')) or {}).get(note['id'])
    return (note['id'], entry) if entry else (None, None)


def _client():
    return opensubs.OpenSubtitles(utils.setting('os_api_key'), utils.setting('os_username'),
                                  utils.setting('os_password'))


# ------------------------------------------------------------- the list

def _item(handle, label2, url, sync_=False, hi=False, rating='0'):
    li = xbmcgui.ListItem(label='English', label2=label2)
    li.setArt({'icon': rating, 'thumb': 'en'})
    li.setProperty('sync', 'true' if sync_ else 'false')
    li.setProperty('hearing_imp', 'true' if hi else 'false')
    xbmcplugin.addDirectoryItem(handle, url, li, False)


def _url(**params):
    return ADDON_URL + '?' + urlencode(params)


def search(handle, manual_query=None):
    """List sync actions plus English subtitles for the playing library video."""
    fid, entry = current_entry()
    if fid:
        _item(handle, 'Sync the current subtitle to the dialogue (pick a line as you hear it)',
              _url(action='sub_sync'), rating='5')
        if fid in utils.load_json(SYNC_FILE, {}):
            _item(handle, 'Undo subtitle sync (back to the original timing)', _url(action='sub_unsync'))
    client = _client()
    if not client.configured:
        _item(handle, 'Set up OpenSubtitles in the Premiumize Library settings to search here',
              _url(action='settings'))
        return xbmcplugin.endOfDirectory(handle)

    if manual_query:
        attempts = [{'query': manual_query}]
    elif entry:
        attempts = subfetch.search_params(entry)
    else:
        attempts = _attempts_from_player()
    moviehash = ''
    if entry and entry.get('size'):
        try:
            moviehash = opensubs.remote_hash(xbmc.Player().getPlayingFile(), entry['size'])
        except RuntimeError:
            moviehash = ''
    name = (entry or {}).get('name') or _playing_name()
    seen, results = set(), []
    try:
        for params in attempts:
            tries = [dict(params, moviehash=moviehash), params] if moviehash else [params]
            for p in tries:
                for item in client.search(**p):
                    key = item.get('id')
                    if key not in seen:
                        seen.add(key)
                        results.append(item)
            if results:
                break
    except opensubs.OSError_ as exc:
        _item(handle, 'OpenSubtitles: %s' % exc, _url(action='os_test'))
        return xbmcplugin.endOfDirectory(handle)

    for file_id, item in opensubs.rank(results, name, utils.setting_bool('os_hearing_impaired', False))[:30]:
        a = item.get('attributes') or {}
        label = a.get('release') or (a.get('files') or [{}])[0].get('file_name') or 'Subtitle %s' % file_id
        dls = int(a.get('download_count') or 0)
        rating = str(min(5, max(0, len(str(dls)) - 1)))   # 0..5 stars by popularity
        _item(handle, label, _url(action='sub_download', file_id=file_id),
              sync_=bool(a.get('moviehash_match')), hi=bool(a.get('hearing_impaired')), rating=rating)
    xbmcplugin.endOfDirectory(handle)


def _playing_name():
    try:
        return os.path.basename(xbmc.Player().getPlayingFile().split('?')[0])
    except RuntimeError:
        return ''


def _attempts_from_player():
    """Search by the playing item's library info when it is not one of our files."""
    try:
        tag = xbmc.Player().getVideoInfoTag()
    except (RuntimeError, AttributeError):
        return []
    show = tag.getTVShowTitle()
    if show:
        return [{'type': 'episode', 'query': show, 'season_number': tag.getSeason(),
                 'episode_number': tag.getEpisode()}]
    imdb = tag.getIMDBNumber()
    attempts = []
    if imdb:
        attempts.append({'type': 'movie', 'imdb_id': subfetch._digits(imdb)})
    if tag.getTitle():
        q = {'type': 'movie', 'query': tag.getTitle()}
        if tag.getYear():
            q['year'] = tag.getYear()
        attempts.append(q)
    return attempts


def _return_file(handle, path):
    xbmcplugin.addDirectoryItem(handle, path, xbmcgui.ListItem(label=path), False)
    xbmcplugin.endOfDirectory(handle)


def download(handle, file_id):
    fid, _entry = current_entry()
    try:
        content, _remaining = _client().download(file_id)
    except opensubs.OSError_ as exc:
        utils.notify(str(exc), icon=xbmcgui.NOTIFICATION_ERROR, ms=7000)
        return xbmcplugin.endOfDirectory(handle, succeeded=False)
    if fid:
        path = subfetch._cache_path(fid)          # becomes this video's subtitle from now on
        state = utils.load_json(SYNC_FILE, {})
        if state.pop(fid, None) is not None:      # a new file starts with fresh timing
            utils.save_json(SYNC_FILE, state)
    else:
        path = os.path.join(subfetch.cache_dir(), 'download.en.srt')
    with open(path, 'wb') as handle_:
        handle_.write(content)
    _return_file(handle, path)


# ------------------------------------------------------------------ sync

def _candidates(fid, entry):
    """Subtitle files that can be synced for this video: (label, loader) pairs."""
    out = []
    cached = subfetch.cached_file(fid)
    if cached:
        out.append(('Subtitle saved by this add-on', lambda: open(cached, 'rb').read(), 'cached'))
    base, _where = playback.find_dir_link()
    for sub in entry.get('subs') or []:
        def load(sub=sub):
            from . import net
            if base:
                url = playback.file_url(base, sub['path'])
                data = net.get_bytes(url)
                if data is not None:
                    return data
            link = premiumize.Premiumize(utils.setting('pm_api_key').strip()).resolve_link(sub['id'])
            data = net.get_bytes(link)
            if data is None:
                raise IOError('download failed')
            return data
        out.append(('Cloud file: %s' % sub['name'], load, 'cloud'))
    return out


def _orig_path(fid):
    return os.path.join(subfetch.cache_dir(), '%s.orig.srt' % fid.replace('/', '_'))


def _pick_line(dialog, player, shown_cues):
    """Show lines around 'now'; returns (cue index, moment heard) or (None, None)."""
    now = player.getTime()
    near = [i for i, (s, _e, _t) in enumerate(shown_cues) if now - WINDOW_BEFORE <= s <= now + WINDOW_AFTER]
    if len(near) < 5:
        near = sorted(range(len(shown_cues)), key=lambda i: abs(shown_cues[i][0] - now))[:30]
        near.sort()
    while True:
        labels = ['Show lines from the whole video...'] + [
            '[%s]  %s' % (_clock(shown_cues[i][0]), subsync.plain(shown_cues[i][2])[:80]) for i in near]
        upcoming = [n for n, i in enumerate(near) if shown_cues[i][0] >= now]
        pre = (upcoming[0] if upcoming else len(near) - 1) + 1
        choice = dialog.select('Press OK the moment you hear the highlighted line spoken', labels,
                               preselect=pre)
        heard = player.getTime() - subsync.REACTION
        if choice < 0:
            return None, None
        if choice == 0:
            near = list(range(len(shown_cues)))
            continue
        return near[choice - 1], heard


def _clock(seconds):
    seconds = max(0, int(seconds))
    h, rest = divmod(seconds, 3600)
    return ('%d:%02d:%02d' % (h, rest // 60, rest % 60)) if h else ('%02d:%02d' % (rest // 60, rest % 60))


def sync_flow(player=None):
    """Interactive sync. Returns (path of the re-timed file, message) or (None, message)."""
    player = player or xbmc.Player()
    dialog = xbmcgui.Dialog()
    fid, entry = current_entry(player)
    if not fid:
        return None, 'Sync works for videos played from your Premiumize library.'
    state = utils.load_json(SYNC_FILE, {})
    st = state.get(fid)
    orig = _orig_path(fid)
    if st and not os.path.isfile(orig):
        st = None
    if not st:
        candidates = _candidates(fid, entry)
        if not candidates:
            return None, 'This video has no subtitle file to sync. Download one first.'
        pick = 0
        if len(candidates) > 1:
            pick = dialog.select('Which subtitle is out of sync?', [c[0] for c in candidates])
            if pick < 0:
                return None, ''
        label, loader, kind = candidates[pick]
        try:
            data = loader()
        except Exception:  # noqa: BLE001 - network or file problem
            return None, 'Could not read that subtitle file.'
        if not subsync.parse_srt(data):
            return None, 'Only .srt subtitle files can be synced.'
        with open(orig, 'wb') as handle_:
            handle_.write(data if isinstance(data, bytes) else data.encode('utf-8'))
        st = {'label': label, 'kind': kind, 'points': []}

    with open(orig, 'rb') as handle_:
        cues = subsync.parse_srt(handle_.read())
    shown = subsync.mapped(cues, subsync.fit(st['points']))
    index, heard = _pick_line(dialog, player, shown)
    if index is None:
        return None, ''
    points = [p for p in st['points'] if abs(p[0] - cues[index][0]) > 30]
    points.append([cues[index][0], heard])
    st['points'] = points[-6:]
    mapping = subsync.fit(st['points'])
    out = subsync.apply(cues, mapping)
    path = subfetch._cache_path(fid)
    with open(path, 'w', encoding='utf-8') as handle_:
        handle_.write(subsync.format_srt(out))
    state[fid] = st
    utils.save_json(SYNC_FILE, state)
    message = subsync.describe(mapping)
    if len(st['points']) == 1:
        message += '. If it drifts later in the video, sync once more near the end.'
    return path, message


def unsync():
    """Back to the original timing. Returns (path to load or None, message)."""
    fid, _entry = current_entry()
    if not fid:
        return None, 'Nothing to undo for this video.'
    state = utils.load_json(SYNC_FILE, {})
    st = state.pop(fid, None)
    utils.save_json(SYNC_FILE, state)
    orig = _orig_path(fid)
    cached = subfetch._cache_path(fid)
    if not st or not os.path.isfile(orig):
        return None, 'Nothing to undo for this video.'
    if st.get('kind') == 'cached':
        os.replace(orig, cached)
        return cached, 'Back to the original timing.'
    if os.path.isfile(cached):
        os.remove(cached)
    path = os.path.join(subfetch.cache_dir(), 'original.en.srt')
    os.replace(orig, path)
    return path, 'Back to the original timing.'


def sync_action(handle):
    """Called from the subtitle list: returns the re-timed file for Kodi to load."""
    path, message = sync_flow()
    if message:
        utils.notify(message, ms=6000)
    if path:
        return _return_file(handle, path)
    xbmcplugin.endOfDirectory(handle, succeeded=False)


def unsync_action(handle):
    path, message = unsync()
    utils.notify(message)
    if path:
        return _return_file(handle, path)
    xbmcplugin.endOfDirectory(handle, succeeded=False)


def sync_from_menu():
    """Called from the add-on's own menu while a video plays."""
    player = xbmc.Player()
    path, message = sync_flow(player)
    if path:
        player.setSubtitles(path)
        player.showSubtitles(True)
    if message:
        xbmcgui.Dialog().ok(HEADING, message)
