# -*- coding: utf-8 -*-
"""OpenSubtitles.com REST client (English only) and the OpenSubtitles file hash.

Nothing here writes the API key, password, token or download links to the log.
"""
import difflib
import math
import re
import struct
import time

import requests

from . import utils

API_URL = 'https://api.opensubtitles.com/api/v1/'
TIMEOUT = 30
TOKEN_FILE = 'os_token.json'
TOKEN_TTL = 20 * 3600          # the server-side token lasts about 24 hours
HASH_BLOCK = 65536


class OSError_(Exception):
    """Problem the user should read about (message is safe to show)."""


class OSAuthError(OSError_):
    pass


class OSLimit(OSError_):
    pass


def user_agent():
    try:
        version = utils.addon().getAddonInfo('version') or '1'
    except Exception:  # noqa: BLE001
        version = '1'
    return 'PremiumizeLibrary v%s' % version


# ----------------------------------------------------------------- file hash

def hash_from_blocks(size, head, tail):
    """OpenSubtitles hash: file size plus the 64-bit little-endian sums of the
    first and last 64 KiB."""
    if size < HASH_BLOCK * 2 or len(head) < HASH_BLOCK or len(tail) < HASH_BLOCK:
        return ''
    value = size
    for block in (head[:HASH_BLOCK], tail[-HASH_BLOCK:]):
        for (number,) in struct.iter_unpack('<q', block):
            value = (value + number) & 0xFFFFFFFFFFFFFFFF
    return '%016x' % value


def remote_hash(url, size, session=None, timeout=20):
    """Hash a file on an HTTP server with two ranged requests. '' on any problem."""
    if not url or not size or size < HASH_BLOCK * 2:
        return ''
    session = session or requests.Session()
    blocks = []
    try:
        for start in (0, size - HASH_BLOCK):
            resp = session.get(url, timeout=timeout, headers={
                'Range': 'bytes=%d-%d' % (start, start + HASH_BLOCK - 1),
                'User-Agent': user_agent()})
            if resp.status_code != 206 or len(resp.content) != HASH_BLOCK:
                return ''
            blocks.append(resp.content)
    except requests.RequestException:
        return ''
    return hash_from_blocks(size, blocks[0], blocks[1])


# ------------------------------------------------------------------- ranking

_WORD = re.compile(r'[a-z0-9]+')
_EXT = re.compile(r'\.[A-Za-z0-9]{2,4}$')
_NOISE = {'en', 'eng', 'english', 'sub', 'subs', 'srt', 'forced', 'sdh', 'hi', 'cc', 'the', 'a', 'and'}


def _tokens(text):
    return _WORD.findall((text or '').lower())


def name_similarity(video_name, subtitle_name):
    """0..1: how closely a subtitle's name matches the video file's name.

    Combines word overlap (release group, resolution, source and so on, in any order)
    with character-sequence similarity, ignoring words like 'english' or 'srt'.
    """
    a = [t for t in _tokens(_EXT.sub('', video_name or '')) if t not in _NOISE]
    b = [t for t in _tokens(_EXT.sub('', subtitle_name or '')) if t not in _NOISE]
    if not a or not b:
        return 0.0
    sa, sb = set(a), set(b)
    overlap = len(sa & sb) / float(len(sa | sb))
    sequence = difflib.SequenceMatcher(None, ' '.join(a), ' '.join(b)).ratio()
    return max(overlap, sequence)


def rank(results, file_name, prefer_hi=False):
    """Best first: a subtitle made for this exact file (hash match), then the closest
    name to the video file; trust, popularity and the hearing-impaired preference
    only break near-ties."""
    scored = []
    for item in results or []:
        a = item.get('attributes') or {}
        files = a.get('files') or []
        if not files or not files[0].get('file_id'):
            continue
        if a.get('ai_translated') or a.get('machine_translated'):
            continue
        if (a.get('language') or 'en').lower() not in ('en', 'eng'):
            continue
        similarity = max(name_similarity(file_name, a.get('release')),
                         name_similarity(file_name, files[0].get('file_name')))
        score = 0.0
        if a.get('moviehash_match'):
            score += 1000
        score += similarity * 100
        if a.get('from_trusted'):
            score += 2
        score += min(3.0, math.log10(1 + max(0, int(a.get('download_count') or 0))) / 2)
        if bool(a.get('hearing_impaired')) == bool(prefer_hi):
            score += 2
        if len(files) > 1:          # multi-CD subtitles do not fit a single file
            score -= 50
        scored.append((score, int(files[0]['file_id']), item))
    scored.sort(key=lambda s: s[0], reverse=True)
    return [(file_id, item) for _score, file_id, item in scored]


# -------------------------------------------------------------------- client

class OpenSubtitles(object):
    def __init__(self, api_key, username, password, session=None, sleeper=time.sleep):
        self.api_key = (api_key or '').strip()
        self.username = (username or '').strip()
        self.password = password or ''
        self.sleeper = sleeper
        self.session = session or requests.Session()
        self.session.headers.update({'Api-Key': self.api_key, 'User-Agent': user_agent(),
                                     'Accept': 'application/json'})
        self._token = None

    @property
    def configured(self):
        return bool(self.api_key and self.username and self.password)

    # ---------------------------------------------------------------- token
    def _load_token(self):
        data = utils.load_json(TOKEN_FILE, {})
        if data.get('user') == self.username and time.time() < data.get('expires', 0):
            return data.get('token')
        return None

    def _save_token(self, token):
        utils.save_json(TOKEN_FILE, {'user': self.username, 'token': token,
                                     'expires': time.time() + TOKEN_TTL})

    def token(self, force=False):
        if not force:
            self._token = self._token or self._load_token()
            if self._token:
                return self._token
        self._token = self.login()
        return self._token

    # ------------------------------------------------------------- requests
    def _request(self, method, path, auth=False, retry_auth=True, **kwargs):
        headers = kwargs.pop('headers', {})
        if auth:
            headers['Authorization'] = 'Bearer %s' % self.token()
        for attempt in range(3):
            try:
                resp = self.session.request(method, API_URL + path, headers=headers,
                                            timeout=TIMEOUT, **kwargs)
            except requests.RequestException:
                if attempt < 2:
                    self.sleeper(2 * (attempt + 1))
                    continue
                raise OSError_('Could not reach OpenSubtitles (the connection was dropped; '
                               'try again in a moment)')
            if resp.status_code == 429 and attempt < 2:
                try:
                    wait = float(resp.headers.get('Retry-After', '2'))
                except ValueError:
                    wait = 2
                self.sleeper(min(max(wait, 1), 10))
                continue
            if resp.status_code >= 500 and attempt < 2:
                self.sleeper(2)
                continue
            if resp.status_code == 401 and auth and retry_auth:
                headers['Authorization'] = 'Bearer %s' % self.token(force=True)
                retry_auth = False
                continue
            return resp
        return resp

    def login(self):
        if not self.configured:
            raise OSAuthError('Enter your OpenSubtitles username, password and API key first')
        resp = self._request('POST', 'login', json={'username': self.username,
                                                    'password': self.password})
        if resp.status_code == 400:
            raise OSAuthError('OpenSubtitles login failed: use your username, not your email')
        if resp.status_code in (401, 403):
            raise OSAuthError('OpenSubtitles rejected the username, password or API key')
        if resp.status_code == 429:
            raise OSLimit('OpenSubtitles is busy (too many requests); try again shortly')
        if resp.status_code >= 400:
            raise OSError_('OpenSubtitles login failed (HTTP %d)' % resp.status_code)
        try:
            token = resp.json()['token']
        except (ValueError, KeyError, TypeError):
            raise OSError_('Unexpected answer from OpenSubtitles')
        self._save_token(token)
        return token

    def user_info(self):
        resp = self._request('GET', 'infos/user', auth=True)
        if resp.status_code >= 400:
            raise OSError_('Could not read the OpenSubtitles account (HTTP %d)' % resp.status_code)
        try:
            return resp.json().get('data') or {}
        except ValueError:
            raise OSError_('Unexpected answer from OpenSubtitles')

    def search(self, **params):
        clean = {'languages': 'en', 'ai_translated': 'exclude', 'machine_translated': 'exclude'}
        for key, value in params.items():
            if value not in (None, ''):
                clean[key] = value.lower() if isinstance(value, str) else value
        resp = self._request('GET', 'subtitles', params=sorted(clean.items()))
        if resp.status_code in (401, 403):
            raise OSAuthError('OpenSubtitles rejected the API key')
        if resp.status_code >= 400:
            raise OSError_('OpenSubtitles search failed (HTTP %d)' % resp.status_code)
        try:
            data = resp.json().get('data')
        except ValueError:
            raise OSError_('Unexpected answer from OpenSubtitles')
        return data if isinstance(data, list) else []

    def download(self, file_id):
        """Returns (content_bytes, remaining_downloads_or_None)."""
        resp = self._request('POST', 'download', auth=True,
                             json={'file_id': int(file_id), 'sub_format': 'srt'})
        if resp.status_code == 406:
            raise OSLimit('OpenSubtitles daily download limit reached')
        if resp.status_code in (401, 403):
            raise OSAuthError('OpenSubtitles rejected the login')
        if resp.status_code >= 400:
            raise OSError_('OpenSubtitles download failed (HTTP %d)' % resp.status_code)
        try:
            body = resp.json()
            link = body['link']
        except (ValueError, KeyError, TypeError):
            raise OSError_('Unexpected answer from OpenSubtitles')
        if not isinstance(link, str) or not link.startswith(('http://', 'https://')):
            raise OSError_('Unexpected answer from OpenSubtitles')
        for attempt in range(3):            # dropped connections are common on some networks
            try:
                res = requests.get(link, timeout=TIMEOUT, headers={'User-Agent': user_agent()})
            except requests.RequestException:
                if attempt < 2:
                    self.sleeper(2 * (attempt + 1))
                    continue
                raise OSError_('Could not fetch the subtitle file (connection dropped)')
            if res.status_code >= 500 and attempt < 2:
                self.sleeper(2 * (attempt + 1))
                continue
            if res.status_code >= 400 or not res.content:
                raise OSError_('Could not fetch the subtitle file (HTTP %d)' % res.status_code)
            return res.content, body.get('remaining')
