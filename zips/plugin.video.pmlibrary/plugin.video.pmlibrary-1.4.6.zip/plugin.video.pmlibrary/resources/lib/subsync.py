# -*- coding: utf-8 -*-
"""Re-time a subtitle file from moments the viewer marks while watching.

Each sync point pairs a line's time in the original file with the moment it was
actually heard. One point shifts the whole file; two points far enough apart also
correct a speed difference (for example a 25 fps subtitle on a 23.976 fps video).
"""
import re

_TIME = re.compile(r'(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})')
_ARROW = re.compile(r'^\s*(\S+)\s*-->\s*(\S+)')
_TAGS = re.compile(r'<[^>]+>|\{[^}]*\}')
MIN_SPREAD = 300.0      # seconds between two points before speed is corrected
REACTION = 0.3          # seconds people typically take to press after hearing a line


def decode(data):
    if isinstance(data, str):
        return data
    for enc in ('utf-8-sig', 'utf-16') if data[:2] in (b'\xff\xfe', b'\xfe\xff') else ('utf-8-sig',):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            pass
    return data.decode('cp1252', errors='replace')


def _seconds(stamp):
    m = _TIME.match(stamp.strip())
    if not m:
        raise ValueError(stamp)
    h, mi, s, ms = m.groups()
    return int(h) * 3600 + int(mi) * 60 + int(s) + int(ms.ljust(3, '0')) / 1000.0


def _stamp(seconds):
    total = max(0, int(round(seconds * 1000)))
    h, rest = divmod(total, 3600000)
    m, rest = divmod(rest, 60000)
    s, ms = divmod(rest, 1000)
    return '%02d:%02d:%02d,%03d' % (h, m, s, ms)


def parse_srt(text):
    """List of (start, end, text) cues. Tolerates missing numbers, CRLF and stray blank lines."""
    text = decode(text).replace('\r\n', '\n').replace('\r', '\n')
    cues = []
    lines = text.split('\n')
    i = 0
    while i < len(lines):
        m = _ARROW.match(lines[i])
        if not m:
            i += 1
            continue
        try:
            start, end = _seconds(m.group(1)), _seconds(m.group(2))
        except ValueError:
            i += 1
            continue
        i += 1
        body = []
        while i < len(lines) and lines[i].strip() and not _ARROW.match(lines[i]):
            body.append(lines[i])
            i += 1
        # a bare cue number directly before the next timing line is not text
        if body and body[-1].strip().isdigit() and i < len(lines) and _ARROW.match(lines[i]):
            body.pop()
        cues.append((start, end, '\n'.join(body).strip()))
    return cues


def format_srt(cues):
    out = []
    for n, (start, end, text) in enumerate(cues, 1):
        out.append('%d\n%s --> %s\n%s\n' % (n, _stamp(start), _stamp(end), text))
    return '\n'.join(out)


def plain(text):
    return re.sub(r'\s+', ' ', _TAGS.sub('', text or '')).strip()


def fit(points):
    """Mapping (scale, offset) so that heard = scale * original + offset.

    One point (or points close together) gives a pure shift from the latest point;
    points spread over at least MIN_SPREAD seconds give a least-squares line.
    """
    if not points:
        return 1.0, 0.0
    xs = [p[0] for p in points]
    if max(xs) - min(xs) < MIN_SPREAD:
        orig, heard = points[-1]
        return 1.0, heard - orig
    n = float(len(points))
    mx = sum(xs) / n
    my = sum(p[1] for p in points) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    sxy = sum((p[0] - mx) * (p[1] - my) for p in points)
    scale = sxy / sxx
    if not 0.9 < scale < 1.1:          # implausible: fall back to a shift
        orig, heard = points[-1]
        return 1.0, heard - orig
    return scale, my - scale * mx


def mapped(cues, mapping):
    """Same cues with mapped times, nothing dropped (keeps positions for display)."""
    scale, offset = mapping
    return [(scale * s + offset, scale * e + offset, t) for s, e, t in cues]


def apply(cues, mapping):
    scale, offset = mapping
    out = []
    for start, end, text in cues:
        s, e = scale * start + offset, scale * end + offset
        if e <= 0:
            continue                      # moved before the start of the video
        out.append((max(0.0, s), e, text))
    return out


def describe(mapping):
    scale, offset = mapping
    if abs(scale - 1.0) > 0.0005:
        return 'Timing and speed corrected'
    if abs(offset) < 0.05:
        return 'Timing unchanged'
    return 'Subtitles moved %.1f s %s' % (abs(offset), 'later' if offset > 0 else 'earlier')
