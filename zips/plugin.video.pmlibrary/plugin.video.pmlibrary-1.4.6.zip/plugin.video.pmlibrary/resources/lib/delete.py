# -*- coding: utf-8 -*-
"""Delete a movie, episode or whole TV show from the Premiumize cloud (long-press menu).

Always asks first. Removes the video files, the subtitles found next to them, and the
cloud folder they came in when nothing worth keeping is left in it (another real video
or a subfolder keeps the folder). Folders left completely empty above it go too, never
the cloud root. Then removes the items from the Kodi library.
"""
import xbmc
import xbmcgui

from . import net, parser, premiumize, sync, utils

HEADING = 'Premiumize Library'
RUNNING = 'pmlib.running'
MAX_LISTED = 6
MAX_CLIMB = 4


def _rel(engine, path):
    """Path relative to the library folder, or None when it lies outside it."""
    root = engine.root.replace('\\', '/').rstrip('/') + '/'
    real = utils.translate(path or '').replace('\\', '/')
    return real[len(root):] if real.startswith(root) else None


def _label(title, year):
    return '%s (%s)' % (title, year) if year else (title or 'this item')


def from_library(engine, dbtype, dbid):
    """(label, [cloud file ids]) for a Kodi library movie, episode or TV show."""
    ids = []
    if dbtype == 'movie':
        d = utils.jsonrpc('VideoLibrary.GetMovieDetails',
                          {'movieid': dbid, 'properties': ['file', 'title', 'year']}).get('moviedetails') or {}
        rel = _rel(engine, d.get('file'))
        ids = [fid for fid, e in engine.files.items() if rel and e.get('strm') == rel]
        return _label(d.get('title'), d.get('year')), ids
    if dbtype == 'episode':
        d = utils.jsonrpc('VideoLibrary.GetEpisodeDetails',
                          {'episodeid': dbid,
                           'properties': ['file', 'showtitle', 'season', 'episode']}).get('episodedetails') or {}
        rel = _rel(engine, d.get('file'))
        ids = [fid for fid, e in engine.files.items() if rel and e.get('strm') == rel]
        return '%s S%02dE%02d' % (d.get('showtitle') or '', d.get('season') or 0, d.get('episode') or 0), ids
    if dbtype == 'tvshow':
        d = utils.jsonrpc('VideoLibrary.GetTVShowDetails',
                          {'tvshowid': dbid, 'properties': ['file', 'title', 'year']}).get('tvshowdetails') or {}
        rel = _rel(engine, d.get('file'))
        if rel:
            folder = rel.rstrip('/') + '/'
            ids = [fid for fid, e in engine.files.items() if (e.get('strm') or '').startswith(folder)]
        return _label(d.get('title'), d.get('year')), ids
    return None, []


def _keeps_folder(item, doomed):
    """True for a cloud entry worth keeping, so the folder holding it must stay."""
    if item.get('type') == 'folder':
        return True
    if str(item.get('id')) in doomed:
        return False
    name = item.get('name') or ''
    if not parser.is_video(name, item.get('mime_type', '')):
        return False          # .srt, .nfo, .txt, .jpg ... left over from the download
    try:
        size = int(item.get('size') or 0)
    except (TypeError, ValueError):
        size = 0
    return not parser.is_junk(name, [], size)   # a sample clip is not worth keeping


def plan(pm, fids, entries):
    """Work out what to delete.

    Returns dict: folders {folder id: {'name', 'fids', 'parent'}}, files {file id: name}
    (for videos whose folder stays, plus their subtitles), video_files {file id: name}
    (the videos among files), root (cloud root folder id or '').
    """
    try:
        root = str(pm.list_folder(None).get('folder_id') or '')
    except premiumize.PremiumizeError:
        root = ''
    by_folder, files, videos = {}, {}, {}
    for fid in fids:
        try:
            folder_id = str(pm.details(fid).get('folder_id') or '')
        except premiumize.PremiumizeError:
            folder_id = ''
        if folder_id and root and folder_id != root:
            by_folder.setdefault(folder_id, []).append(fid)
        else:
            videos[fid] = entries.get(fid, {}).get('name') or fid

    folders = {}
    for folder_id, ids in by_folder.items():
        doomed = set(ids)
        for fid in ids:
            doomed.update(str(s['id']) for s in entries.get(fid, {}).get('subs') or [])
        try:
            listing = pm.list_folder(folder_id)
        except premiumize.PremiumizeError:
            listing = None
        if listing is not None and not any(_keeps_folder(i, doomed) for i in listing.get('content') or []):
            folders[folder_id] = {'name': listing.get('name') or folder_id, 'fids': ids,
                                  'parent': str(listing.get('parent_id') or '')}
        else:
            for fid in ids:
                videos[fid] = entries.get(fid, {}).get('name') or fid
    files = dict(videos)
    for fid in videos:   # subtitles go with their video when the folder stays
        for sub in entries.get(fid, {}).get('subs') or []:
            files[str(sub['id'])] = sub.get('name') or str(sub['id'])
    return {'folders': folders, 'files': files, 'videos': videos, 'root': root}


def confirm(label, count, the_plan):
    names = ['%s (folder)' % f['name'] for f in the_plan['folders'].values()]
    names += list(the_plan['videos'].values())
    shown = '\n'.join('  ' + n for n in names[:MAX_LISTED])
    if len(names) > MAX_LISTED:
        shown += '\n  ... and %d more' % (len(names) - MAX_LISTED)
    text = ('Delete "%s" from your Premiumize cloud?\n\n'
            '%d video file%s will be deleted:\n%s\n\nThis cannot be undone.'
            % (label, count, '' if count == 1 else 's', shown))
    dialog = xbmcgui.Dialog()
    try:
        return bool(dialog.yesno(HEADING, text, nolabel='Cancel', yeslabel='Delete',
                                 defaultbutton=xbmcgui.DLG_YESNO_NO_BTN))
    except (TypeError, AttributeError):   # Kodi 19 has no defaultbutton
        return bool(dialog.yesno(HEADING, text, nolabel='Cancel', yeslabel='Delete'))


def execute(pm, the_plan):
    """Delete what the plan lists. Returns (gone file ids, number of failures)."""
    gone, failed, removed_folders = set(), 0, set()
    for folder_id, info in the_plan['folders'].items():
        try:
            pm.delete_folder(folder_id)
            removed_folders.add(folder_id)
            gone.update(info['fids'])
        except (premiumize.PremiumizeError, net.NetError) as exc:
            failed += 1
            utils.log('Could not delete a cloud folder: %s' % exc, xbmc.LOGWARNING)
    for file_id in the_plan['files']:
        try:
            pm.delete_item(file_id)
            gone.add(file_id)
        except (premiumize.PremiumizeError, net.NetError) as exc:
            failed += 1
            utils.log('Could not delete a cloud file: %s' % exc, xbmc.LOGWARNING)

    # Parents left completely empty (e.g. the show folder after its season folders went).
    root = the_plan['root']
    todo = {info['parent'] for fid, info in the_plan['folders'].items() if fid in removed_folders}
    for _ in range(MAX_CLIMB):
        nxt = set()
        for folder_id in todo:
            if not folder_id or not root or folder_id == root:
                continue
            try:
                listing = pm.list_folder(folder_id)
                if listing.get('content'):
                    continue
                pm.delete_folder(folder_id)
                nxt.add(str(listing.get('parent_id') or ''))
            except (premiumize.PremiumizeError, net.NetError) as exc:
                utils.log('Left an empty cloud folder in place: %s' % exc, xbmc.LOGWARNING)
        todo = nxt
        if not todo:
            break
    return gone, failed


def delete(label, fids):
    """Ask, then delete the given cloud video files and tidy the Kodi library."""
    dialog = xbmcgui.Dialog()
    win = utils.home_window()
    if win.getProperty(RUNNING) == '1':
        dialog.ok(HEADING, 'A sync is running. Try again when it has finished.')
        return False
    key = utils.setting('pm_api_key').strip()
    if not key:
        dialog.ok(HEADING, 'Enter your Premiumize API key in the add-on settings first.')
        return False
    if not fids:
        dialog.ok(HEADING, 'This item was not found in your Premiumize cloud list. '
                           'Run "Sync library now" and try again.')
        return False
    pm = premiumize.Premiumize(key)
    engine = sync.SyncEngine()
    engine.load()

    win.setProperty(RUNNING, '1')   # no sync may start while we work
    try:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        try:
            the_plan = plan(pm, fids, engine.files)
        finally:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        if not confirm(label, len(fids), the_plan):
            return False
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        try:
            gone, failed = execute(pm, the_plan)
            engine.drop_entries([fid for fid in fids if fid in gone])
            engine.save()
            engine._scoped_clean()
        finally:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    except premiumize.AuthError:
        dialog.ok(HEADING, 'Premiumize rejected the API key. Check it in the settings.')
        return False
    except (premiumize.PremiumizeError, net.NetError) as exc:
        dialog.ok(HEADING, 'Nothing was deleted: %s' % exc)
        return False
    finally:
        win.clearProperty(RUNNING)

    if failed:
        dialog.ok(HEADING, 'Some parts could not be deleted. Check your Premiumize cloud; '
                           'the next sync tidies the library.')
    else:
        utils.notify('Deleted "%s" from Premiumize.' % label)
    xbmc.executebuiltin('Container.Refresh')
    return True
