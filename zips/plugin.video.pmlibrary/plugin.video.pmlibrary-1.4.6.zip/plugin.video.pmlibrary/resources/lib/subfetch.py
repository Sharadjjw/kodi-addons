# -*- coding: utf-8 -*-
"""Fetch English subtitles for a playing library item that has none.

main.py's play action leaves a note in a window property; the background service
picks it up, waits for Kodi to open the video, looks at the subtitle tracks Kodi
found (embedded and external) and, when no English track exists, fetches one from
OpenSubtitles.com, loads it into the player and keeps a copy for next time.
"""
import json
import os
import re
import time

import xbmc

from . import opensubs, sync, utils

PLAY_PROP = 'pmlib.play'
STATE_FILE = 'subs_state.json'
CACHE_DIR = 'subtitles'
NOT_FOUND_RETRY = 3 * 24 * 3600
WAIT_FOR_PLAYER = 60
SETTLE_SECONDS = 3
ENGLISH = ('en', 'eng', 'english')


# ----------------------------------------------------------------- the note

def leave_note(file_id, has_subtitles):
    """Called by the play action just before Kodi starts the video."""
    utils.home_window().setProperty(PLAY_PROP, json.dumps(
        {'id': file_id, 't': time.time(), 'has': bool(has_subtitles)}))


def take_note():
    win = utils.home_window()
    raw = win.getProperty(PLAY_PROP)
    if not raw:
        return None
    win.clearProperty(PLAY_PROP)
    try:
        note = json.loads(raw)
    except ValueError:
        return None
    if time.time() - note.get('t', 0) > WAIT_FOR_PLAYER:
        return None
    return note


# ------------------------------------------------------------- local cache

def cache_dir():
    path = os.path.join(utils.profile_dir(), CACHE_DIR)
    os.makedirs(path, exist_ok=True)
    return path


def cached_file(file_id):
    """Path of a previously fetched subtitle, or None. Named *.en.srt so Kodi labels it English."""
    safe = re.sub(r'[^A-Za-z0-9_-]', '_', str(file_id))
    path = os.path.join(cache_dir(), '%s.en.srt' % safe)
    return path if os.path.isfile(path) and os.path.getsize(path) > 0 else None


def _cache_path(file_id):
    safe = re.sub(r'[^A-Za-z0-9_-]', '_', str(file_id))
    return os.path.join(cache_dir(), '%s.en.srt' % safe)


# ------------------------------------------------------------ Kodi player

def _video_player_id():
    for player in utils.jsonrpc('Player.GetActivePlayers') or []:
        if isinstance(player, dict) and player.get('type') == 'video':
            return player.get('playerid')
    return None


def wait_for_video(monitor, timeout=WAIT_FOR_PLAYER):
    """Player id once a video is playing (and its streams are known), else None."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        pid = _video_player_id()
        if pid is not None:
            props = utils.jsonrpc('Player.GetProperties', {'playerid': pid, 'properties': ['time']})
            t = props.get('time') or {}
            if any(t.get(k) for k in ('hours', 'minutes', 'seconds', 'milliseconds')):
                if monitor.waitForAbort(SETTLE_SECONDS):
                    return None
                return pid
        if monitor.waitForAbort(1):
            return None
    return None


def has_english(player_id):
    props = utils.jsonrpc('Player.GetProperties', {'playerid': player_id, 'properties': ['subtitles']})
    for sub in props.get('subtitles') or []:
        lang = (sub.get('language') or '').strip().lower()
        name = (sub.get('name') or '').strip().lower()
        if sub.get('isforced') or 'forced' in name:
            continue
        if lang in ENGLISH or lang.startswith('en-') or re.search(r'\benglish\b', name):
            return True
    return False


# --------------------------------------------------------------- searching

def _digits(value):
    m = re.search(r'(\d+)', str(value or ''))
    return int(m.group(1)) if m else None


def search_params(entry):
    """Search attempts for an index entry, most precise first."""
    ids = entry.get('ids') or {}
    imdb, tmdb = _digits(ids.get('imdb')), _digits(ids.get('tmdb'))
    attempts = []
    if entry.get('kind') == 'episode':
        base = {'type': 'episode', 'season_number': entry.get('season'),
                'episode_number': (entry.get('episodes') or [None])[0]}
        if imdb:
            attempts.append(dict(base, parent_imdb_id=imdb))
        if tmdb:
            attempts.append(dict(base, parent_tmdb_id=tmdb))
        if entry.get('title'):
            attempts.append(dict(base, query=entry['title']))
    else:
        if imdb:
            attempts.append({'type': 'movie', 'imdb_id': imdb})
        if tmdb:
            attempts.append({'type': 'movie', 'tmdb_id': tmdb})
        if entry.get('title'):
            q = {'type': 'movie', 'query': entry['title']}
            if entry.get('year'):
                q['year'] = entry['year']
            attempts.append(q)
    return attempts


def find_and_download(client, entry, moviehash, prefer_hi):
    """Returns (bytes, remaining) or (None, None) when nothing suitable exists."""
    for params in search_params(entry):
        tries = [dict(params, moviehash=moviehash), params] if moviehash else [params]
        for p in tries:
            results = client.search(**p)
            ranked = opensubs.rank(results, entry.get('name'), prefer_hi)
            shown = ', '.join('%s=%s' % (k, v) for k, v in sorted(p.items())
                              if k in ('type', 'imdb_id', 'tmdb_id', 'parent_imdb_id', 'parent_tmdb_id',
                                       'season_number', 'episode_number', 'year')
                              or (k == 'query') or (k == 'moviehash' and v))
            utils.log('Subtitle search (%s): %d results, %d usable' % (shown, len(results or []), len(ranked)))
            if ranked:
                file_id, _item = ranked[0]
                return client.download(file_id)
    return None, None


# --------------------------------------------------------------- main step

def _notify(message, error=False):
    if error or utils.setting_bool('os_notify', True):
        import xbmcgui
        utils.notify(message, icon=xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO)


def _load(player, path, show):
    player.setSubtitles(path)
    player.showSubtitles(bool(show))


def handle(note, monitor, player=None, client=None):
    """Process one play note. Returns a short status string (used by tests and the log)."""
    if not utils.setting_bool('os_enabled', False):
        return 'disabled'
    if note.get('has'):
        return 'has subtitle file'
    file_id = note.get('id')
    entry = ((utils.load_json(sync.INDEX_FILE, {}).get('files')) or {}).get(file_id)
    if not entry:
        return 'not in library'
    pid = wait_for_video(monitor)
    if pid is None:
        return 'no video playing'
    if has_english(pid):
        return 'english present'

    player = player or xbmc.Player()
    show = utils.setting_bool('os_show', True)
    cached = cached_file(file_id)
    if cached:
        _load(player, cached, show)
        return 'loaded cached'

    state = utils.load_json(STATE_FILE, {})
    last_miss = (state.get('missing') or {}).get(file_id, 0)
    if time.time() - last_miss < NOT_FOUND_RETRY:
        hours = max(1, int((time.time() - last_miss) / 3600))
        _notify('No English subtitles on OpenSubtitles for this (checked %d hour%s ago)'
                % (hours, '' if hours == 1 else 's'))
        return 'recently not found'

    client = client or opensubs.OpenSubtitles(utils.setting('os_api_key'), utils.setting('os_username'),
                                              utils.setting('os_password'),
                                              sleeper=lambda s: monitor.waitForAbort(s))
    if not client.configured:
        _notify('Subtitles: enter your OpenSubtitles details in the add-on settings', error=True)
        return 'not configured'

    moviehash = ''
    try:
        playing = player.getPlayingFile()
    except RuntimeError:
        playing = ''
    if playing.startswith('http') and entry.get('size'):
        moviehash = opensubs.remote_hash(playing, entry['size'])

    try:
        content, remaining = find_and_download(client, entry, moviehash,
                                               utils.setting_bool('os_hearing_impaired', False))
    except opensubs.OSLimit as exc:
        _notify(str(exc), error=True)
        return 'limit'
    except opensubs.OSError_ as exc:
        _notify('Subtitles: %s' % exc, error=True)
        return 'error'

    if not content:
        state.setdefault('missing', {})[file_id] = time.time()
        utils.save_json(STATE_FILE, state)
        _notify('No English subtitles found on OpenSubtitles')
        return 'not found'

    path = _cache_path(file_id)
    with open(path, 'wb') as handle_:
        handle_.write(content)
    if (state.get('missing') or {}).pop(file_id, None):
        utils.save_json(STATE_FILE, state)
    try:
        if not player.isPlayingVideo():
            return 'saved (playback stopped)'
    except RuntimeError:
        return 'saved (playback stopped)'
    _load(player, path, show)
    extra = ' (%s downloads left today)' % remaining if remaining is not None else ''
    utils.log('Fetched English subtitles from OpenSubtitles%s' % extra)
    _notify('English subtitles added from OpenSubtitles')
    return 'fetched'


def forget_failed_searches():
    state = utils.load_json(STATE_FILE, {})
    count = len(state.get('missing') or {})
    state['missing'] = {}
    utils.save_json(STATE_FILE, state)
    return count


def worker(monitor):
    """Background loop run by the service in its own thread."""
    while not monitor.abortRequested():
        note = take_note()
        if note:
            try:
                status = handle(note, monitor)
                utils.log('Subtitles: %s' % status)
            except Exception as exc:  # noqa: BLE001 - never let the thread die
                utils.log('Subtitle fetch failed: %s' % type(exc).__name__, xbmc.LOGWARNING)
        if monitor.waitForAbort(1):
            break
