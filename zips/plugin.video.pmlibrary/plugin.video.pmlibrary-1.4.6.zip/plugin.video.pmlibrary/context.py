# -*- coding: utf-8 -*-
"""Long-press menu in the Kodi library: Delete from Premiumize."""
import sys

import xbmc

from resources.lib import delete, sync


def _info():
    dbtype, dbid = '', 0
    item = getattr(sys, 'listitem', None)
    if item is not None:
        try:
            tag = item.getVideoInfoTag()
            dbtype, dbid = tag.getMediaType(), tag.getDbId()
        except Exception:  # noqa: BLE001 - older Kodi
            pass
    if not dbtype or not dbid or dbid < 0:
        dbtype = xbmc.getInfoLabel('ListItem.DBTYPE')
        try:
            dbid = int(xbmc.getInfoLabel('ListItem.DBID') or 0)
        except ValueError:
            dbid = 0
    return dbtype, dbid


def main():
    dbtype, dbid = _info()
    if dbtype not in ('movie', 'episode', 'tvshow') or dbid <= 0:
        return
    engine = sync.SyncEngine()
    engine.load()
    label, fids = delete.from_library(engine, dbtype, dbid)
    delete.delete(label or 'this item', fids)


if __name__ == '__main__':
    main()
