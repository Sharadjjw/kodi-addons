# -*- coding: utf-8 -*-
"""Installs a small Kodi keymap: on the Home screen, Back jumps to the left menu (Estuary)."""
import xbmc
import xbmcvfs

from resources.lib import utils

KEYMAP_DIR = 'special://masterprofile/keymaps/'
KEYMAP_FILE = KEYMAP_DIR + 'pmlibrary_homeback.xml'
CONTENT = ('<keymap>\n'
           '  <Home>\n'
           '    <keyboard>\n'
           '      <backspace>Control.SetFocus(9000)</backspace>\n'
           '    </keyboard>\n'
           '  </Home>\n'
           '</keymap>\n')


def install():
    """Write the keymap if it is missing or different, then ask Kodi to reload its keymaps."""
    try:
        folder = xbmcvfs.translatePath(KEYMAP_DIR)
        path = xbmcvfs.translatePath(KEYMAP_FILE)
        current = None
        if xbmcvfs.exists(path):
            with xbmcvfs.File(path) as handle:
                current = handle.read()
        if current == CONTENT:
            return False
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
        with xbmcvfs.File(path, 'w') as handle:
            handle.write(CONTENT)
        xbmc.executebuiltin('Action(reloadkeymaps)')
        utils.log('Installed the Home screen Back keymap')
        return True
    except Exception as exc:  # noqa: BLE001 - never stop the service for this
        utils.log('Could not install the Home screen Back keymap: %s' % exc, xbmc.LOGWARNING)
        return False
