# -*- coding: utf-8 -*-
"""Small HTTP helper shared by the Premiumize, TMDb and OMDb clients.

Error messages never include the request URL, because URLs carry API keys.
"""
import time

import requests

USER_AGENT = 'plugin.video.pmlibrary/1.0'

_session = None


class NetError(Exception):
    """Network failure or unusable HTTP response (message is safe to log)."""

    def __init__(self, message, status=None):
        Exception.__init__(self, message)
        self.status = status


class Aborted(Exception):
    """Raised when Kodi is shutting down or the user cancelled."""


def _get_session():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update({'User-Agent': USER_AGENT})
    return _session


def get_bytes(url, timeout=30, attempts=3, sleeper=time.sleep):
    """Body of a plain GET (with retries on dropped connections), or None."""
    for attempt in range(attempts):
        try:
            resp = _get_session().get(url, timeout=timeout)
            if resp.status_code < 400:
                return resp.content
            if resp.status_code < 500:
                return None
        except requests.RequestException:
            pass
        if attempt < attempts - 1:
            sleeper(2 * (attempt + 1))
    return None


def url_ok(url, timeout=8):
    """True when the server answers a one-byte ranged GET for url with success."""
    try:
        resp = _get_session().get(url, headers={'Range': 'bytes=0-0'}, stream=True,
                                  timeout=timeout, allow_redirects=True)
        try:
            return resp.status_code in (200, 206)
        finally:
            resp.close()
    except requests.RequestException:
        return False


def get_json(url, params=None, headers=None, timeout=30, retries=3,
             sleeper=time.sleep, abort=None):
    """GET url and return (http_status, parsed_json_or_None).

    Retries network errors, HTTP 429 and 5xx with backoff. Other HTTP errors
    are returned to the caller together with any JSON body, because the APIs
    used here report problems (bad key, rate limit) in the body.
    """
    last = None
    for attempt in range(retries + 1):
        if abort and abort():
            raise Aborted()
        try:
            resp = _get_session().get(url, params=params, headers=headers, timeout=timeout)
        except (requests.ConnectionError, requests.Timeout) as exc:
            last = NetError('Network error (%s)' % type(exc).__name__)
            if attempt < retries:
                sleeper(min(2 ** attempt, 8))
                continue
            raise last
        except requests.RequestException as exc:
            raise NetError('Request failed (%s)' % type(exc).__name__)

        if resp.status_code == 429 or resp.status_code >= 500:
            last = NetError('HTTP %d from server' % resp.status_code, resp.status_code)
            if attempt < retries:
                try:
                    wait = float(resp.headers.get('Retry-After', ''))
                except ValueError:
                    wait = 2 ** attempt
                sleeper(max(1, min(wait, 30)))
                continue
            raise last

        try:
            payload = resp.json()
        except ValueError:
            payload = None
        if resp.status_code >= 400 and payload is None:
            raise NetError('HTTP %d from server' % resp.status_code, resp.status_code)
        return resp.status_code, payload
    raise last or NetError('Request failed')
