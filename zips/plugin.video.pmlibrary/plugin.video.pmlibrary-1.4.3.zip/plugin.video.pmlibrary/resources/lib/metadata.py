# -*- coding: utf-8 -*-
"""TMDb (artwork, details, TMDb ratings) and OMDb (IMDb ratings) lookups."""
import time
from difflib import SequenceMatcher

from . import net, parser

TMDB_BASE = 'https://api.themoviedb.org/3'
OMDB_BASE = 'https://www.omdbapi.com/'
IMG_POSTER = 'https://image.tmdb.org/t/p/w500'
IMG_FANART = 'https://image.tmdb.org/t/p/w1280'
IMG_STILL = 'https://image.tmdb.org/t/p/w780'
IMG_PROFILE = 'https://image.tmdb.org/t/p/w185'
CACHE_TTL = 30 * 24 * 3600
NEGATIVE_TTL = 24 * 3600   # "nothing found" answers are retried after a day
MISS = object()


def _is_negative(value):
    return value is None or value == [] or value == {}


class TmdbError(Exception):
    pass


class TmdbAuthError(TmdbError):
    pass


class OmdbError(Exception):
    pass


class OmdbLimit(OmdbError):
    pass


class OmdbAuthError(OmdbError):
    pass


class Cache(object):
    """Key/value cache with expiry; optionally persisted through loader/saver."""

    def __init__(self, loader=None, saver=None, ttl=CACHE_TTL):
        self.ttl = ttl
        self.saver = saver
        self.dirty = False
        self.data = loader() if loader else {}
        if not isinstance(self.data, dict):
            self.data = {}
        now = time.time()
        stale = [k for k, e in self.data.items()
                 if not isinstance(e, dict) or now - e.get('t', 0) >= ttl]
        for key in stale:
            del self.data[key]
        if stale:
            self.dirty = True

    def get(self, key):
        entry = self.data.get(key)
        if entry is None:
            return MISS
        age = time.time() - entry['t']
        ttl = NEGATIVE_TTL if _is_negative(entry['v']) else self.ttl
        return entry['v'] if age < ttl else MISS

    def purge_negative(self):
        """Forget every cached "nothing found" answer. Returns how many were removed."""
        keys = [k for k, e in self.data.items() if _is_negative(e.get('v'))]
        for key in keys:
            del self.data[key]
        if keys:
            self.dirty = True
        return len(keys)

    def set(self, key, value):
        self.data[key] = {'t': int(time.time()), 'v': value}
        self.dirty = True

    def flush(self):
        if self.dirty and self.saver:
            self.saver(self.data)
            self.dirty = False


def _year(date):
    return int(date[:4]) if date and date[:4].isdigit() else None


def _to_float(text):
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def _to_int(text):
    try:
        return int(str(text).replace(',', ''))
    except (TypeError, ValueError):
        return None


class Metadata(object):
    def __init__(self, tmdb_key, omdb_key, language='en-US', cache=None,
                 defer_on_limit=True, episode_ratings=False,
                 sleeper=time.sleep, abort=None):
        self.tmdb_key = (tmdb_key or '').strip()
        self.omdb_key = (omdb_key or '').strip()
        self.language = language or 'en-US'
        self.cache = cache or Cache()
        self.defer_on_limit = defer_on_limit
        self.episode_ratings = episode_ratings
        self.sleeper = sleeper
        self.abort = abort
        self.omdb_blocked = False

    @property
    def enabled(self):
        return bool(self.tmdb_key)

    # ------------------------------------------------------------------ TMDb

    def _tmdb(self, path, **params):
        headers = {}
        if self.tmdb_key.startswith('eyJ'):  # v4 read access token (JWT)
            headers['Authorization'] = 'Bearer %s' % self.tmdb_key
        else:
            params['api_key'] = self.tmdb_key
        params.setdefault('language', self.language)
        try:
            status, data = net.get_json(TMDB_BASE + path, params=params, headers=headers,
                                        sleeper=self.sleeper, abort=self.abort)
        except net.NetError as exc:
            raise TmdbError(str(exc))
        if status == 401:
            raise TmdbAuthError('TMDb rejected the API key')
        if status == 404:
            return None
        if status >= 400 or not isinstance(data, dict):
            raise TmdbError('TMDb returned HTTP %s' % status)
        return data

    def _search(self, kind, query, year=None):
        key = 'tmdb|search|%s|%s|%s|%s' % (kind, self.language, query.lower(), year or '')
        cached = self.cache.get(key)
        if cached is not MISS:
            return cached
        params = {'query': query, 'include_adult': 'false'}
        if year:
            params['year' if kind == 'movie' else 'first_air_date_year'] = year
        data = self._tmdb('/search/' + kind, **params) or {}
        results = []
        for r in (data.get('results') or [])[:10]:
            if kind == 'movie':
                title, original, date = r.get('title'), r.get('original_title'), r.get('release_date')
            else:
                title, original, date = r.get('name'), r.get('original_name'), r.get('first_air_date')
            results.append({'id': r.get('id'), 'title': title or '', 'original_title': original or '',
                            'date': date or '', 'popularity': r.get('popularity') or 0,
                            'overview': r.get('overview') or ''})
        self.cache.set(key, results)
        return results

    @staticmethod
    def _pick(results, title, year):
        target = parser.normalize(title)
        if not target:
            return None
        best = None
        for r in results:
            norms = [parser.normalize(n) for n in (r['title'], r['original_title']) if n]
            if not norms:
                continue
            sim = max(SequenceMatcher(None, target, n).ratio() for n in norms)
            exact = target in norms
            if not (exact or sim >= 0.6):
                continue
            ry = _year(r['date'])
            gap = abs(ry - year) if (year and ry) else None
            score = sim * 10 + (5 if exact else 0)
            if gap is not None:
                score += 4 if gap == 0 else (2 if gap == 1 else -3)
            cand = {'result': r, 'exact': exact, 'year_ok': gap is not None and gap <= 1,
                    'score': (score, r['popularity'])}
            if best is None or cand['score'] > best['score']:
                best = cand
        return best

    def _find(self, kind, title, year, alt):
        pick = self._pick(self._search(kind, title, year), title, year)
        if pick and pick['exact'] and (not year or pick['year_ok']):
            return pick['result']
        if alt:  # the "year" may really be part of the title, e.g. "Wonder Woman 1984"
            alt_pick = self._pick(self._search(kind, alt, None), alt, None)
            if alt_pick and alt_pick['exact']:
                return alt_pick['result']
        if pick:
            return pick['result']
        if year:
            loose = self._pick(self._search(kind, title, None), title, year)
            if loose:
                return loose['result']
        return None

    def search_candidates(self, kind, query):
        """For the manual match dialog: list of {id, label, overview}."""
        out = []
        for r in self._search(kind, query, None):
            year = _year(r['date'])
            label = '%s (%s)' % (r['title'], year) if year else r['title']
            out.append({'id': r['id'], 'label': label, 'overview': r['overview']})
        return out

    @staticmethod
    def _cast(details):
        cast = []
        for person in ((details.get('credits') or {}).get('cast') or [])[:15]:
            cast.append({'name': person.get('name'), 'role': person.get('character'),
                         'order': person.get('order'),
                         'thumb': IMG_PROFILE + person['profile_path'] if person.get('profile_path') else None})
        return cast

    @staticmethod
    def _tmdb_rating(details):
        votes = details.get('vote_count') or 0
        value = details.get('vote_average') or 0
        return {'value': round(float(value), 1), 'votes': votes} if votes else None

    def _movie_cached(self, tmdb_id):
        key = 'tmdb|movie|%s|%s' % (self.language, tmdb_id)
        cached = self.cache.get(key)
        if cached is not MISS:
            return cached
        d = self._tmdb('/movie/%d' % tmdb_id, append_to_response='external_ids,credits')
        if d is None:
            self.cache.set(key, None)
            return None
        crew = (d.get('credits') or {}).get('crew') or []
        writers = []
        for c in crew:
            if c.get('job') in ('Writer', 'Screenplay', 'Story') and c.get('name') not in writers:
                writers.append(c['name'])
        title = d.get('title') or ''
        meta = {
            'kind': 'movie', 'tmdb_id': d.get('id'),
            'imdb_id': d.get('imdb_id') or (d.get('external_ids') or {}).get('imdb_id') or None,
            'title': title,
            'original_title': d.get('original_title') if d.get('original_title') != title else None,
            'year': _year(d.get('release_date')), 'premiered': d.get('release_date') or None,
            'plot': d.get('overview') or None, 'tagline': d.get('tagline') or None,
            'runtime': d.get('runtime') or None,
            'genres': [g['name'] for g in d.get('genres') or []],
            'studios': [c['name'] for c in (d.get('production_companies') or [])[:3]],
            'countries': [c['name'] for c in d.get('production_countries') or []],
            'directors': [c['name'] for c in crew if c.get('job') == 'Director'],
            'writers': writers[:4],
            'cast': self._cast(d),
            'poster': IMG_POSTER + d['poster_path'] if d.get('poster_path') else None,
            'fanart': IMG_FANART + d['backdrop_path'] if d.get('backdrop_path') else None,
            'collection': (d.get('belongs_to_collection') or {}).get('name'),
            'tmdb_rating': self._tmdb_rating(d),
        }
        self.cache.set(key, meta)
        return meta

    def _show_cached(self, tmdb_id):
        key = 'tmdb|tv|%s|%s' % (self.language, tmdb_id)
        cached = self.cache.get(key)
        if cached is not MISS:
            return cached
        d = self._tmdb('/tv/%d' % tmdb_id, append_to_response='external_ids,credits')
        if d is None:
            self.cache.set(key, None)
            return None
        ext = d.get('external_ids') or {}
        title = d.get('name') or ''
        networks = [n['name'] for n in d.get('networks') or []] or \
                   [c['name'] for c in d.get('production_companies') or []]
        meta = {
            'kind': 'tv', 'tmdb_id': d.get('id'), 'imdb_id': ext.get('imdb_id') or None,
            'tvdb_id': ext.get('tvdb_id') or None,
            'title': title,
            'original_title': d.get('original_name') if d.get('original_name') != title else None,
            'year': _year(d.get('first_air_date')), 'premiered': d.get('first_air_date') or None,
            'plot': d.get('overview') or None, 'status': d.get('status') or None,
            'genres': [g['name'] for g in d.get('genres') or []],
            'studios': networks[:3],
            'cast': self._cast(d),
            'poster': IMG_POSTER + d['poster_path'] if d.get('poster_path') else None,
            'fanart': IMG_FANART + d['backdrop_path'] if d.get('backdrop_path') else None,
            'season_posters': {str(s['season_number']): IMG_POSTER + s['poster_path']
                               for s in d.get('seasons') or []
                               if s.get('poster_path') and s.get('season_number') is not None},
            'tmdb_rating': self._tmdb_rating(d),
        }
        self.cache.set(key, meta)
        return meta

    def _season(self, tmdb_id, season):
        key = 'tmdb|season|%s|%s|%s' % (self.language, tmdb_id, season)
        cached = self.cache.get(key)
        if cached is not MISS:
            return cached
        d = self._tmdb('/tv/%d/season/%d' % (tmdb_id, season))
        episodes = {}
        for e in (d or {}).get('episodes') or []:
            episodes[str(e.get('episode_number'))] = {
                'title': e.get('name') or None, 'plot': e.get('overview') or None,
                'aired': e.get('air_date') or None, 'runtime': e.get('runtime') or None,
                'still': IMG_STILL + e['still_path'] if e.get('still_path') else None,
                'tmdb_rating': self._tmdb_rating(e),
            }
        self.cache.set(key, episodes)
        return episodes

    # ------------------------------------------------------------------ OMDb

    def _omdb_get(self, params):
        params = dict(params)
        params['apikey'] = self.omdb_key
        try:
            status, data = net.get_json(OMDB_BASE, params=params,
                                        sleeper=self.sleeper, abort=self.abort)
        except net.NetError as exc:
            raise OmdbError(str(exc))
        if not isinstance(data, dict):
            raise OmdbError('OMDb returned HTTP %s' % status)
        if str(data.get('Response')).lower() == 'false':
            error = str(data.get('Error', ''))
            low = error.lower()
            if 'limit' in low:
                self.omdb_blocked = True
                raise OmdbLimit(error)
            if 'api key' in low:
                raise OmdbAuthError(error)
            return None  # simply not found
        return data

    def omdb(self, imdb_id):
        """IMDb rating info for a title id: {'rating', 'votes', 'rated'} or None."""
        key = 'omdb|%s' % imdb_id
        cached = self.cache.get(key)
        if cached is not MISS:
            return cached
        if self.omdb_blocked:
            raise OmdbLimit('OMDb daily limit reached')
        data = self._omdb_get({'i': imdb_id})
        if data is None:
            self.cache.set(key, None)
            return None
        rated = data.get('Rated')
        info = {'rating': _to_float(data.get('imdbRating')), 'votes': _to_int(data.get('imdbVotes')),
                'rated': rated if rated and rated != 'N/A' else None}
        self.cache.set(key, info)
        return info

    def omdb_season(self, imdb_id, season):
        key = 'omdb|season|%s|%s' % (imdb_id, season)
        cached = self.cache.get(key)
        if cached is not MISS:
            return cached
        if self.omdb_blocked:
            raise OmdbLimit('OMDb daily limit reached')
        data = self._omdb_get({'i': imdb_id, 'Season': season})
        episodes = {}
        for e in (data or {}).get('Episodes') or []:
            number = _to_int(e.get('Episode'))
            if number is not None:
                episodes[str(number)] = {'rating': _to_float(e.get('imdbRating')),
                                         'imdb_id': e.get('imdbID') or None}
        self.cache.set(key, episodes)
        return episodes

    # -------------------------------------------------------- public: compose

    def _finish(self, meta):
        """Attach the ratings list (IMDb first, then TMDb) to a cached meta dict."""
        meta = dict(meta)
        imdb = None
        if self.omdb_key and meta.get('imdb_id'):
            try:
                imdb = self.omdb(meta['imdb_id'])
            except OmdbAuthError:
                raise
            except OmdbError:
                if self.defer_on_limit:
                    raise
                imdb = None
        ratings = []
        if imdb and imdb.get('rating'):
            ratings.append({'name': 'imdb', 'value': imdb['rating'],
                            'votes': imdb.get('votes'), 'default': True})
        tmdb = meta.pop('tmdb_rating', None)
        if tmdb:
            ratings.append({'name': 'themoviedb', 'value': tmdb['value'],
                            'votes': tmdb['votes'], 'default': not ratings})
        meta['ratings'] = ratings
        if imdb and imdb.get('rated') and not meta.get('mpaa'):
            meta['mpaa'] = imdb['rated']
        return meta

    def movie_by_id(self, tmdb_id):
        meta = self._movie_cached(int(tmdb_id))
        return self._finish(meta) if meta else None

    def show_by_id(self, tmdb_id):
        meta = self._show_cached(int(tmdb_id))
        return self._finish(meta) if meta else None

    def lookup_movie(self, title, year=None, alt=None):
        if not self.enabled:
            return None
        found = self._find('movie', title, year, alt)
        return self.movie_by_id(found['id']) if found else None

    def lookup_show(self, title, year=None, alt=None):
        if not self.enabled:
            return None
        found = self._find('tv', title, year, alt)
        return self.show_by_id(found['id']) if found else None

    def episode_infos(self, show, season, numbers):
        """Details for each episode number; unknown episodes get a minimal entry."""
        tmdb_eps = self._season(show['tmdb_id'], season)
        omdb_eps = {}
        if self.episode_ratings and self.omdb_key and show.get('imdb_id') and season > 0:
            try:
                omdb_eps = self.omdb_season(show['imdb_id'], season)
            except OmdbAuthError:
                raise
            except OmdbError:
                if self.defer_on_limit:
                    raise
                omdb_eps = {}
        infos = []
        for number in numbers:
            base = tmdb_eps.get(str(number)) or {}
            info = {'episode': number, 'title': base.get('title'), 'plot': base.get('plot'),
                    'aired': base.get('aired'), 'runtime': base.get('runtime'),
                    'still': base.get('still'), 'ratings': []}
            o = omdb_eps.get(str(number))
            if o and o.get('rating'):
                info['ratings'].append({'name': 'imdb', 'value': o['rating'], 'default': True})
                info['imdb_id'] = o.get('imdb_id')
            t = base.get('tmdb_rating')
            if t:
                info['ratings'].append({'name': 'themoviedb', 'value': t['value'],
                                        'votes': t['votes'], 'default': not info['ratings']})
            infos.append(info)
        return infos

    # ------------------------------------------------------------- key checks

    def check_keys(self):
        """Return {'tmdb': (ok, text), 'omdb': (ok, text)} for the settings test."""
        result = {}
        if not self.tmdb_key:
            result['tmdb'] = (False, 'No TMDb key entered')
        else:
            try:
                self._tmdb('/configuration')
                result['tmdb'] = (True, 'OK')
            except TmdbError as exc:
                result['tmdb'] = (False, str(exc))
        if not self.omdb_key:
            result['omdb'] = (False, 'No OMDb key entered (IMDb ratings will be skipped)')
        else:
            try:
                data = self._omdb_get({'i': 'tt0111161'})
                result['omdb'] = (True, 'OK') if data else (False, 'Unexpected empty answer')
            except OmdbLimit:
                result['omdb'] = (True, 'Key works, but the daily limit is used up')
            except OmdbError as exc:
                result['omdb'] = (False, str(exc))
        return result
