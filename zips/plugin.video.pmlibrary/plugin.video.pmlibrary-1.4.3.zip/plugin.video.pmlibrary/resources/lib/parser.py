# -*- coding: utf-8 -*-
"""Turn messy release names into title / year / season / episode."""
import datetime
import os
import re
import string
import unicodedata

VIDEO_EXT = ('.mkv', '.mp4', '.avi', '.mov', '.m4v', '.wmv', '.ts', '.m2ts',
             '.mpg', '.mpeg', '.flv', '.webm', '.divx')

MAX_YEAR = datetime.date.today().year + 1

# Tokens that mark the end of the title (never treated as part of a title).
_STRONG_RE = re.compile(
    r'^(?:(?:2160|1440|1080|720|576|480)[pi]|4k|uhd|bluray|bdrip|brrip|bdremux|remux|'
    r'webdl|webrip|hdtv|pdtv|dvdrip|dvdscr|dvd|hdrip|camrip|hdcam|hdts|telesync|telecine|'
    r'x26[45]|h26[45]|hevc|xvid|divx|av1|10bit|8bit|hdr\d*|hdr10plus|'
    r'(?:aac|ac3|eac3|dts|ddp?|truehd|atmos|flac)\d*)$', re.I)

# Edition words stripped from the end of a title (only if 2+ words remain).
_WEAK = {'extended', 'unrated', 'uncut', 'proper', 'repack', 'remastered', 'imax',
         'theatrical', 'directors', "director's", 'cut', 'edition', 'special',
         'criterion', 'restored'}

_SEASON_ONLY = re.compile(r'^s\d{1,2}$', re.I)
_QUALITY = re.compile(r'(?i)(?<![a-z0-9])(2160p|1080p|720p|480p|4k)(?![a-z0-9])')
_JUNK_NAME = re.compile(
    r'(?i)(?:^|[^a-z0-9])(?:sample|trailer|teaser|featurette|behind[ ._-]the[ ._-]scenes|'
    r'deleted[ ._-]scenes|bloopers?)(?:$|[^a-z0-9])')
_JUNK_DIRS = {'sample', 'samples', 'extras', 'extra', 'featurettes', 'trailers',
              'behind the scenes', 'deleted scenes', 'bonus'}
_GENERIC_DIR = re.compile(
    r'(?i)^(?:(?:season|series|s)[ ._-]*\d{1,2}\b.*|specials?|extras?|featurettes?|samples?|'
    r'subs?|subtitles?|complete.*|movies?|tv ?shows?|tv|series|videos?|downloads?|'
    r'torrents?|premiumize|my files|cloud|new folder)$')


def is_video(name, mime=''):
    return os.path.splitext(name)[1].lower() in VIDEO_EXT or (mime or '').startswith('video/')


def is_junk(name, dirs, size=0):
    for d in dirs or []:
        if d.strip().lower() in _JUNK_DIRS:
            return True
    stem = os.path.splitext(name)[0]
    return bool(_JUNK_NAME.search(stem)) and size < 300 * 1024 * 1024


def normalize(text):
    """Lowercase, accent-free, letters and digits only. For comparing titles."""
    text = unicodedata.normalize('NFKD', text or '')
    text = ''.join(c for c in text if not unicodedata.combining(c))
    text = text.lower().replace('&', ' and ')
    return re.sub(r'[\W_]+', '', text, flags=re.UNICODE)


def _prep(s):
    s = re.sub(r'(?i)(?<![a-z0-9])blu[ ._-]?ray(?![a-z0-9])', 'bluray', s)
    s = re.sub(r'(?i)(?<![a-z0-9])web[ ._-]?dl(?![a-z0-9])', 'webdl', s)
    s = re.sub(r'(?i)(?<![a-z0-9])(web|bd|br|dvd|hd)[ ._-]?rip(?![a-z0-9])',
               lambda m: m.group(1).lower() + 'rip', s)
    s = re.sub(r'(?i)(?<![a-z0-9])dd(?:p|\+)?[ ._]?([257])[ ._][01](?![0-9])',
               lambda m: 'dd' + m.group(1), s)
    s = re.sub(r'(?i)(?<![a-z0-9])h[ ._]26([45])(?![0-9])',
               lambda m: 'h26' + m.group(1), s)
    s = re.sub(r'[._]+', ' ', s)
    s = re.sub(r'[\[\]\(\)\{\}]', ' ', s)
    return re.sub(r' +', ' ', s).strip()


def _is_year(token):
    return bool(re.fullmatch(r'(?:19|20)\d\d', token)) and 1900 <= int(token) <= MAX_YEAR


def _split(s, stop=None, mode='file'):
    """Return (title, year) from the title area of a prepared string."""
    area = s if stop is None else s[:stop]
    tokens = area.replace('-', ' ').split()
    cut = len(tokens)
    for i, tok in enumerate(tokens):
        if i == 0:
            continue
        if _STRONG_RE.match(tok):
            cut = i
            break
        if mode == 'folder' and (_SEASON_ONLY.match(tok) or tok.lower() in ('season', 'seasons', 'complete')):
            cut = i
            break
    head = tokens[:cut]
    year = None
    for i in range(len(head) - 1, 0, -1):
        if _is_year(head[i]):
            year = int(head[i])
            head = head[:i]
            break
    while len(head) > 2 and head[-1].lower() in _WEAK:
        head.pop()
    return ' '.join(head), year


_GENERIC_NAMES = {'movie', 'video', 'film', 'main', 'file', 'full', 'feature', 'untitled'}


def _usable(title):
    if len(title) < 2 or re.fullmatch(r'[0-9a-fA-F]{16,}', title.replace(' ', '')):
        return False
    return title.strip().lower() not in _GENERIC_NAMES


def _season_from_dirs(dirs):
    for d in reversed(dirs):
        m = re.match(r'(?i)^\s*(?:season|series|s)[ ._-]*(\d{1,2})\b', d)
        if m:
            return int(m.group(1))
        if re.match(r'(?i)^\s*specials?\s*$', d):
            return 0
    return None


def _folder_hint(dirs):
    for d in reversed(dirs):
        if _GENERIC_DIR.match(d.strip()):
            continue
        s = _prep(re.sub(r'(?i)\((?:US|UK|AU|CA|NZ)\)', ' ', d))
        title, year = _split(s, mode='folder')
        if _usable(title):
            return title, year
        return None, None
    return None, None


def _find_episode(s, dirs, fansub):
    """Detect season/episode info. Returns dict(season, eps, stop) or None."""
    m = re.search(r'(?i)(?<![a-z0-9])s(\d{1,2}) ?e(\d{1,3})(?![0-9])', s)
    if m:
        season, eps, pos = int(m.group(1)), [int(m.group(2))], m.end()
        while True:
            m2 = re.match(r'(?i) *(-|&|and|\+)? *e(\d{1,3})(?![0-9])', s[pos:])
            if m2:
                number = int(m2.group(2))
                if m2.group(1) == '-' and eps[-1] < number <= eps[-1] + 30:
                    eps.extend(range(eps[-1] + 1, number + 1))  # E01-E03 means 1, 2, 3
                else:
                    eps.append(number)
                pos += m2.end()
                continue
            m3 = re.match(r' *- *(\d{2,3})(?![0-9pPiI])', s[pos:])
            if m3 and len(eps) == 1:
                end = int(m3.group(1))
                if eps[0] < end <= eps[0] + 30:
                    eps.extend(range(eps[0] + 1, end + 1))
            break
        return {'season': season, 'eps': sorted(set(eps)), 'stop': m.start()}

    m = re.search(r'(?i)(?<![a-z0-9])(\d{1,2})x(\d{2,3})(?![0-9a-z])', s)
    if m:
        return {'season': int(m.group(1)), 'eps': [int(m.group(2))], 'stop': m.start()}

    m = re.search(r'(?i)(?<![a-z0-9])season ?(\d{1,2}) *[-,]? *(?:episode|ep) ?(\d{1,3})(?![0-9])', s)
    if m:
        return {'season': int(m.group(1)), 'eps': [int(m.group(2))], 'stop': m.start()}

    season_dir = _season_from_dirs(dirs)
    if season_dir is not None:
        m = re.search(r'(?i)(?<![a-z0-9])(?:episode|ep|e) ?(\d{1,3})(?![0-9a-z])', s)
        if m:
            return {'season': season_dir, 'eps': [int(m.group(1))], 'stop': m.start()}
        m = re.match(r'^(\d{1,3})(?: *[-.] *| +)', s)
        if m:
            return {'season': season_dir, 'eps': [int(m.group(1))], 'stop': 0}

    if fansub:
        m = re.match(r'^(.*?) - (\d{1,3})(?:v\d)?(?![0-9a-z])', s)
        if m and m.group(1).strip():
            season = season_dir if season_dir is not None else 1
            return {'season': season, 'eps': [int(m.group(2))], 'stop': len(m.group(1))}
    return None


def _tidy(title):
    if title and (title.islower() or title.isupper()):
        return string.capwords(title)
    return title


def parse(name, dirs=None, force_movie=False):
    """Parse a cloud file name (plus its folder names) into a media description.

    Returns a dict: kind ('movie' or 'episode'), title, year, alt_title, quality and,
    for episodes, season and episodes (list).
    """
    dirs = list(dirs or [])
    base, ext = os.path.splitext(name)
    stem = base if ext.lower() in VIDEO_EXT else name

    fansub = False
    m = re.match(r'^\s*\[[^\]]*\]\s*', stem)
    if m:
        stem = stem[m.end():]
        fansub = True
    stem = re.sub(r'(?i)^(?:www\.)?[a-z0-9-]+\.(?:com|org|net|to|me|ws|cc|io|tv|info)\s*[-–—]+\s*', '', stem)
    stem = re.sub(r'(?i)\((?:US|UK|AU|CA|NZ)\)', ' ', stem)
    s = _prep(stem)

    quality = None
    qm = _QUALITY.search(s)
    if qm:
        quality = qm.group(1).lower()

    ep = None if force_movie else _find_episode(s, dirs, fansub)
    hint_title, hint_year = _folder_hint(dirs)

    if ep:
        title, year = _split(s, stop=ep['stop'])
        if not _usable(title):
            if hint_title:
                title, year = hint_title, hint_year
        elif year is None and hint_year and hint_title and normalize(hint_title) == normalize(title):
            year = hint_year
        tokens = title.split()
        if len(tokens) > 2 and tokens[-1].lower() in ('us', 'uk', 'au', 'nz'):
            title = ' '.join(tokens[:-1])
        title = _tidy(title) or 'Unknown'
        result = {'kind': 'episode', 'title': title, 'year': year,
                  'season': ep['season'], 'episodes': ep['eps']}
    else:
        title, year = _split(s)
        if not _usable(title):
            if hint_title:
                title, year = hint_title, hint_year
        elif year is None and hint_year and hint_title and normalize(hint_title) == normalize(title):
            year = hint_year
        title = _tidy(title) or 'Unknown'
        result = {'kind': 'movie', 'title': title, 'year': year}

    result['alt_title'] = ('%s %d' % (result['title'], result['year'])) if result['year'] else None
    result['quality'] = quality
    return result
