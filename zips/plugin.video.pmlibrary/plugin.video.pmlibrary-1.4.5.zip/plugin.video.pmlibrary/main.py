# -*- coding: utf-8 -*-
"""Plugin entry point: browse the cloud, play files, fix matches, and helper actions."""
import json
import sys
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import (delete, metadata, net, opensubs, parser, playback, premiumize, subfetch,
                           subservice, sync, utils, vaultui)

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
BASE_URL = sys.argv[0] if sys.argv else 'plugin://%s/' % utils.ADDON_ID
RUNNING = 'pmlib.running'
REQUEST = 'pmlib.request'
HEADING = 'Premiumize Library'


def build_url(**params):
    return '%s?%s' % (BASE_URL, urlencode(params))


def set_info(item, title=None, plot=None, year=None, mediatype=None):
    try:  # Kodi 20+
        tag = item.getVideoInfoTag()
        if title:
            tag.setTitle(title)
        if plot:
            tag.setPlot(plot)
        if year:
            tag.setYear(int(year))
        if mediatype:
            tag.setMediaType(mediatype)
    except AttributeError:  # Kodi 19
        info = {}
        if title:
            info['title'] = title
        if plot:
            info['plot'] = plot
        if year:
            info['year'] = int(year)
        if mediatype:
            info['mediatype'] = mediatype
        item.setInfo('video', info)


def finish(succeeded=True):
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=succeeded)


def action_done():
    """Close a click-through action item (not a list) cleanly."""
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False, cacheToDisc=False)


def pm_client():
    key = utils.setting('pm_api_key').strip()
    if not key:
        xbmcgui.Dialog().ok(HEADING, 'Enter your Premiumize API key in the add-on settings first.')
        return None
    return premiumize.Premiumize(key)


def make_metadata():
    cache = metadata.Cache(lambda: utils.load_json(sync.CACHE_FILE, {}),
                           lambda data: utils.save_json(sync.CACHE_FILE, data))
    md = metadata.Metadata(utils.setting('tmdb_key'), utils.setting('omdb_key'),
                           utils.setting('tmdb_language', 'en-US'), cache=cache)
    return md, cache


# ------------------------------------------------------------------- listings

def root_menu():
    index = utils.load_json(sync.INDEX_FILE, {})
    unmatched = sum(1 for e in (index.get('files') or {}).values() if not e.get('matched'))
    entries = []
    if not utils.setting('pm_api_key').strip() or not utils.setting('tmdb_key').strip():
        entries.append(('[B]Enter API keys[/B]', build_url(action='enter_keys'), False))
    entries += [
        ('Browse Premiumize cloud', build_url(action='browse'), True),
        ('Not matched to a movie or show (%d)' % unmatched, build_url(action='unmatched'), True),
        ('Sync library now', build_url(action='sync_now'), False),
        ('Sync subtitles of the video playing now', build_url(action='sync_subs'), False),
        ('How to add the library to Kodi', build_url(action='setup'), False),
        ('Settings', build_url(action='settings'), False),
    ]
    for label, url, is_folder in entries:
        xbmcplugin.addDirectoryItem(HANDLE, url, xbmcgui.ListItem(label=label), is_folder)
    finish()


def _file_item(file_id, name, entry):
    item = xbmcgui.ListItem(label=name)
    item.setProperty('IsPlayable', 'true')
    if entry:
        set_info(item, title=entry.get('title'), year=entry.get('year'), mediatype='video')
        if entry.get('poster'):
            item.setArt({'thumb': entry['poster'], 'poster': entry['poster']})
    else:
        set_info(item, title=name, mediatype='video')
    item.addContextMenuItems([('Match to a different movie or show...',
                               'RunPlugin(%s)' % build_url(action='fix', id=file_id)),
                              ('Delete from Premiumize...',
                               'RunPlugin(%s)' % build_url(action='delete', id=file_id, name=name))])
    return item


def browse(folder_id=None):
    pm = pm_client()
    if pm is None:
        return finish(False)
    try:
        data = pm.list_folder(folder_id)
    except premiumize.PremiumizeError as exc:
        xbmcgui.Dialog().ok(HEADING, 'Could not read the folder: %s' % exc)
        return finish(False)
    index = (utils.load_json(sync.INDEX_FILE, {}).get('files')) or {}
    for entry in data.get('content') or []:
        name = entry.get('name') or ''
        if entry.get('type') == 'folder':
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action='browse', id=entry['id']),
                                        xbmcgui.ListItem(label=name), True)
        elif parser.is_video(name, entry.get('mime_type', '')):
            fid = str(entry['id'])
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action='play', id=fid),
                                        _file_item(fid, name, index.get(fid)), False)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
    xbmcplugin.setContent(HANDLE, 'files')
    finish()


def unmatched():
    index = (utils.load_json(sync.INDEX_FILE, {}).get('files')) or {}
    rows = sorted(((e.get('name', ''), fid, e) for fid, e in index.items() if not e.get('matched')),
                  key=lambda r: r[0].lower())
    for name, fid, entry in rows:
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action='play', id=fid),
                                    _file_item(fid, name, entry), False)
    xbmcplugin.setContent(HANDLE, 'files')
    finish()


# ------------------------------------------------------------------- playback

def play(file_id):
    entry = ((utils.load_json(sync.INDEX_FILE, {}).get('files')) or {}).get(file_id) or {}
    base = ''
    if utils.setting_bool('use_dir_link', True):
        base, _where = playback.find_dir_link()

    link = None
    if base and entry.get('path'):
        candidate = playback.file_url(base, entry['path'])
        if net.url_ok(candidate):
            link = candidate
        else:
            utils.log('HTTP folder link did not answer for this file; using the Premiumize API link')

    pm = None
    if link is None:
        pm = pm_client()
        if pm is None:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        try:
            link = pm.resolve_link(file_id)
        except (premiumize.PremiumizeError, net.NetError) as exc:
            utils.notify('Could not play: %s' % exc, icon=xbmcgui.NOTIFICATION_ERROR, ms=7000)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return

    item = xbmcgui.ListItem(path=link)
    subs = []
    cached = subfetch.cached_file(file_id)
    if cached:
        subs.append(cached)
    for sub in entry.get('subs') or []:
        if base and link.startswith(base):
            subs.append(playback.file_url(base, sub['path']))
            continue
        try:
            pm = pm or premiumize.Premiumize(utils.setting('pm_api_key').strip())
            subs.append(pm.resolve_link(sub['id']))
        except (premiumize.PremiumizeError, net.NetError):
            pass
    if subs:
        item.setSubtitles(subs)
    subfetch.leave_note(file_id, bool(subs))
    subservice.remember_current(file_id, link)
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


# -------------------------------------------------------------------- actions

def request_sync(mode):
    win = utils.home_window()
    if win.getProperty(RUNNING) == '1':
        utils.notify('A sync is already running.')
    else:
        win.setProperty(REQUEST, mode)
        utils.notify('Sync requested. It runs in the background.')
    action_done()


def rebuild():
    ok = xbmcgui.Dialog().yesno(
        HEADING, 'Rebuild the library?\n\nThis deletes the generated library files and creates '
                 'them again. Your Premiumize files are not touched, but watched marks in Kodi '
                 'for these items are lost.')
    if ok:
        request_sync('rebuild')
    else:
        action_done()


def setup_guide():
    root = utils.library_root_kodi()
    text = (
        'Your library folders are:\n'
        '  Movies:    %s/Movies/\n'
        '  TV shows:  %s/TV Shows/\n\n'
        '1. Run "Sync library now" and wait for the "Sync finished" message.\n\n'
        '2. In Kodi: Videos > Files > Add videos... Do not press Browse. Select the empty '
        'path box, type the Movies path above exactly, and press OK.\n\n'
        '3. "This directory contains": Movies. "Choose information provider": '
        '"Local information only". Turn on "Movies are in separate folders that match the movie '
        'title". Press OK.\n\n'
        '4. Repeat for TV Shows: type the TV Shows path, content "TV shows", provider '
        '"Local information only", and leave "Selected folder contains a single TV show" off.\n\n'
        '5. Say Yes when Kodi offers to scan. After this, every sync updates the library by '
        'itself.\n\n'
        'Files that could not be matched to a movie or show are not shown in the library. '
        'Find them under "Not matched" in this add-on.' % (root, root))
    xbmcgui.Dialog().textviewer(HEADING, text)
    action_done()


def enter_keys():
    """Backup way to type the keys, straight from the add-on menu."""
    dialog = xbmcgui.Dialog()
    fields = [('pm_api_key', 'Premiumize API key'),
              ('tmdb_key', 'TMDb API key'),
              ('omdb_key', 'OMDb API key (optional, for IMDb ratings)')]
    addon = utils.addon()
    for key, heading in fields:
        value = dialog.input(heading, defaultt=addon.getSetting(key))
        if value.strip():
            addon.setSetting(key, value.strip())
    action_done()
    test_keys_dialog()
    xbmc.executebuiltin('Container.Refresh')


def test_keys():
    test_keys_dialog()
    action_done()


def test_keys_dialog():
    lines = []
    key = utils.setting('pm_api_key').strip()
    if not key:
        lines.append('Premiumize: no API key entered')
    else:
        try:
            info = premiumize.Premiumize(key).account_info()
            lines.append('Premiumize: OK (account %s)' % info.get('customer_id', ''))
        except premiumize.PremiumizeError as exc:
            lines.append('Premiumize: %s' % exc)
    md, _ = make_metadata()
    checks = md.check_keys()
    lines.append('TMDb: %s' % checks['tmdb'][1])
    lines.append('OMDb: %s' % checks['omdb'][1])
    base, where = playback.find_dir_link()
    if not utils.setting_bool('use_dir_link', True):
        lines.append('HTTP folder link: switched off in settings')
    elif not base:
        lines.append('HTTP folder link: not found (playback uses API links)')
    else:
        found = 'from your Kodi sources' if where == 'sources' else 'from settings'
        state = 'OK' if net.url_ok(base + '/') else 'found but not answering'
        lines.append('HTTP folder link: %s (%s)' % (state, found))
    xbmcgui.Dialog().ok(HEADING, '\n'.join(lines))


def os_test():
    client = opensubs.OpenSubtitles(utils.setting('os_api_key'), utils.setting('os_username'),
                                    utils.setting('os_password'))
    if not client.configured:
        msg = 'Enter your OpenSubtitles username, password and API key first.'
    else:
        try:
            client.token(force=True)
            info = client.user_info()
            remaining = info.get('remaining_downloads')
            allowed = info.get('allowed_downloads')
            level = info.get('level') or ('VIP' if info.get('vip') else 'standard')
            msg = 'OpenSubtitles: OK\nAccount level: %s\nDownloads left today: %s of %s' % (
                level, remaining if remaining is not None else '?', allowed if allowed is not None else '?')
            if not utils.setting_bool('os_enabled', False):
                msg += '\n\nNote: "Fetch English subtitles" is switched off.'
        except opensubs.OSError_ as exc:
            msg = 'OpenSubtitles: %s' % exc
    xbmcgui.Dialog().ok(HEADING, msg)
    action_done()


EXPORT_NAME = 'pmlibrary-settings.json'


def export_settings():
    dialog = xbmcgui.Dialog()
    folder = dialog.browse(3, 'Choose where to save the settings (e.g. your USB stick)', 'files')
    if not folder:
        return action_done()
    data = {'addon': utils.ADDON_ID, 'version': 1, 'settings': {}}
    for key in utils.EXPORT_KEYS:
        data['settings'][key] = utils.setting(key)
    if not data['settings'].get('pm_dir_url'):
        base, _where = playback.find_dir_link()   # carry the HTTP folder link to the other device
        if base:
            data['settings']['pm_dir_url'] = base
    path = folder.rstrip('/\\') + '/' + EXPORT_NAME
    try:
        utils.fs_write(path, json.dumps(data, indent=1))
    except Exception:  # noqa: BLE001
        dialog.ok(HEADING, 'Could not write to that folder. Try another one.')
        return action_done()
    dialog.ok(HEADING, 'Settings saved as %s.\n\nThe file contains your API keys and passwords, so '
                       'delete it from the USB stick after importing it on the other device.' % EXPORT_NAME)
    action_done()


def import_settings():
    dialog = xbmcgui.Dialog()
    path = dialog.browse(1, 'Choose %s' % EXPORT_NAME, 'files', '.json')
    if not path:
        return action_done()
    try:
        data = json.loads(utils.fs_read(path))
        values = data['settings']
        if data.get('addon') != utils.ADDON_ID or not isinstance(values, dict):
            raise ValueError
    except Exception:  # noqa: BLE001
        dialog.ok(HEADING, 'That file is not a Premiumize Library settings file.')
        return action_done()
    addon = utils.addon()
    count = 0
    for key in utils.EXPORT_KEYS:
        if key in values and values[key] is not None:
            addon.setSetting(key, str(values[key]))
            count += 1
    dialog.ok(HEADING, 'Imported %d settings. Use "Test connections" to check them, then run '
                       '"Sync library now".' % count)
    action_done()


def fix(file_id):
    dialog = xbmcgui.Dialog()
    if utils.home_window().getProperty(RUNNING) == '1':
        dialog.ok(HEADING, 'A sync is running. Try again when it has finished.')
        return
    engine = sync.SyncEngine()
    engine.load()
    entry = engine.files.get(file_id)
    if not entry:
        dialog.ok(HEADING, 'This file is not part of the library (it may be too small, a sample, '
                           'or not synced yet).')
        return
    md, cache = make_metadata()
    if not md.enabled:
        dialog.ok(HEADING, 'Enter your TMDb API key in the add-on settings first.')
        return
    parsed = parser.parse(entry['name'], entry.get('dirs'))
    choice = dialog.select('Match this file as...', ['Movie', 'TV show'],
                           preselect=0 if parsed['kind'] == 'movie' else 1)
    if choice < 0:
        return
    kind = 'movie' if choice == 0 else 'tv'
    # No episode code in the name (or matched by hand before): pick show, season and
    # episode for this one file instead of asking for a rename.
    by_hand = kind == 'tv' and (not entry.get('tkey') or entry.get('manual'))
    query = dialog.input('Search TMDb for', defaultt=parsed['title'])
    if not query:
        return
    try:
        candidates = md.search_candidates(kind, query)
        cache.flush()
    except metadata.TmdbError as exc:
        dialog.ok(HEADING, 'TMDb search failed: %s' % exc)
        return
    if not candidates:
        dialog.ok(HEADING, 'No results for "%s".' % query)
        return
    picked = dialog.select('Choose the right match', [c['label'] for c in candidates])
    if picked < 0:
        return
    show_id = candidates[picked]['id']
    if by_hand:
        numbers = _pick_episode(md, show_id, entry)
        cache.flush()
        if numbers is None:
            return
        engine.apply_manual_match(file_id, 'episode', show_id, numbers[0], numbers[1])
        utils.home_window().setProperty(REQUEST, 'sync')
        utils.notify('Matched as season %d, episode %d. Updating the library in the background.'
                     % numbers)
        return
    count = engine.apply_manual_match(file_id, kind, show_id)
    utils.home_window().setProperty(REQUEST, 'sync')
    utils.notify('Re-matching %d file(s) in the background.' % count)


def _ask_number(heading, default):
    value = xbmcgui.Dialog().numeric(0, heading, str(default))
    try:
        return int(value) if str(value).strip() else None
    except ValueError:
        return None


def _pick_episode(md, show_id, entry):
    """Ask which season and episode this file is. Returns (season, episode) or None."""
    dialog = xbmcgui.Dialog()
    if entry.get('manual') and entry.get('season') is not None and entry.get('episodes'):
        guess_season, guess_ep = entry['season'], entry['episodes'][0]
    else:
        guess_season, guess_ep = parser.guess_numbers(entry.get('name', ''), entry.get('dirs'))
    try:
        seasons = md.season_list(show_id)
    except metadata.TmdbError:
        seasons = []
    if len(seasons) == 1:
        season = seasons[0][0]
    elif seasons:
        labels = ['%s (%d episode%s)' % (name, n, '' if n == 1 else 's') for _, name, n in seasons]
        pre = next((i for i, x in enumerate(seasons) if x[0] == guess_season), 0)
        i = dialog.select('Which season is this file?', labels, preselect=pre)
        if i < 0:
            return None
        season = seasons[i][0]
    else:
        season = _ask_number('Season number (0 for specials)', guess_season)
        if season is None:
            return None
    try:
        episodes = md.episode_list(show_id, season)
    except metadata.TmdbError:
        episodes = []
    if episodes:
        labels = ['%d. %s' % (n, t) if t else 'Episode %d' % n for n, t in episodes]
        pre = next((i for i, x in enumerate(episodes) if x[0] == guess_ep), 0)
        i = dialog.select('Which episode is this file?', labels, preselect=pre)
        if i < 0:
            return None
        return season, episodes[i][0]
    episode = _ask_number('Episode number', guess_ep)
    if not episode:
        return None
    return season, episode


# --------------------------------------------------------------------- router

def main():
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    if action is None:
        root_menu()
    elif action == 'browse':
        browse(params.get('id'))
    elif action == 'unmatched':
        unmatched()
    elif action == 'play':
        play(params.get('id', ''))
    elif action == 'sync_now':
        request_sync('sync')
    elif action == 'rebuild':
        rebuild()
    elif action == 'setup':
        setup_guide()
    elif action == 'test_keys':
        test_keys()
    elif action == 'enter_keys':
        enter_keys()
    elif action == 'os_test':
        os_test()
    elif action == 'search':                       # Kodi: Subtitles > Download
        subservice.search(HANDLE)
    elif action == 'manualsearch':
        subservice.search(HANDLE, manual_query=params.get('searchstring', ''))
    elif action == 'sub_download':
        subservice.download(HANDLE, params.get('file_id', ''))
    elif action == 'sub_sync':
        subservice.sync_action(HANDLE)
    elif action == 'sub_unsync':
        subservice.unsync_action(HANDLE)
    elif action == 'sync_subs':
        subservice.sync_from_menu()
        action_done()
    elif action == 'os_forget':
        count = subfetch.forget_failed_searches()
        xbmcgui.Dialog().ok(HEADING, 'Forgot %d failed subtitle search%s. The next play of those '
                                     'videos searches OpenSubtitles again.' % (count, '' if count == 1 else 'es'))
        action_done()
    elif action == 'export_settings':
        export_settings()
    elif action == 'import_settings':
        import_settings()
    elif action == 'vault_export':
        action_done()
        vaultui.export_locked()
    elif action == 'vault_import':
        action_done()
        vaultui.fill_in(auto=False)
    elif action == 'fix':
        fix(params.get('id', ''))
    elif action == 'delete':
        fid = params.get('id', '')
        delete.delete(params.get('name') or fid, [fid] if fid else [])
    elif action == 'settings':
        xbmc.executebuiltin('Addon.OpenSettings(%s)' % utils.ADDON_ID)
        action_done()


if __name__ == '__main__':
    main()
