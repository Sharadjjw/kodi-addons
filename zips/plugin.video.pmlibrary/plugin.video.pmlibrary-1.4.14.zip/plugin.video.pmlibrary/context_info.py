# -*- coding: utf-8 -*-
"""Long-press menu in the Kodi library: File details (the real Premiumize file)."""
from context import _info
from resources.lib import fileinfo


def main():
    dbtype, dbid = _info()
    if dbtype not in ('movie', 'episode') or dbid <= 0:
        return
    fileinfo.from_library(dbtype, dbid)


if __name__ == '__main__':
    main()
