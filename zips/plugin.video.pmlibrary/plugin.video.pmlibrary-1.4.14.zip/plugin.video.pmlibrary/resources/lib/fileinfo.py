# -*- coding: utf-8 -*-
"""File details: the real Premiumize file behind a library item or the video playing now.

Kodi only sees the add-on's .strm link, so its own info screens never show the release
name. This puts together what the add-on knows (cloud name, folder, size, match,
subtitles) with what Kodi or Premiumize know about the streams.
"""
import json

import xbmc
import xbmcgui

from . import net, premiumize, subfetch, subservice, sync, utils

HEADING = 'File details'
CHANNELS = {1: 'mono', 2: 'stereo', 6: '5.1', 7: '6.1', 8: '7.1'}


# ------------------------------------------------------------------ helpers

def size_text(size):
    try:
        size = int(size or 0)
    except (TypeError, ValueError):
        return ''
    if size < 1024 ** 2:
        return ''
    if size >= 1024 ** 3:
        return '%.2f GB' % (size / 1024.0 ** 3)
    return '%d MB' % round(size / 1024.0 ** 2)


def duration_text(seconds):
    try:
        seconds = int(float(seconds or 0))
    except (TypeError, ValueError):
        return ''
    if seconds <= 0:
        return ''
    hours, rest = divmod(seconds, 3600)
    return '%d h %02d min' % (hours, rest // 60) if hours else '%d min' % (rest // 60)


def resolution_text(width, height):
    try:
        width, height = int(width or 0), int(height or 0)
    except (TypeError, ValueError):
        return ''
    if not width or not height:
        return ''
    if width >= 3200 or height >= 1800:
        label = '4K'
    elif width >= 1800 or height >= 1000:
        label = '1080p'
    elif width >= 1200 or height >= 700:
        label = '720p'
    else:
        label = 'SD'
    return '%d x %d (%s)' % (width, height, label)


def _lang(code):
    code = (code or '').strip()
    return code if code and code.lower() not in ('und', 'unknown') else ''


def audio_line(stream):
    parts = [_lang(stream.get('language')), (stream.get('codec') or '').upper(),
             CHANNELS.get(stream.get('channels'), '%s ch' % stream['channels'] if stream.get('channels') else ''),
             (stream.get('name') or '').strip()]
    return ', '.join(p for p in parts if p) or 'track'


def subtitle_line(stream):
    parts = [_lang(stream.get('language')), (stream.get('name') or '').strip()]
    if stream.get('isforced'):
        parts.append('forced')
    if stream.get('isimpaired'):
        parts.append('hearing impaired')
    return ', '.join(p for p in parts if p) or 'track'


def match_text(entry):
    if not entry:
        return 'Not part of the library (too small, a sample, or not synced yet)'
    if not entry.get('matched'):
        return 'Not matched to a movie or show'
    title = entry.get('title') or ''
    if entry.get('year'):
        title = '%s (%s)' % (title, entry['year'])
    if entry.get('kind') == 'episode':
        eps = entry.get('episodes') or []
        code = 'S%02d' % (entry.get('season') or 0) + ''.join('E%02d' % e for e in eps)
        title = '%s %s' % (title, code)
        if entry.get('manual'):
            title += ' (matched by hand)'
    return title


# ------------------------------------------------------------- what we know

def cloud_details(file_id):
    """Premiumize's item/details for the file, or {} when it cannot be had."""
    key = utils.setting('pm_api_key').strip()
    if not key or not file_id:
        return {}
    try:
        return premiumize.Premiumize(key).details(file_id) or {}
    except (premiumize.PremiumizeError, net.NetError) as exc:
        utils.log('File details: Premiumize did not answer (%s)' % exc)
        return {}


def player_streams():
    """Streams of the video playing now, from Kodi's player. {} when nothing plays."""
    pid = subfetch._video_player_id()
    if pid is None:
        return {}
    return utils.jsonrpc('Player.GetProperties', {
        'playerid': pid,
        'properties': ['videostreams', 'currentvideostream', 'audiostreams', 'currentaudiostream',
                       'subtitles', 'currentsubtitle', 'subtitleenabled', 'totaltime']}) or {}


def library_streams(dbtype, dbid):
    """Stream details Kodi saved for a library item (filled in after it was played once)."""
    method, key, idkey = {'movie': ('VideoLibrary.GetMovieDetails', 'moviedetails', 'movieid'),
                          'episode': ('VideoLibrary.GetEpisodeDetails', 'episodedetails', 'episodeid')
                          }.get(dbtype, (None, None, None))
    if not method or not dbid:
        return {}
    d = utils.jsonrpc(method, {idkey: dbid, 'properties': ['streamdetails']}).get(key) or {}
    return d.get('streamdetails') or {}


def playing_file_id():
    """Cloud file id of the video playing now when this add-on started it, else None."""
    try:
        playing = xbmc.Player().getPlayingFile()
    except RuntimeError:
        return None
    try:
        note = json.loads(utils.home_window().getProperty(subservice.CURRENT_PROP) or '{}')
    except ValueError:
        note = {}
    if note.get('id') and subservice._same_video(note.get('url') or '', playing):
        return str(note['id'])
    return None


# ------------------------------------------------------------------ the text

def build_text(file_id, entry, cloud=None, live=None, saved=None):
    """The details as plain lines.

    entry: the add-on's index entry (may be {}); cloud: Premiumize item/details;
    live: Kodi Player.GetProperties of the video playing now; saved: Kodi library
    streamdetails. Every part is optional and left out when unknown.
    """
    entry = entry or {}
    cloud = cloud or {}
    live = live or {}
    saved = saved or {}
    lines = []

    name = entry.get('name') or cloud.get('name') or ''
    lines.append('[B]File name[/B]')
    lines.append(name or 'unknown')
    if entry.get('dirs'):
        lines.append('')
        lines.append('[B]Folder in Premiumize[/B]')
        lines.append(' / '.join(entry['dirs']))
    lines.append('')

    size = size_text(entry.get('size') or cloud.get('size'))
    if size:
        lines.append('[B]Size:[/B] %s' % size)
    lines.append('[B]Library:[/B] %s' % match_text(entry))

    # Video and audio: the player is exact for what plays now; otherwise what Kodi saved
    # after an earlier play; otherwise what Premiumize reports for the file.
    if live:
        source = 'now playing'
        videos = live.get('videostreams') or []
        current = live.get('currentvideostream') or (videos[0] if videos else {})
        width, height = current.get('width'), current.get('height')
        vcodec = current.get('codec')
        audios = live.get('audiostreams') or []
        cur_audio = (live.get('currentaudiostream') or {}).get('index')
        subs = live.get('subtitles') or []
        cur_sub = (live.get('currentsubtitle') or {}).get('index') if live.get('subtitleenabled') else None
        total = live.get('totaltime') or {}
        seconds = total.get('hours', 0) * 3600 + total.get('minutes', 0) * 60 + total.get('seconds', 0)
    elif saved.get('video') or saved.get('audio'):
        source = 'saved by Kodi at the last play'
        video = (saved.get('video') or [{}])[0]
        width, height, vcodec = video.get('width'), video.get('height'), video.get('codec')
        audios, cur_audio = saved.get('audio') or [], None
        subs, cur_sub = saved.get('subtitle') or [], None
        seconds = video.get('duration')
    else:
        source = 'from Premiumize' if cloud else ''
        width, height, vcodec = cloud.get('resx'), cloud.get('resy'), None
        audios, cur_audio, subs, cur_sub = [], None, [], None
        seconds = cloud.get('duration')

    res = resolution_text(width, height)
    length = duration_text(seconds)
    if res or vcodec or length:
        lines.append('')
        lines.append('[B]Video[/B]  [I](%s)[/I]' % source)
        if res:
            lines.append('Resolution: %s' % res)
        if vcodec:
            lines.append('Codec: %s' % vcodec.upper())
        if length:
            lines.append('Length: %s' % length)
    if audios:
        lines.append('')
        lines.append('[B]Audio tracks[/B]')
        for i, stream in enumerate(audios):
            mark = '  [I](playing)[/I]' if cur_audio is not None and stream.get('index', i) == cur_audio else ''
            lines.append('%d. %s%s' % (i + 1, audio_line(stream), mark))
    if subs:
        lines.append('')
        lines.append('[B]Subtitle tracks[/B]')
        for i, stream in enumerate(subs):
            mark = '  [I](shown)[/I]' if cur_sub is not None and stream.get('index', i) == cur_sub else ''
            lines.append('%d. %s%s' % (i + 1, subtitle_line(stream), mark))

    lines.append('')
    lines.append('[B]Subtitle files[/B]')
    cloud_subs = [s.get('name') for s in entry.get('subs') or [] if s.get('name')]
    if cloud_subs:
        lines.append('Next to the video in Premiumize: %s' % ', '.join(cloud_subs))
    else:
        lines.append('Next to the video in Premiumize: none')
    if file_id and subfetch.chosen_file(file_id):
        lines.append('Downloaded and chosen by you (Subtitles > Download): yes')
    elif file_id and subfetch.cached_file(file_id):
        lines.append('Fetched from OpenSubtitles: yes')
    return '\n'.join(lines)


def show(file_id, entry=None, dbtype=None, dbid=0, live=None):
    """Open the details window for one cloud file."""
    if entry is None:
        entry = ((utils.load_json(sync.INDEX_FILE, {}).get('files')) or {}).get(file_id) or {}
    cloud = {}
    saved = {}
    if live is None and dbtype:
        saved = library_streams(dbtype, dbid)
    if not live and not (saved.get('video') or saved.get('audio')):
        cloud = cloud_details(file_id)       # only needed when Kodi knows no streams
    elif not entry.get('name'):
        cloud = cloud_details(file_id)
    xbmcgui.Dialog().textviewer(HEADING, build_text(file_id, entry, cloud, live, saved))


def show_playing():
    """Details of the video playing now (when this add-on started it)."""
    file_id = playing_file_id()
    if not file_id:
        xbmcgui.Dialog().ok(HEADING, 'No Premiumize video is playing now. Start a video from your '
                                     'library, then open this again.')
        return
    show(file_id, live=player_streams())


def from_library(dbtype, dbid):
    """Details for a Kodi library movie or episode (long-press)."""
    from . import delete
    engine = sync.SyncEngine()
    engine.load()
    _label, fids = delete.from_library(engine, dbtype, dbid)
    if not fids:
        xbmcgui.Dialog().ok(HEADING, 'This item is not linked to a Premiumize file. Run "Sync library '
                                     'now" in the add-on and try again.')
        return
    # The playing video gets live stream details; others what Kodi saved or Premiumize knows.
    playing = playing_file_id()
    for i, fid in enumerate(fids):
        live = player_streams() if fid == playing else None
        show(fid, engine.files.get(fid) or {}, dbtype, dbid, live)
        if i + 1 < len(fids) and not xbmcgui.Dialog().yesno(
                HEADING, 'This item has %d files. Show the next one?' % len(fids)):
            break


def start_note(entry, name=None):
    """Short pop-up text when a video starts: the file name and its size."""
    name = (entry or {}).get('name') or name or ''
    if not name:
        return ''
    size = size_text((entry or {}).get('size'))
    return '%s  (%s)' % (name, size) if size else name
