"""Plugin source: history listing for Video add-ons and skin widgets.

plugin://script.lastplayed/                 full history (newest first)
plugin://script.lastplayed/?action=latest   only the most recent item ("continue" widget)
"""
import sys
import time
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

import lp_core as core


def _handle():
    try:
        return int(sys.argv[1])
    except Exception:
        return -1


def _params():
    try:
        return dict(parse_qsl(sys.argv[2][1:]))
    except Exception:
        return {}


HANDLE = _handle()
PARAMS = _params()


def build(**kwargs):
    return core.BASE_URL + '?' + urlencode(kwargs)


def set_tags(li, entry):
    pos = float(entry.get('pos') or 0)
    total = float(entry.get('total') or 0)
    when = time.strftime('%d %b %Y, %H:%M', time.localtime(entry.get('ts') or 0))
    plot = 'Last played: %s' % when
    if core.has_resume_point(entry):
        plot += '\nStopped at %s' % core.fmt_time(pos)
    title = entry.get('title') or entry['target']
    try:
        if entry.get('type') == 'audio':
            tag = li.getMusicInfoTag()
            tag.setTitle(title)
            tag.setComment(plot)
        else:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            tag.setPlot(plot)
            if core.has_resume_point(entry) and total > 0:
                tag.setResumePoint(pos, total)
    except Exception:
        try:
            li.setInfo('video', {'title': title, 'plot': plot})
        except Exception:
            pass


def list_entries(entries, show_clear):
    xbmcplugin.setContent(HANDLE, 'videos')
    if not entries:
        li = xbmcgui.ListItem(label='Nothing played yet')
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(HANDLE, build(action='noop'), li, False)
    for e in entries:
        li = xbmcgui.ListItem(label=e.get('title') or e['target'])
        li.setProperty('IsPlayable', 'true')
        thumb = e.get('thumb')
        if thumb:
            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
        set_tags(li, e)
        li.addContextMenuItems([
            ('Play from the beginning',
             'RunPlugin(%s)' % build(action='play', id=e['id'], resume='0')),
            ('Remove from history',
             'RunPlugin(%s)' % build(action='remove', id=e['id'])),
        ])
        xbmcplugin.addDirectoryItem(HANDLE, build(action='play', id=e['id']), li, False)
    if show_clear and entries:
        li = xbmcgui.ListItem(label='Clear history')
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(HANDLE, build(action='clear'), li, False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _cancel_resolve():
    if HANDLE >= 0:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def play(eid, resume_param):
    entry = core.find(eid)
    if not entry:
        core.notify('Item is no longer in history')
        _cancel_resolve()
        return

    if resume_param == '0':
        resume = False
    elif resume_param == '1':
        resume = core.has_resume_point(entry)
    elif core.can_resume(entry):
        if core.prompt_enabled():
            choice = core.ask_start(entry)
            if choice is None:
                _cancel_resolve()
                return
            resume = (choice == 'resume')
        else:
            resume = True
    else:
        resume = False

    li = core.make_listitem(entry, resume)
    target = entry['target']
    if HANDLE >= 0 and not target.startswith('plugin://'):
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    else:
        # Nested plugin:// targets (and RunPlugin calls) are started directly.
        _cancel_resolve()
        xbmc.Player().play(item=target, listitem=li)


def main():
    action = PARAMS.get('action', '')
    if action == 'play':
        play(PARAMS.get('id', ''), PARAMS.get('resume'))
    elif action == 'remove':
        core.remove(PARAMS.get('id', ''))
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'clear':
        if xbmcgui.Dialog().yesno('Last Played 10', 'Clear the whole history?'):
            core.clear()
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'noop':
        pass
    elif action == 'latest':
        list_entries(core.load()[:1], show_clear=False)
    else:
        list_entries(core.load(), show_clear=True)


if __name__ == '__main__':
    main()
