"""Per-add-on configuration: Last Played 10 (choose from recent items)."""
ADDON_ID = 'plugin.video.lastplayed10'
NAME = 'Last Played 10'
LAUNCH_MODE = 'history'    # launching shows a list of recent items to choose from
HISTORY_FIXED = None       # size comes from the settings (default 10)
PROMPT_DEFAULT = True      # ask Resume / Play from the beginning
