"""Per-add-on configuration: Last Played 10 (choose from recent items)."""
ADDON_ID = 'plugin.video.lastplayed10'
NAME = 'Last Played 10'
LAUNCH_MODE = 'history'    # launching shows a list of recent items to choose from
HISTORY_FIXED = None       # size comes from the settings (default 10)
PROMPT_DEFAULT = False     # resume without asking (Sharad's choice, Oct 2026)
PROMPT_OFF_ONCE = True     # switch the question off once on devices that had it on
