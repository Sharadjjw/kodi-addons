"""Background service: records what is played, where it stopped, and the
subtitle choice; restores the subtitle when playback is started by us."""
import os
import time

import xbmc

import lp_core as core

SAVE_EVERY = 15      # seconds between periodic position saves
SAVE_MIN_DELTA = 5   # only save if position moved at least this much
RESTORE_FINAL_TRY = 10
RESTORE_MAX_TRIES = 20
RESTORE_STABLE = 3   # consecutive "already correct" checks before we stop


class Tracker(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.cur = None
        self.pos = 0.0
        self.total = 0.0
        self.saved_pos = 0.0
        self.last_save = 0.0
        self.restore = None
        self.sub_key = None
        self.n = 0

    def onAVStarted(self):
        try:
            playing = self.getPlayingFile()
        except Exception:
            return

        item_path, label = '', ''
        try:
            li = self.getPlayingItem()
            item_path = li.getPath() or ''
            label = li.getLabel() or ''
        except Exception:
            pass
        if not item_path:
            item_path = xbmc.getInfoLabel('Player.Filenameandpath')

        # A library .strm is replayed as the .strm itself, so Kodi loads its library
        # info and saved settings (subtitle offset etc.) just as from the Movies section.
        # Otherwise keep the original plugin:// URL (it re-resolves fresh stream tokens
        # and re-attaches the add-on's subtitles), or the real path/URL being played.
        target = core.strm_target(item_path, xbmc.getInfoLabel('Player.Filenameandpath'))
        if not target:
            target = item_path if item_path.startswith('plugin://') else playing
        if not target or target.startswith(core.SKIP_PREFIXES):
            return

        show = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
        title = xbmc.getInfoLabel('Player.Title') or label
        if not title:
            title = os.path.basename(playing.split('|')[0].split('?')[0]) or target
        if show and show != title:
            title = '%s - %s' % (show, title)

        thumb = (xbmc.getInfoLabel('Player.Art(thumb)')
                 or xbmc.getInfoLabel('Player.Art(poster)')
                 or xbmc.getInfoLabel('Player.Icon'))

        try:
            kind = 'video' if self.isPlayingVideo() else 'audio'
        except Exception:
            kind = 'video'

        try:
            self.total = float(self.getTotalTime())
        except Exception:
            self.total = 0.0
        self.pos = 0.0
        self.saved_pos = 0.0
        self.last_save = time.monotonic()
        self.cur = core.entry_id(target)
        self.restore = None
        self.sub_key = None
        self.n = 0

        old = core.find(self.cur)
        entry = {
            'id': self.cur,
            'target': target,
            'playing': playing,
            'title': title,
            'type': kind,
            'thumb': thumb,
            'pos': 0.0,
            'total': self.total,
            'finished': False,
            'ts': time.time(),
        }
        if old:
            for key in core.SUB_KEYS:   # keep the saved subtitle choice
                if key in old:
                    entry[key] = old[key]
        flagged = core.take_restore_flag(self.cur)
        core.record_start(entry)

        if flagged and old and 'sub_enabled' in old and kind == 'video':
            self.restore = {'prefs': old, 'tries': 0, 'stable': 0}
            self._restore_step()

    # -- subtitle restore -------------------------------------------------
    def _restore_step(self):
        r = self.restore
        r['tries'] += 1
        res = core.restore_subtitles(self, r['prefs'],
                                     final=r['tries'] >= RESTORE_FINAL_TRY)
        if res == 'ok':
            r['stable'] += 1
            if r['stable'] >= RESTORE_STABLE:
                self.restore = None
        elif res == 'applied':
            r['stable'] = 0
        elif res in ('applied_file', 'gaveup'):
            self.restore = None
        if self.restore and r['tries'] >= RESTORE_MAX_TRIES:
            self.restore = None

    # -- subtitle capture ---------------------------------------------------
    def _sample_subtitles(self):
        self.n += 1
        if self.n % 2:
            return
        state = core.read_subtitle_state()
        if not state:
            return
        cur = state['current']
        key = (state['enabled'], cur.get('index'), cur.get('name'), cur.get('language'))
        if key == self.sub_key:
            return
        self.sub_key = key
        try:
            playing = self.getPlayingFile()
        except Exception:
            playing = ''
        core.update_subs(self.cur, core.snapshot_subtitles(self.cur, state, playing))

    # -- periodic ---------------------------------------------------------------
    def tick(self):
        try:
            self.pos = float(self.getTime())
            total = float(self.getTotalTime())
            if total > 0:
                self.total = total
        except Exception:
            return
        if self.restore:
            self._restore_step()
        else:
            self._sample_subtitles()
        if (abs(self.pos - self.saved_pos) >= SAVE_MIN_DELTA
                and time.monotonic() - self.last_save >= SAVE_EVERY):
            core.update_position(self.cur, self.pos, self.total)
            self.saved_pos = self.pos
            self.last_save = time.monotonic()

    def _flush(self, finished):
        if self.cur:
            core.update_position(self.cur, self.pos, self.total, finished)
        self.cur = None
        self.restore = None

    def onPlayBackStopped(self):
        self._flush(False)

    def onPlayBackEnded(self):
        self._flush(True)

    def onPlayBackError(self):
        self.cur = None
        self.restore = None


def run():
    monitor = xbmc.Monitor()
    tracker = Tracker()
    while not monitor.waitForAbort(1):
        if tracker.cur and tracker.isPlaying():
            tracker.tick()


if __name__ == '__main__':
    run()
