"""Kodi Voice: starts the Sinric Pro bridge with Kodi and restarts it when the
settings change. Never logs the App Key, App Secret or Device IDs."""
import os
import sys

import xbmc
import xbmcaddon

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib'))

from kv_bridge import Bridge, Config  # noqa: E402
from kv_kodi import ADDON_ID, log, notify  # noqa: E402


def _clean(text):
    # Pasted values often carry spaces or line breaks.
    return ''.join((text or '').split())


def read_config():
    addon = xbmcaddon.Addon(ADDON_ID)
    if not addon.getSettingBool('enabled'):
        return None
    try:
        step = addon.getSettingInt('step_seconds')
    except Exception:
        step = 30
    return Config(
        app_key=_clean(addon.getSetting('app_key')),
        app_secret=_clean(addon.getSetting('app_secret')),
        tv_id=_clean(addon.getSetting('tv_device_id')),
        cmd_id=_clean(addon.getSetting('cmd_device_id')),
        step=max(5, step or 30),
    )


def _signature(cfg):
    if cfg is None:
        return None
    return (cfg.app_key, cfg.app_secret, cfg.tv_id, cfg.cmd_id, cfg.step)


class Monitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.changed = False

    def onSettingsChanged(self):
        self.changed = True


def run():
    monitor = Monitor()
    bridge = None
    current = None
    told_missing = False

    def apply():
        nonlocal bridge, current, told_missing
        cfg = read_config()
        sig = _signature(cfg)
        if sig == current and bridge is not None:
            return
        if bridge is not None:
            bridge.stop()
            bridge = None
        current = sig
        if cfg is None:
            log('Turned off in settings')
            return
        if not cfg.complete():
            log('Waiting for the App Key, App Secret and Device IDs in the settings')
            if not told_missing:
                told_missing = True
                notify('Enter your Sinric Pro keys in Kodi Voice settings', 5000)
            return
        log('Starting (%d device%s)' % (len(cfg.device_ids()), '' if len(cfg.device_ids()) == 1 else 's'))
        bridge = Bridge(cfg)
        bridge.start()

    apply()
    while not monitor.waitForAbort(2):
        if monitor.changed:
            monitor.changed = False
            apply()
    if bridge is not None:
        bridge.stop()


if __name__ == '__main__':
    run()
