"""Sinric Pro wire protocol (payloadVersion 2, signatureVersion 1).

Mirrors the official Python SDK (sinricpro 6.0.0, core/signature.py and
core/sinric_pro.py): the payload is serialised once with compact separators,
signed with HMAC-SHA256 of the App Secret (base64), and spliced into the
envelope with the signature last. Incoming messages are validated against the
payload bytes exactly as received (sliced between '"payload":' and
',"signature"'), never against a re-serialisation.
"""
import base64
import hashlib
import hmac
import json
import random
import string
import time

SERVER_URL = 'wss://ws.sinric.pro:443/'
PLATFORM = 'Python'
SDK_VERSION = '6.0.0'

_PAYLOAD_MARKER = '"payload":'
_SIGNATURE_MARKER = ',"signature"'
_HEADER = {'payloadVersion': 2, 'signatureVersion': 1}


def connect_headers(app_key, device_ids):
    return [
        'appkey: %s' % app_key,
        'deviceids: %s' % ';'.join(device_ids),
        'platform: %s' % PLATFORM,
        'SDKVersion: %s' % SDK_VERSION,
    ]


class Signer:
    def __init__(self, app_secret):
        self._secret = app_secret.encode('utf-8')

    def _hmac_b64(self, payload_str):
        digest = hmac.new(self._secret, payload_str.encode('utf-8'), hashlib.sha256).digest()
        return base64.b64encode(digest).decode('utf-8')

    def sign_message(self, message):
        """Return the exact string to send: header, payload, signature (last)."""
        payload_str = json.dumps(message['payload'], separators=(',', ':'), sort_keys=False)
        signature = {'HMAC': self._hmac_b64(payload_str)}
        parts = [json.dumps(k) + ':' + json.dumps(v, separators=(',', ':'), sort_keys=False)
                 for k, v in message.items() if k not in ('payload', 'signature')]
        parts.append(_PAYLOAD_MARKER + payload_str)
        parts.append('"signature":' + json.dumps(signature, separators=(',', ':')))
        return '{' + ','.join(parts) + '}'

    def valid(self, raw, parsed):
        try:
            received = parsed['signature']['HMAC']
        except (KeyError, TypeError):
            return False
        begin = raw.find(_PAYLOAD_MARKER)
        if begin < 0:
            return False
        end = raw.find(_SIGNATURE_MARKER, begin)
        if end < 0:
            return False
        payload_str = raw[begin + len(_PAYLOAD_MARKER):end]
        return hmac.compare_digest(received, self._hmac_b64(payload_str))


def response(request_payload, success, value, error_message=None):
    payload = {
        'action': request_payload.get('action', ''),
        'clientId': request_payload.get('clientId', ''),
        'createdAt': int(time.time()),
        'deviceId': request_payload.get('deviceId', ''),
        'message': error_message if error_message else ('OK' if success else 'Request failed'),
        'replyToken': request_payload.get('replyToken', ''),
        'scope': 'device',
        'success': bool(success),
        'type': 'response',
        'value': value,
    }
    if 'instanceId' in request_payload:
        payload['instanceId'] = request_payload['instanceId']
    return {'header': dict(_HEADER), 'payload': payload}


def event(device_id, action, value, cause='PHYSICAL_INTERACTION'):
    stamp = int(time.time() * 1000)
    token = '%d-%s' % (stamp, ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in range(9)))
    return {'header': dict(_HEADER), 'payload': {
        'action': action,
        'cause': {'type': cause},
        'createdAt': int(time.time()),
        'deviceId': device_id,
        'replyToken': token,
        'type': 'event',
        'value': value,
    }}
