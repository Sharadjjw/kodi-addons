"""One WebSocket connection to Sinric Pro: receives Alexa requests, answers them,
and hands the work to kv_kodi. Runs in its own thread; reconnects by itself."""
import json
import os
import threading
import time
import traceback

import websocket

import kv_sinric as sp
from kv_kodi import Kodi, command_for, log, notify

CA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cacert.pem')
PING_INTERVAL = 60      # seconds; keeps home routers from dropping an idle connection
PING_TIMEOUT = 20
BACKOFF = (5, 10, 30, 60, 120)
AUTH_BACKOFF = 600      # wrong App Key: try again after 10 minutes
RESET_AFTER = 2         # seconds before "Kodi Command" is set back to 0 %


class Config:
    def __init__(self, app_key, app_secret, tv_id, cmd_id, step):
        self.app_key = app_key
        self.app_secret = app_secret
        self.tv_id = tv_id
        self.cmd_id = cmd_id
        self.step = step

    def device_ids(self):
        return [d for d in (self.tv_id, self.cmd_id) if d]

    def complete(self):
        return bool(self.app_key and self.app_secret and self.device_ids())


class Bridge:
    def __init__(self, cfg, kodi=None, server_url=None, sslopt=None):
        self.cfg = cfg
        self.kodi = kodi or Kodi()
        self.signer = sp.Signer(cfg.app_secret)
        self.url = server_url or sp.SERVER_URL
        self.sslopt = sslopt if sslopt is not None else {'ca_certs': CA_FILE}
        self._stop = threading.Event()
        self._app = None
        self._thread = None
        self._attempt = 0
        self._auth_failed = False
        self._told_connected = False
        self._warned = {}
        self.connected = False

    # --- lifecycle ---
    def start(self):
        self._thread = threading.Thread(target=self._loop, name='kodivoice', daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        app = self._app
        if app is not None:
            try:
                app.close()
            except Exception:
                pass
        if self._thread is not None:
            self._thread.join(10)

    def _loop(self):
        while not self._stop.is_set():
            self._auth_failed = False
            self._app = websocket.WebSocketApp(
                self.url,
                header=sp.connect_headers(self.cfg.app_key, self.cfg.device_ids()),
                on_open=self._on_open,
                on_message=self._on_message,
                on_error=self._on_error,
                on_close=self._on_close,
            )
            try:
                self._app.run_forever(sslopt=self.sslopt, ping_interval=PING_INTERVAL,
                                      ping_timeout=PING_TIMEOUT)
            except Exception as e:
                log('Connection error: %s' % type(e).__name__)
            self.connected = False
            if self._stop.is_set():
                break
            if self._auth_failed:
                wait = AUTH_BACKOFF
            else:
                wait = BACKOFF[min(self._attempt, len(BACKOFF) - 1)]
                self._attempt += 1
            log('Reconnecting in %d s' % wait)
            self._stop.wait(wait)

    # --- websocket callbacks ---
    def _on_open(self, ws):
        self.connected = True
        self._attempt = 0
        log('Connected to Sinric Pro')
        if not self._told_connected:
            self._told_connected = True
            notify('Connected to Sinric Pro')

    def _on_error(self, ws, err):
        status = getattr(err, 'status_code', None)
        if status in (401, 403):
            self._auth_failed = True
            log('Sinric Pro refused the App Key (HTTP %s)' % status)
            notify('Sinric Pro refused the App Key. Check the add-on settings.', 6000)
        else:
            log('Connection problem: %s' % type(err).__name__)

    def _on_close(self, ws, code=None, reason=None):
        if self.connected:
            log('Disconnected from Sinric Pro (%s)' % code)
        self.connected = False

    def _on_message(self, ws, raw):
        try:
            msg = json.loads(raw)
        except ValueError:
            return
        if 'timestamp' in msg and 'payload' not in msg:
            return                                   # server clock message
        payload = msg.get('payload') or {}
        if payload.get('type') != 'request':
            return
        if not self.signer.valid(raw, msg):
            log('Ignored a request with a wrong signature (check the App Secret)')
            self._warn('secret', 'Alexa command refused: the App Secret in Kodi Voice settings '
                                 'does not match Sinric Pro. Enter it again.')
            self._send(sp.response(payload, False, {}, 'Signature is invalid'))
            return
        try:
            ok, value = self.handle(payload)
        except Exception as e:
            log('Command failed: %s' % traceback.format_exc())
            self._warn('error', 'Alexa command failed (%s). Please tell Claude.' % type(e).__name__)
            ok, value = False, {}
        self._send(sp.response(payload, ok, value))

    def _warn(self, kind, text):
        """On-screen problem report, at most once a minute per kind."""
        now = time.time()
        if now - self._warned.get(kind, 0) < 60:
            return
        self._warned[kind] = now
        notify(text, 8000, force=True)

    def _send(self, message):
        app = self._app
        if app is None or app.sock is None:
            return
        try:
            app.send(self.signer.sign_message(message))
        except Exception as e:
            log('Send failed: %s' % type(e).__name__)

    # --- requests ---
    def handle(self, payload):
        """Carry out one request; returns (success, response value)."""
        device = payload.get('deviceId')
        action = payload.get('action', '')
        value = payload.get('value') or {}
        if device == self.cfg.tv_id:
            return self._tv(action, value)
        if device == self.cfg.cmd_id:
            return self._command(action, value)
        log('Request for an unknown device ignored')
        self._warn('device', 'Alexa command for a device that is not in Kodi Voice settings. '
                             'Check both Device IDs.')
        return False, {}

    def _tv(self, action, value):
        if action == 'mediaControl':
            control = value.get('control', '')
            ok = self.kodi.media(control, self.cfg.step)
            return ok, {'control': control}
        if action == 'setPowerState':
            # "Alexa, turn on/off Kodi": nothing to switch; answer so Alexa does not complain.
            return True, {'state': value.get('state', 'On')}
        if action == 'setMute':
            mute = bool(value.get('mute'))
            self.kodi.set_mute(mute)
            return True, {'mute': mute}
        log('Not supported on Kodi: %s' % action)
        return False, {}

    def _command(self, action, value):
        if action == 'setPowerLevel':
            level = value.get('powerLevel', 0)
            cmd = command_for(level)
            if cmd is None:
                return True, {'powerLevel': level}  # 0 % or an unused level: do nothing
            ok = self.kodi.run_command(cmd)
            self._reset_later()
            return ok, {'powerLevel': level}
        if action == 'setPowerState':
            # Plain on/off (e.g. "turn on the lights" in its room) is ignored on purpose.
            return True, {'state': value.get('state', 'Off')}
        if action == 'adjustPowerLevel':
            return True, {'powerLevel': 0}
        return False, {}

    def _reset_later(self):
        """Put "Kodi Command" back to 0 % so the next routine always counts as a change."""
        def run():
            if self._stop.wait(RESET_AFTER):
                return
            self._send(sp.event(self.cfg.cmd_id, 'setPowerLevel', {'powerLevel': 0}))
        threading.Thread(target=run, daemon=True).start()
