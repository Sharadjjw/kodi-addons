"""What each Alexa command does in Kodi."""
import json

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = 'service.kodivoice'
LAST_PLAYED = 'script.lastplayed'
LAST_PLAYED_10 = 'plugin.video.lastplayed10'

# "Kodi Command" (Switch with Dimming): the level an Alexa routine sets -> what to do.
COMMANDS = {
    10: ('seek', -30),
    20: ('seek', 30),
    30: ('seek', -180),
    40: ('seek', 180),
    50: ('seek', -300),
    60: ('seek', 300),
    70: ('lastplayed', None),
    80: ('lastplayed10', None),
}
TOLERANCE = 4   # 28-32 % still means 30 %


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def notify(text, ms=2000, force=False):
    """force=True: problem reports, shown even when on-screen messages are off."""
    if not force:
        try:
            if not xbmcaddon.Addon(ADDON_ID).getSettingBool('notify'):
                return
        except Exception:
            pass
    try:
        icon = xbmcaddon.Addon(ADDON_ID).getAddonInfo('icon')
    except Exception:
        icon = xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification('Kodi Voice', text, icon, ms)


def command_for(level):
    """Nearest command for a level, or None (0 % / off and stray levels do nothing)."""
    try:
        level = int(round(float(level)))
    except (TypeError, ValueError):
        return None
    if level <= 0:
        return None
    best = min(COMMANDS, key=lambda k: abs(k - level))
    if abs(best - level) > TOLERANCE:
        return None
    return COMMANDS[best]


def _describe_seek(seconds):
    word = 'Back' if seconds < 0 else 'Forward'
    n = abs(seconds)
    if n % 60 == 0:
        mins = n // 60
        return '%s %d minute%s' % (word, mins, '' if mins == 1 else 's')
    return '%s %d seconds' % (word, n)


def _has_addon(addon_id):
    return xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id)


class Kodi:
    def __init__(self):
        self.player = xbmc.Player()

    def _playing(self):
        return self.player.isPlaying()

    def _paused(self):
        return xbmc.getCondVisibility('Player.Paused')

    # --- media controls (device "Kodi", type TV) ---
    def media(self, control, step):
        control = (control or '').lower()
        if control == 'pause':
            return self.pause()
        if control in ('play', 'resume'):
            return self.play()
        if control == 'stop':
            return self.stop()
        if control == 'rewind':
            return self.seek(-abs(step))
        if control == 'fastforward':
            return self.seek(abs(step))
        if control == 'startover':
            return self.start_over()
        if control == 'next':
            return self._goto('next')
        if control == 'previous':
            return self._goto('previous')
        log('Unknown media control: %s' % control, xbmc.LOGWARNING)
        return False

    def pause(self):
        if not self._playing():
            notify('Nothing is playing')
            return True
        if not self._paused():
            self.player.pause()          # toggles; only called when it is playing
        notify('Paused')
        return True

    def play(self, start_last_when_idle=True):
        if not self._playing():
            if start_last_when_idle and _has_addon(LAST_PLAYED):
                log('Resume asked with nothing playing: starting Last Played')
                xbmc.executebuiltin('RunScript(%s)' % LAST_PLAYED)
                return True
            notify('Nothing is playing')
            return True
        if self._paused():
            self.player.pause()          # toggles back to playing
        notify('Playing')
        return True

    def stop(self):
        if self._playing():
            self.player.stop()
            notify('Stopped')
        return True

    def seek(self, seconds):
        if not self._playing():
            notify('Nothing is playing')
            return True
        try:
            now = self.player.getTime()
            total = self.player.getTotalTime()
        except RuntimeError:
            notify('Nothing is playing')
            return True
        target = now + seconds
        if total > 0:
            target = min(target, max(total - 5, 0))
        target = max(target, 0)
        self.player.seekTime(target)
        notify(_describe_seek(seconds))
        return True

    def start_over(self):
        if self._playing():
            self.player.seekTime(0)
            notify('From the start')
        return True

    def set_mute(self, mute):
        xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Application.SetMute',
                                        'params': {'mute': bool(mute)}}))
        notify('Muted' if mute else 'Sound on')
        return True

    def _goto(self, where):
        if self._playing():
            xbmc.executebuiltin('PlayerControl(%s)' % ('Next' if where == 'next' else 'Previous'))
        return True

    # --- routine commands (device "Kodi Command", Switch with Dimming) ---
    def run_command(self, cmd):
        kind, arg = cmd
        if kind == 'seek':
            return self.seek(arg)
        if kind == 'lastplayed':
            if not _has_addon(LAST_PLAYED):
                notify('Last Played is not installed', 4000)
                return True
            if self.player.isPlayingVideo():
                notify('A video is already playing')
                return True
            log('Starting Last Played')
            xbmc.executebuiltin('RunScript(%s)' % LAST_PLAYED)
            return True
        if kind == 'lastplayed10':
            if not _has_addon(LAST_PLAYED_10):
                notify('Last Played 10 is not installed', 4000)
                return True
            log('Opening Last Played 10')
            xbmc.executebuiltin('RunScript(%s)' % LAST_PLAYED_10)
            return True
        return False
